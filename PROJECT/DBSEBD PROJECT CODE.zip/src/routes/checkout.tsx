import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQueries } from "@tanstack/react-query";
import { CheckCircle2, ShoppingBag } from "lucide-react";
import { toast } from "sonner";
import { AuthGate, SiteShell } from "@/components/site-header";
import { PaymentForm, type PaymentMethod } from "@/components/payment-form";
import { Button } from "@/components/ui/button";
import { createBooking, getPackageBySlug, notify, type TravelPackage } from "@/lib/api/travel";
import { useAuth } from "@/lib/auth";
import { useCart, type CartItem } from "@/lib/cart";
import { inr } from "@/lib/format";
import { quote } from "@/lib/pricing";

export const Route = createFileRoute("/checkout")({
  head: () => ({ meta: [
    { title: "Checkout — Royal Voyage" },
    { name: "description", content: "Confirm traveller details, departure dates and current trip totals for your Royal Voyage booking." },
    { property: "og:title", content: "Checkout — Royal Voyage" },
    { property: "og:description", content: "Review and confirm your selected journeys." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <AuthGate><CheckoutPage /></AuthGate>,
});

const field = "mt-1.5 w-full rounded-xl border border-border/60 bg-background/60 px-4 py-3 text-sm outline-none focus:border-primary";
function itemQuote(pkg: TravelPackage, item: CartItem) { return quote({ packagePrice: Number(pkg.price), adults: item.adults, children: item.children, nights: pkg.duration_nights, roomsCount: 1, roomPricePerNight: 0, baseRoomPricePerNight: 0, addonIds: [] }); }
function defaultDate() { const date = new Date(); date.setDate(date.getDate() + 14); return date.toISOString().slice(0, 10); }

function CheckoutPage() {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { items, hydrated, clearCart } = useCart();
  const [dates, setDates] = useState<Record<string, string>>({});
  const [traveller, setTraveller] = useState({ fullName: "", email: "", phone: "", nationality: "" });
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [bookingIds, setBookingIds] = useState<string[]>([]);
  const results = useQueries({ queries: items.map((item) => ({ queryKey: ["package", item.slug], queryFn: () => getPackageBySlug(item.slug) })) });
  const rows = items.map((item, index) => ({ item, pkg: results[index]?.data ?? null })).filter((row): row is { item: CartItem; pkg: TravelPackage } => !!row.pkg);

  useEffect(() => { if (profile) setTraveller({ fullName: profile.full_name, email: profile.email, phone: profile.phone, nationality: "" }); }, [profile]);
  useEffect(() => { setDates((current) => { const next = { ...current }; items.forEach((item) => { if (!next[item.slug]) next[item.slug] = defaultDate(); }); return next; }); }, [items]);
  const totals = useMemo(() => rows.reduce((acc, row) => { const q = itemQuote(row.pkg, row.item); return { subtotal: acc.subtotal + q.packageAmount, taxes: acc.taxes + q.taxes, total: acc.total + q.total }; }, { subtotal: 0, taxes: 0, total: 0 }), [rows]);

  async function pay(method: PaymentMethod) {
    if (!user || !traveller.fullName.trim() || !/^\S+@\S+\.\S+$/.test(traveller.email) || traveller.phone.trim().length < 7 || !traveller.nationality.trim()) { toast.error("Complete all lead traveller details before paying."); return; }
    if (!rows.length || rows.length !== items.length) { toast.error("Remove unavailable packages before checkout."); return; }
    setBusy(true);
    const created: string[] = [];
    try {
      for (const { item, pkg } of rows) {
        const startDate = dates[item.slug];
        if (!startDate) throw new Error(`Choose a departure date for ${pkg.name}.`);
        const end = new Date(startDate); end.setDate(end.getDate() + pkg.duration_days - 1);
        const q = itemQuote(pkg, item);
        const booking = await createBooking({ packageId: pkg.id, hotelId: null, roomId: null, startDate, endDate: end.toISOString().slice(0, 10), adults: item.adults, children: item.children, roomsCount: 1, addons: [], packageAmount: q.packageAmount, hotelAmount: 0, addonAmount: 0, taxes: q.taxes, total: q.total, method, notes: `${notes}\nLead traveller: ${traveller.fullName}; Nationality: ${traveller.nationality}`.trim() });
        created.push(booking.id);
        await notify(user.id, "Booking confirmed", `${pkg.name} is confirmed for ${startDate}. Reference: ${booking.booking_ref}`);
      }
      clearCart(); setBookingIds(created); toast.success(`${created.length} ${created.length === 1 ? "trip" : "trips"} confirmed`);
    } catch (error) { toast.error(error instanceof Error ? error.message : "Checkout could not be completed"); }
    finally { setBusy(false); }
  }

  if (!hydrated || results.some((result) => result.isLoading)) return <SiteShell><div className="grid min-h-[70vh] place-items-center text-muted-foreground">Preparing checkout…</div></SiteShell>;
  if (bookingIds.length) return <SiteShell><main className="mx-auto max-w-2xl px-6 py-24 text-center"><CheckCircle2 className="mx-auto h-12 w-12 text-primary" /><div className="mt-5 text-xs uppercase tracking-[0.2em] text-primary">Booking confirmed</div><h1 className="mt-2 font-display text-4xl">Your journeys are reserved</h1><p className="mt-4 text-sm text-muted-foreground">Your {bookingIds.length === 1 ? "trip is" : "trips are"} now available with current booking details and status.</p><div className="mt-8 flex flex-wrap justify-center gap-3"><Button asChild className="rounded-full"><Link to="/trips">View my trips</Link></Button>{bookingIds.length === 1 && <Button asChild variant="outline" className="rounded-full"><Link to="/trips/$id" params={{ id: bookingIds[0] }} search={{ confirmed: true }}>Open confirmation</Link></Button>}</div></main></SiteShell>;
  if (!items.length) return <SiteShell><main className="mx-auto max-w-2xl px-6 py-24 text-center"><ShoppingBag className="mx-auto h-9 w-9 text-primary" /><h1 className="mt-4 font-display text-4xl">Nothing to check out</h1><p className="mt-3 text-sm text-muted-foreground">Your cart has no selected journeys.</p><Button asChild className="mt-6 rounded-full"><Link to="/packages" search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }}>Browse packages</Link></Button></main></SiteShell>;

  return <SiteShell><main className="mx-auto max-w-7xl px-6 py-12"><div className="text-xs uppercase tracking-[0.2em] text-primary">Final review</div><h1 className="mt-2 font-display text-4xl sm:text-5xl">Checkout</h1><p className="mt-2 text-sm text-muted-foreground">Confirm each departure date and the lead traveller before demo payment.</p>
    <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_400px]"><div className="space-y-6">
      <section className="rounded-2xl glass p-6"><h2 className="font-display text-2xl">Selected journeys</h2><div className="mt-5 divide-y divide-border/50">{rows.map(({ item, pkg }) => <div key={item.slug} className="grid gap-4 py-5 first:pt-0 sm:grid-cols-[80px_1fr_190px]"><img src={pkg.image_url} alt={pkg.name} className="h-20 w-20 rounded-lg object-cover" /><div><h3 className="font-display text-xl">{pkg.name}</h3><p className="mt-1 text-xs text-muted-foreground">{item.adults} adult{item.adults === 1 ? "" : "s"}{item.children ? `, ${item.children} child${item.children === 1 ? "" : "ren"}` : ""} · {pkg.duration_days} days</p><p className="mt-2 text-sm text-primary">{inr(itemQuote(pkg, item).total)}</p></div><label className="text-xs text-muted-foreground">Departure date<input type="date" min={new Date().toISOString().slice(0, 10)} className={field} value={dates[item.slug] ?? ""} onChange={(event) => setDates({ ...dates, [item.slug]: event.target.value })} /></label></div>)}</div><Button asChild variant="outline" className="rounded-full"><Link to="/cart">Edit cart</Link></Button></section>
      <section className="rounded-2xl glass p-6"><h2 className="font-display text-2xl">Lead traveller</h2><div className="mt-5 grid gap-5 sm:grid-cols-2">{([ ["fullName", "Full name", "text"], ["email", "Email", "email"], ["phone", "Phone", "tel"], ["nationality", "Nationality", "text"] ] as const).map(([key, label, type]) => <label key={key} className="text-xs text-muted-foreground">{label}<input type={type} className={field} value={traveller[key]} onChange={(event) => setTraveller({ ...traveller, [key]: event.target.value })} /></label>)}<label className="text-xs text-muted-foreground sm:col-span-2">Requests for the travel team<textarea rows={4} className={`${field} resize-none`} value={notes} onChange={(event) => setNotes(event.target.value)} /></label></div></section>
    </div><div><div className="mb-6 rounded-2xl glass-strong p-6"><h2 className="font-display text-2xl">Total</h2><div className="mt-5 space-y-3 text-sm"><SummaryRow label="Packages" value={inr(totals.subtotal)} /><SummaryRow label="GST (5%)" value={inr(totals.taxes)} /></div><div className="mt-5 flex items-end justify-between border-t border-border/50 pt-5"><span className="text-sm">Amount due</span><strong className="font-display text-3xl text-primary">{inr(totals.total)}</strong></div></div><PaymentForm amount={totals.total} busy={busy} onPay={pay} /></div></div>
  </main></SiteShell>;
}

function SummaryRow({ label, value }: { label: string; value: string }) { return <div className="flex justify-between gap-4"><span className="text-muted-foreground">{label}</span><span>{value}</span></div>; }