import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CalendarDays, Wallet, Clock, MapPin } from "lucide-react";
import { SiteShell } from "@/components/site-header";
import { PageTransition, Reveal } from "@/components/motion";
import {
  SectionHeading, AttractionCard, PackageCard, HotelCard, CardSkeleton, EmptyState,
} from "@/components/cards";
import { inr } from "@/lib/format";
import { getCityBySlug, listAttractions, listHotels, listPackagesForCity } from "@/lib/api/travel";

export const Route = createFileRoute("/destinations/$city")({
  head: ({ params }) => {
    const pretty = params.city.replace(/-/g, " ").replace(/\b\w/g, (m) => m.toUpperCase());
    return {
      meta: [
        { title: `${pretty} Travel Guide & Packages — Royal Voyage` },
        { name: "description", content: `Plan a trip to ${pretty}: attractions, curated travel packages, hotels, best season to visit and an approximate daily budget.` },
        { property: "og:title", content: `${pretty} — Royal Voyage` },
        { property: "og:description", content: `Attractions, packages and stays in ${pretty}.` },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: CityPage,
});

function CityPage() {
  const { city: slug } = Route.useParams();
  const { data: city, isLoading } = useQuery({ queryKey: ["city", slug], queryFn: () => getCityBySlug(slug) });

  const { data: places } = useQuery({
    queryKey: ["city-places", city?.id], enabled: !!city, queryFn: () => city ? listAttractions({ cityId: city.id }) : Promise.resolve([]),
  });
  const { data: hotels } = useQuery({
    queryKey: ["city-hotels", city?.id], enabled: !!city, queryFn: () => city ? listHotels({ cityId: city.id }) : Promise.resolve([]),
  });
  const { data: packages } = useQuery({
    queryKey: ["city-packages", city?.id], enabled: !!city, queryFn: () => city ? listPackagesForCity(city) : Promise.resolve([]),
  });

  if (isLoading) {
    return (
      <SiteShell>
        <div className="mx-auto max-w-7xl px-6 py-14">
          <div className="h-72 animate-pulse rounded-3xl bg-muted/40" />
        </div>
      </SiteShell>
    );
  }

  if (!city) {
    return (
      <SiteShell>
        <div className="mx-auto max-w-3xl px-6 py-24">
          <EmptyState
            title="We don't cover that destination yet"
            hint="Browse the destinations we currently plan trips to."
            action={<Link to="/destinations" className="rounded-full bg-primary px-6 py-2.5 text-sm text-primary-foreground">All destinations</Link>}
          />
        </div>
      </SiteShell>
    );
  }

  return (
    <SiteShell>
      <PageTransition>
        <section className="relative">
          <img
            src={city.image_url}
            alt={`${city.name}, ${city.state?.name}`}
            className="h-[46vh] min-h-[320px] w-full object-cover opacity-55"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
          <div className="absolute inset-x-0 bottom-0">
            <div className="mx-auto max-w-7xl px-6 pb-10">
              <nav className="mb-3 text-xs text-muted-foreground">
                <Link to="/destinations" className="hover:text-primary">Destinations</Link>
                <span className="mx-2">/</span>
                {city.state?.country?.name}
                <span className="mx-2">/</span>
                {city.state?.name}
              </nav>
              <h1 className="font-display text-5xl sm:text-6xl">{city.name}</h1>
            </div>
          </div>
        </section>

        <div className="mx-auto max-w-7xl px-6 pb-8">
          <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
            <p className="max-w-3xl pt-8 text-muted-foreground">{city.description}</p>
            <div className="rounded-3xl glass p-6 lg:mt-8">
              <div className="space-y-4 text-sm">
                <div className="flex items-center gap-3">
                  <CalendarDays className="h-4 w-4 text-primary" />
                  <span><span className="text-muted-foreground">Best time to visit:</span> {city.best_season}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="h-4 w-4 text-primary" />
                  <span><span className="text-muted-foreground">Ideal length:</span> {city.recommended_days} days</span>
                </div>
                <div className="flex items-center gap-3">
                  <Wallet className="h-4 w-4 text-primary" />
                  <span><span className="text-muted-foreground">Daily budget:</span> {inr(city.daily_budget)} per person</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="h-4 w-4 text-primary" />
                  <span>{city.state?.name}, {city.state?.country?.name}</span>
                </div>
              </div>
            </div>
          </div>

          <section className="pt-16">
            <Reveal><SectionHeading eyebrow="Things to see" title={`Popular attractions in ${city.name}`} /></Reveal>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {!places ? <CardSkeleton count={3} /> : places.map((p) => <AttractionCard key={p.id} place={p} />)}
            </div>
            {places?.length === 0 && <EmptyState title="Attraction guide coming soon" hint="Our specialists are still curating this city's highlights." />}
          </section>

          <section className="pt-20">
            <Reveal><SectionHeading eyebrow="Ready to book" title="Packages covering this region" /></Reveal>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {!packages ? <CardSkeleton count={3} /> : packages.map((p) => <PackageCard key={p.id} pkg={p} />)}
            </div>
            {packages?.length === 0 && (
              <EmptyState
                title="No package for this region yet"
                hint="Browse every package we run — many include nearby cities."
                action={<Link to="/packages" search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }} className="rounded-full bg-primary px-6 py-2.5 text-sm text-primary-foreground">All packages</Link>}
              />
            )}
          </section>

          <section className="pt-20">
            <Reveal><SectionHeading eyebrow="Where to stay" title={`Hotels in ${city.name}`} /></Reveal>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {!hotels ? <CardSkeleton count={3} /> : hotels.map((h) => <HotelCard key={h.id} hotel={h} />)}
            </div>
            {hotels?.length === 0 && <EmptyState title="Stays are being added" hint="Your package hotel will still be arranged by our team." />}
          </section>
        </div>
      </PageTransition>
    </SiteShell>
  );
}
