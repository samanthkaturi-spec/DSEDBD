import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, CalendarDays, Users, ShieldCheck, Sparkles, Headset, Wallet } from "lucide-react";
import { SiteShell } from "@/components/site-header";
import { Reveal, PageTransition } from "@/components/motion";
import {
  SectionHeading, DestinationCard, PackageCard, AttractionCard, HotelCard, ReviewCard, CardSkeleton, EmptyState,
} from "@/components/cards";
import {
  listCountries, listStates, listCities, listCitiesByCountry, listPackages,
  listAttractions, listHotels, listReviews, getPublicStats,
} from "@/lib/api/travel";
import heroImg from "@/assets/hero-travel.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Royal Voyage — Travel Package Booking Portal" },
      { name: "description", content: "Discover. Plan. Experience. Curated travel packages, handpicked hotels and day-by-day itineraries across India and the UAE." },
      { property: "og:title", content: "Royal Voyage — Discover. Plan. Experience." },
      { property: "og:description", content: "Curated travel experiences, beautiful stays, unforgettable memories." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const field =
  "w-full rounded-xl border border-border/60 bg-background/70 px-3.5 py-3 text-sm outline-none transition focus:border-primary";

function SearchPanel() {
  const navigate = useNavigate();
  const [countryId, setCountryId] = useState("");
  const [stateId, setStateId] = useState("");
  const [citySlug, setCitySlug] = useState("");
  const [start, setStart] = useState("");
  const [travellers, setTravellers] = useState(2);

  const { data: countries = [] } = useQuery({ queryKey: ["countries"], queryFn: listCountries });
  const { data: states = [] } = useQuery({
    queryKey: ["states", countryId],
    queryFn: () => listStates(countryId || undefined),
  });
  const { data: cities = [] } = useQuery({
    queryKey: ["cities", countryId, stateId],
    queryFn: () =>
      stateId ? listCities({ stateId }) : countryId ? listCitiesByCountry(countryId) : listCities({ limit: 30 }),
  });

  function search() {
    if (citySlug) {
      navigate({ to: "/destinations/$city", params: { city: citySlug } });
      return;
    }
    navigate({
      to: "/packages",
      search: {
        country: countryId || undefined,
        state: stateId || undefined,
        start: start || undefined,
        travellers,
      },
    });
  }

  return (
    <div className="mt-10 rounded-3xl glass-strong p-4 sm:p-5">
      <div className="grid gap-3 lg:grid-cols-6">
        <select className={field} value={countryId} onChange={(e) => { setCountryId(e.target.value); setStateId(""); setCitySlug(""); }}>
          <option value="">Any country</option>
          {countries.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select className={field} value={stateId} onChange={(e) => { setStateId(e.target.value); setCitySlug(""); }}>
          <option value="">Any region</option>
          {states.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
        <select className={field} value={citySlug} onChange={(e) => setCitySlug(e.target.value)}>
          <option value="">Any city</option>
          {cities.map((c) => <option key={c.id} value={c.slug}>{c.name}</option>)}
        </select>
        <div className="relative">
          <CalendarDays className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input type="date" className={field} value={start} onChange={(e) => setStart(e.target.value)} aria-label="Travel date" />
        </div>
        <div className="relative">
          <Users className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="number" min={1} max={12} className={field} value={travellers}
            onChange={(e) => setTravellers(Math.max(1, Number(e.target.value)))} aria-label="Travellers"
          />
        </div>
        <button
          onClick={search}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-medium text-primary-foreground transition hover:opacity-90"
        >
          <Search className="h-4 w-4" /> Search
        </button>
      </div>
    </div>
  );
}

function Home() {
  const { data: cities, isLoading: loadingCities } = useQuery({ queryKey: ["home-cities"], queryFn: () => listCities({ limit: 8 }) });
  const { data: packages, isLoading: loadingPkgs } = useQuery({ queryKey: ["home-packages"], queryFn: () => listPackages({ limit: 6 }) });
  const { data: places, isLoading: loadingPlaces } = useQuery({ queryKey: ["home-places"], queryFn: () => listAttractions({ limit: 6 }) });
  const { data: hotels, isLoading: loadingHotels } = useQuery({ queryKey: ["home-hotels"], queryFn: () => listHotels({ limit: 3 }) });
  const { data: reviews } = useQuery({ queryKey: ["home-reviews"], queryFn: () => listReviews({ limit: 6 }) });
  const { data: stats } = useQuery({ queryKey: ["public-stats"], queryFn: getPublicStats });

  return (
    <SiteShell>
      <PageTransition>
        {/* hero */}
        <section className="relative overflow-hidden">
          <img
            src={heroImg}
            alt="Cliffside infinity pool overlooking the coast at sunset"
            width={1920}
            height={1088}
            className="absolute inset-0 -z-10 h-full w-full object-cover opacity-45"
          />
          <div className="absolute inset-0 -z-10 bg-gradient-to-b from-background/70 via-background/85 to-background" />
          <div className="mx-auto max-w-6xl px-6 pb-20 pt-16 sm:pt-24">
            <div className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-[11px] uppercase tracking-[0.25em] text-primary">
              <Sparkles className="h-3.5 w-3.5" /> Discover. Plan. Experience.
            </div>
            <h1 className="mt-6 max-w-3xl font-display text-5xl font-medium leading-[1.05] sm:text-7xl">
              Discover Your <span className="text-gradient-gold">Next Escape</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg text-muted-foreground">
              Curated travel experiences, beautiful stays, unforgettable memories —
              your journey, thoughtfully planned.
            </p>
            <SearchPanel />
            {stats && (
              <div className="mt-10 grid max-w-2xl grid-cols-3 gap-6">
                {[
                  { value: stats.destinations, label: "Destinations" },
                  { value: stats.packages, label: "Travel packages" },
                  { value: stats.hotels, label: "Hotels" },
                ].map((stat) => (
                  <div key={stat.label}>
                    <div className="font-display text-3xl text-gradient-gold">{stat.value.toLocaleString("en-IN")}</div>
                    <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{stat.label}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        <div className="mx-auto max-w-7xl px-6">
          {/* destinations */}
          <section className="pt-20">
            <Reveal>
              <SectionHeading
                eyebrow="Where to next"
                title="Available destinations"
                subtitle="Current destinations in the catalogue, with the recorded best season and daily budget for each."
                action={<Link to="/destinations" className="text-sm text-primary hover:underline">View all destinations →</Link>}
              />
            </Reveal>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {loadingCities ? <CardSkeleton count={4} /> : cities?.map((c, i) => (
                <Reveal key={c.id} delay={i * 0.05}><DestinationCard city={c} /></Reveal>
              ))}
            </div>
            {!loadingCities && !cities?.length && <EmptyState title="No destinations are currently available" />}
          </section>

          {/* packages */}
          <section className="pt-24">
            <Reveal>
              <SectionHeading
                eyebrow="Ready to book"
                title="Available travel packages"
                subtitle="Flights aside, everything is arranged: stays, transfers, sightseeing and guided experiences."
                action={<Link to="/packages" search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }} className="text-sm text-primary hover:underline">All packages →</Link>}
              />
            </Reveal>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {loadingPkgs ? <CardSkeleton count={3} /> : packages?.map((p, i) => (
                <Reveal key={p.id} delay={i * 0.05}><PackageCard pkg={p} /></Reveal>
              ))}
            </div>
            {!loadingPkgs && !packages?.length && <EmptyState title="No travel packages are currently available" />}
          </section>

          {/* attractions */}
          <section className="pt-24">
            <Reveal>
              <SectionHeading
                eyebrow="Worth the detour"
                title="Top attractions"
                action={<Link to="/attractions" className="text-sm text-primary hover:underline">Browse attractions →</Link>}
              />
            </Reveal>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {loadingPlaces ? <CardSkeleton count={3} /> : places?.map((p, i) => (
                <Reveal key={p.id} delay={i * 0.05}><AttractionCard place={p} /></Reveal>
              ))}
            </div>
            {!loadingPlaces && !places?.length && <EmptyState title="No attractions are currently available" />}
          </section>

          {/* hotels */}
          <section className="pt-24">
            <Reveal>
              <SectionHeading
                eyebrow="Where you'll sleep"
                title="Recommended hotels & resorts"
                action={<Link to="/hotels" className="text-sm text-primary hover:underline">All stays →</Link>}
              />
            </Reveal>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {loadingHotels ? <CardSkeleton count={3} /> : hotels?.map((h, i) => (
                <Reveal key={h.id} delay={i * 0.05}><HotelCard hotel={h} /></Reveal>
              ))}
            </div>
            {!loadingHotels && !hotels?.length && <EmptyState title="No hotels are currently available" />}
          </section>

          {/* why us */}
          <section className="pt-24">
            <Reveal><SectionHeading eyebrow="Why Royal Voyage" title="Travel planned properly" /></Reveal>
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { icon: Sparkles, t: "Curated, not scraped", d: "Every stay and experience is chosen by our specialists." },
                { icon: Wallet, t: "Clear pricing", d: "One breakdown — package, stay, extras, tax. Nothing hidden." },
                { icon: ShieldCheck, t: "Protected bookings", d: "Capacity-checked reservations and a fair cancellation policy." },
                { icon: Headset, t: "Support that answers", d: "Specialists before, during and after your journey." },
              ].map((f, i) => (
                <Reveal key={f.t} delay={i * 0.05}>
                  <div className="h-full rounded-3xl glass p-6 hover-lift">
                    <f.icon className="mb-4 h-6 w-6 text-primary" />
                    <div className="font-display text-lg">{f.t}</div>
                    <p className="mt-2 text-sm text-muted-foreground">{f.d}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </section>

          {/* reviews */}
          {!!reviews?.length && (
            <section className="pt-24">
              <Reveal><SectionHeading eyebrow="Traveller stories" title="What our guests say" /></Reveal>
              <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
                {reviews.slice(0, 6).map((r, i) => (
                  <Reveal key={r.id} delay={i * 0.05}><ReviewCard review={r} /></Reveal>
                ))}
              </div>
            </section>
          )}

          <section className="mt-24 overflow-hidden rounded-[2rem] glass-strong px-6 py-16 text-center">
            <h2 className="font-display text-3xl sm:text-4xl">Ready when you are</h2>
            <p className="mx-auto mt-3 max-w-lg text-sm text-muted-foreground">
              Pick a package, shape the itinerary around you, and we'll take care of the rest.
            </p>
            <Link
              to="/packages"
              search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }}
              className="mt-8 inline-block rounded-full bg-primary px-7 py-3 text-sm font-medium text-primary-foreground transition hover:opacity-90"
            >
              Explore packages
            </Link>
          </section>
        </div>
      </PageTransition>
    </SiteShell>
  );
}
