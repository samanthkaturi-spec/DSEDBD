import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { CalendarCheck, Clock, CreditCard, Heart } from "lucide-react";
import { AuthGate, SiteShell } from "@/components/site-header";
import { TripCard, PackageCard, EmptyState } from "@/components/cards";
import { PageTransition } from "@/components/motion";
import { useAuth } from "@/lib/auth";
import { daysUntil, inr } from "@/lib/format";
import { listMyBookings, listPayments, listSavedTrips } from "@/lib/api/travel";

export const Route = createFileRoute("/trips/")({
  head: () => ({ meta: [
    { title: "My Trips — Royal Voyage" },
    { name: "description", content: "View upcoming and past trips, confirmations, payments, saved packages and reviews." },
    { property: "og:title", content: "My Trips — Royal Voyage" },
    { property: "og:description", content: "Your Royal Voyage bookings and saved journeys." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ]}),
  component: () => <AuthGate><TripsPage /></AuthGate>,
});

function TripsPage() {
  const { user, profile } = useAuth();
  const userId = user?.id;
  const { data: bookings = [], isLoading } = useQuery({ queryKey: ["my-bookings", userId], enabled: !!userId, queryFn: () => userId ? listMyBookings(userId) : Promise.resolve([]) });
  const { data: saved = [] } = useQuery({ queryKey: ["saved-trips", userId], enabled: !!userId, queryFn: () => userId ? listSavedTrips(userId) : Promise.resolve([]) });
  const { data: payments = [] } = useQuery({ queryKey: ["payments", userId], enabled: !!userId, queryFn: () => userId ? listPayments(userId) : Promise.resolve([]) });
  const now = new Date().toISOString().slice(0, 10);
  const upcoming = useMemo(() => bookings.filter((b) => b.end_date >= now && b.status !== "cancelled"), [bookings, now]);
  const past = useMemo(() => bookings.filter((b) => !upcoming.includes(b)), [bookings, upcoming]);
  const spend = bookings.filter((b) => b.status !== "cancelled").reduce((sum, b) => sum + Number(b.total_amount), 0);

  return <SiteShell><PageTransition><main className="mx-auto max-w-7xl px-6 py-12">
    <div className="flex flex-wrap items-end justify-between gap-4"><div><div className="text-xs uppercase tracking-[0.2em] text-primary">Traveller dashboard</div><h1 className="mt-2 font-display text-4xl sm:text-5xl">Welcome, {profile?.full_name?.split(" ")[0] || "traveller"}</h1></div><Link to="/packages" search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }} className="rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground">Plan another trip</Link></div>
    <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Stat icon={CalendarCheck} label="Total bookings" value={String(bookings.length)} />
      <Stat icon={Clock} label="Upcoming trips" value={String(upcoming.length)} />
      <Stat icon={Heart} label="Saved trips" value={String(saved.length)} />
      <Stat icon={CreditCard} label="Booked value" value={inr(spend)} />
    </div>
    <section className="pt-16"><h2 className="font-display text-3xl">Upcoming trips</h2><div className="mt-6 grid gap-4">{isLoading ? <div className="h-36 animate-pulse rounded-3xl bg-muted/40" /> : upcoming.map((b) => <TripCard key={b.id} booking={b} countdown={daysUntil(b.start_date)} />)}</div>{!isLoading && !upcoming.length && <div className="mt-6"><EmptyState title="No upcoming journeys" hint="Your next escape starts in the package catalogue." action={<Link to="/packages" search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }} className="rounded-full bg-primary px-6 py-2.5 text-sm text-primary-foreground">Find a trip</Link>} /></div>}</section>
    {!!past.length && <section className="pt-16"><h2 className="font-display text-3xl">Past & cancelled trips</h2><div className="mt-6 grid gap-4">{past.map((b) => <TripCard key={b.id} booking={b} />)}</div></section>}
    <section className="pt-16"><h2 className="font-display text-3xl">Saved trips</h2>{saved.length ? <div className="mt-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">{saved.map((s) => <PackageCard key={s.id} pkg={s.package} saved />)}</div> : <div className="mt-6"><EmptyState title="Your wishlist is empty" hint="Save packages while browsing to compare them here." /></div>}</section>
    <section className="pt-16"><h2 className="font-display text-3xl">Payments</h2>{payments.length ? <div className="mt-6 overflow-x-auto rounded-3xl glass"><table className="w-full min-w-[620px] text-left text-sm"><thead className="border-b border-border/50 text-xs uppercase tracking-wider text-muted-foreground"><tr><th className="p-4">Reference</th><th className="p-4">Package</th><th className="p-4">Method</th><th className="p-4">Status</th><th className="p-4 text-right">Amount</th></tr></thead><tbody>{payments.map((p: any) => <tr key={p.id} className="border-b border-border/30 last:border-0"><td className="p-4">{p.reference}</td><td className="p-4 text-muted-foreground">{p.booking?.package?.name}</td><td className="p-4 capitalize text-muted-foreground">{String(p.method).replace(/_/g," ")}</td><td className="p-4 text-primary">{p.status}</td><td className="p-4 text-right font-display text-lg">{inr(p.amount)}</td></tr>)}</tbody></table></div> : <div className="mt-6"><EmptyState title="No payment records yet" /></div>}</section>
  </main></PageTransition></SiteShell>;
}
function Stat({ icon: Icon, label, value }: { icon: typeof CalendarCheck; label: string; value: string }) { return <div className="rounded-3xl glass p-5"><Icon className="h-5 w-5 text-primary" /><div className="mt-4 font-display text-3xl text-gradient-gold">{value}</div><div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{label}</div></div>; }
