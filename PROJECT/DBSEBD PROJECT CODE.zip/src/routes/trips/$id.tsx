import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, Download, CalendarDays, MapPin, BedDouble, Users, CreditCard, MessageSquare, XCircle } from "lucide-react";
import { toast } from "sonner";
import { AuthGate, SiteShell } from "@/components/site-header";
import { EmptyState, Stars } from "@/components/cards";
import { ItineraryTimeline, toCustomStops } from "@/components/itinerary-timeline";
import { useAuth } from "@/lib/auth";
import { cancelBooking, getBooking, listItinerary, submitReview } from "@/lib/api/travel";
import { inr, shortDate } from "@/lib/format";

export const Route = createFileRoute("/trips/$id")({
  validateSearch: (s: Record<string, unknown>) => ({ confirmed: s.confirmed === true || s.confirmed === "true" }),
  head: () => ({ meta: [
    { title: "Trip Details & Booking Confirmation — Royal Voyage" },
    { name: "description", content: "View itinerary, hotel, payment summary and printable booking confirmation." },
    { property: "og:title", content: "Trip Details — Royal Voyage" },
    { property: "og:description", content: "Your booking confirmation and travel itinerary." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ]}),
  component: () => <AuthGate><TripDetail /></AuthGate>,
});

function TripDetail() {
  const { id } = Route.useParams();
  const { confirmed } = Route.useSearch();
  const { user, profile } = useAuth();
  const qc = useQueryClient();
  const [review, setReview] = useState({ rating: 5, comment: "" });
  const [busy, setBusy] = useState(false);
  const { data: booking, isLoading } = useQuery({ queryKey: ["booking", id], queryFn: () => getBooking(id) });
  const pkgId = booking?.package_id;
  const { data: itinerary = [] } = useQuery({ queryKey: ["itinerary", pkgId], enabled: !!pkgId, queryFn: () => pkgId ? listItinerary(pkgId) : Promise.resolve([]) });
  if (isLoading) return <SiteShell><div className="grid min-h-[70vh] place-items-center text-muted-foreground">Loading your confirmation…</div></SiteShell>;
  if (!booking) return <SiteShell><div className="mx-auto max-w-3xl px-6 py-24"><EmptyState title="Booking not found" hint="This booking may not belong to your account." action={<Link to="/trips" className="rounded-full bg-primary px-6 py-2.5 text-sm text-primary-foreground">My trips</Link>} /></div></SiteShell>;
  const currentBooking = booking;

  async function cancel() { if (!window.confirm("Cancel this booking? The cancellation policy will apply.")) return; setBusy(true); try { await cancelBooking(currentBooking.id); await qc.invalidateQueries({ queryKey: ["booking", id] }); toast.success("Booking cancelled"); } catch (e) { toast.error(e instanceof Error ? e.message : "Could not cancel"); } finally { setBusy(false); } }
  async function sendReview(e: React.FormEvent) { e.preventDefault(); if (!user || !review.comment.trim()) return toast.error("Write a short review first."); if (!profile?.full_name.trim()) return toast.error("Add your name to your profile before publishing a review."); setBusy(true); try { await submitReview({ userId: user.id, packageId: currentBooking.package_id, hotelId: currentBooking.hotel_id, rating: review.rating, comment: review.comment.trim(), reviewerName: profile.full_name }); toast.success("Thank you — your review is live"); setReview({ rating: 5, comment: "" }); } catch (e) { toast.error(e instanceof Error ? e.message : "Could not publish review"); } finally { setBusy(false); } }

  return <SiteShell><main className="mx-auto max-w-6xl px-6 py-10">
    {confirmed && <div className="mb-8 flex items-start gap-4 rounded-3xl border border-primary/40 bg-primary/10 p-6"><CheckCircle2 className="h-7 w-7 shrink-0 text-primary" /><div><h1 className="font-display text-2xl">Booking confirmed</h1><p className="mt-1 text-sm text-muted-foreground">Demo payment recorded successfully. No real money was charged.</p></div></div>}
    <section id="booking-confirmation" className="rounded-3xl glass-strong p-6 sm:p-9">
      <div className="flex flex-wrap items-start justify-between gap-4"><div><div className="text-xs uppercase tracking-[0.2em] text-primary">Digital booking confirmation</div><h1 className="mt-2 font-display text-3xl sm:text-4xl">{booking.package?.name}</h1><div className="mt-2 text-sm text-muted-foreground">Booking ID: {booking.booking_ref}</div></div><span className="rounded-full border border-primary/50 px-4 py-2 text-xs uppercase tracking-wider text-primary">{booking.status.replace(/_/g," ")}</span></div>
      <div className="mt-8 grid gap-5 border-y border-border/40 py-7 sm:grid-cols-2 lg:grid-cols-4"><Fact icon={CalendarDays} label="Travel dates" value={`${shortDate(booking.start_date)} — ${shortDate(booking.end_date)}`} /><Fact icon={MapPin} label="Destination" value={`${booking.package?.state?.name ? `${booking.package.state.name}, ` : ""}${booking.package?.country?.name ?? ""}`} />{booking.hotel?.name && <Fact icon={BedDouble} label="Hotel" value={booking.hotel.name} />}<Fact icon={Users} label="Travellers" value={`${booking.travellers} travellers · ${booking.rooms_count} room${booking.rooms_count > 1 ? "s" : ""}`} /></div>
      <div className="mt-7 flex flex-wrap items-end justify-between gap-5">{profile?.full_name && <div><div className="text-xs uppercase tracking-wider text-muted-foreground">Traveller</div><div className="mt-1">{profile.full_name}</div></div>}<div className="ml-auto text-right"><div className="inline-flex items-center gap-1 text-xs text-primary"><CreditCard className="h-3.5 w-3.5" /> Demo payment: paid</div><div className="mt-1 font-display text-3xl text-gradient-gold">{inr(booking.total_amount)}</div></div></div>
    </section>
    <div className="mt-5 flex flex-wrap gap-3"><button onClick={() => window.print()} className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground"><Download className="h-4 w-4" />Download / print confirmation</button>{booking.package?.slug && <Link to="/book/$slug" params={{ slug: booking.package.slug }} search={{ customize: true }} className="rounded-full border border-primary/50 px-5 py-2.5 text-sm text-primary">Modify booking</Link>}{booking.status !== "cancelled" && <button disabled={busy} onClick={cancel} className="inline-flex items-center gap-2 rounded-full border border-destructive/60 px-5 py-2.5 text-sm text-destructive"><XCircle className="h-4 w-4" />Cancel booking</button>}</div>
    <section className="pt-16"><h2 className="mb-6 font-display text-3xl">Your itinerary</h2><ItineraryTimeline stops={toCustomStops(itinerary)} /></section>
    <section className="pt-16"><div className="rounded-3xl glass p-6 sm:p-8"><div className="flex items-center gap-3"><MessageSquare className="h-5 w-5 text-primary" /><h2 className="font-display text-2xl">Review this journey</h2></div><form onSubmit={sendReview} className="mt-5"><div className="flex items-center gap-3"><Stars value={review.rating} /><select value={review.rating} onChange={(e) => setReview({ ...review, rating: Number(e.target.value) })} className="rounded-xl border border-border bg-background px-3 py-2 text-sm">{[5,4,3,2,1].map((n) => <option key={n} value={n}>{n} stars</option>)}</select></div><textarea value={review.comment} onChange={(e) => setReview({ ...review, comment: e.target.value })} rows={4} placeholder="What stood out about your trip?" className="mt-4 w-full resize-none rounded-2xl border border-border bg-background/60 p-4 text-sm outline-none focus:border-primary" /><button disabled={busy} className="mt-4 rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground disabled:opacity-60">Publish review</button></form></div></section>
  </main></SiteShell>;
}
function Fact({ icon: Icon, label, value }: { icon: typeof CalendarDays; label: string; value: string }) { return <div><Icon className="h-4 w-4 text-primary" /><div className="mt-3 text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div><div className="mt-1 text-sm">{value}</div></div>; }
