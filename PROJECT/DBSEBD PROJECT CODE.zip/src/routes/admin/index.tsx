import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { BarChart3, BookOpen, CircleDollarSign, Globe2, Hotel, MapPin, Package, Star, Users, Trash2, Pencil, Plus, Check, X } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { toast } from "sonner";
import { AdminGate, SiteShell } from "@/components/site-header";
import { supabase } from "@/integrations/supabase/client";
import { inr, shortDate } from "@/lib/format";

export const Route = createFileRoute("/admin/")({
  head: () => ({ meta: [
    { title: "Travel Operations Admin — Royal Voyage" },
    { name: "description", content: "Administer destinations, packages, hotels, bookings, payments, users and traveller reviews." },
    { property: "og:title", content: "Royal Voyage Admin" },
    { property: "og:description", content: "Travel catalogue and booking operations." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ]}),
  component: () => <AdminGate><AdminPage /></AdminGate>,
});

type Tab = "bookings" | "packages" | "destinations" | "hotels" | "attractions" | "users" | "payments" | "reviews";
const TABS: { id: Tab; label: string; icon: typeof BookOpen }[] = [
  { id:"bookings", label:"Bookings", icon:BookOpen }, { id:"packages", label:"Packages", icon:Package }, { id:"destinations", label:"Destinations", icon:Globe2 }, { id:"hotels", label:"Hotels", icon:Hotel }, { id:"attractions", label:"Attractions", icon:MapPin }, { id:"users", label:"Users", icon:Users }, { id:"payments", label:"Payments", icon:CircleDollarSign }, { id:"reviews", label:"Reviews", icon:Star },
];
const TABLES: Record<Tab, string> = { bookings:"bookings", packages:"travel_packages", destinations:"cities", hotels:"hotels", attractions:"tourist_places", users:"profiles", payments:"payments", reviews:"reviews" };
const FIELDS: Record<Tab, string[]> = { bookings:["booking_ref","status","start_date","total_amount"], packages:["name","duration_days","price","rating"], destinations:["name","best_season","recommended_days","daily_budget"], hotels:["name","star_rating","rating","address"], attractions:["name","category","entry_fee","status"], users:["full_name","email","phone"], payments:["reference","method","status","amount"], reviews:["reviewer_name","rating","comment","created_at"] };

async function snapshot() {
  const [bookings, packages, destinations, hotels, attractions, users, payments, reviews] = await Promise.all([
    supabase.from("bookings").select("*, package:travel_packages(name)"), supabase.from("travel_packages").select("*").order("name"), supabase.from("cities").select("*, state:states(name)").order("name"), supabase.from("hotels").select("*, city:cities(name)").order("name"), supabase.from("tourist_places").select("*, city:cities(name)").order("name"), supabase.from("profiles").select("*").order("created_at", { ascending:false }), supabase.from("payments").select("*, booking:bookings(booking_ref)"), supabase.from("reviews").select("*, package:travel_packages(name)").order("created_at", { ascending:false }),
  ]);
  const all = { bookings, packages, destinations, hotels, attractions, users, payments, reviews };
  const failure = Object.values(all).find((r) => r.error)?.error;
  if (failure) throw new Error(failure.message);
  return Object.fromEntries(Object.entries(all).map(([k,r]) => [k,r.data ?? []])) as Record<Tab, any[]>;
}

function AdminPage() {
  const [tab,setTab] = useState<Tab>("bookings"); const [editing,setEditing] = useState<any | null>(null); const [creating,setCreating] = useState(false); const qc = useQueryClient();
  const { data, isLoading, error } = useQuery({ queryKey:["admin-snapshot"], queryFn:snapshot });
  const bookings = data?.bookings ?? []; const payments = data?.payments ?? []; const users = data?.users ?? [];
  const revenue = payments.filter((p:any) => p.status === "paid").reduce((s:number,p:any) => s + Number(p.amount),0);
  const avgRating = data?.reviews?.length ? data.reviews.reduce((s:number,r:any) => s + Number(r.rating),0) / data.reviews.length : 0;
  const chart = useMemo(() => { const m = new Map<string,number>(); bookings.forEach((b:any) => { const n=b.package?.name??"Other"; m.set(n,(m.get(n)??0)+1); }); return [...m].map(([name,value])=>({name:name.split(" ").slice(0,2).join(" "),value})).sort((a,b)=>b.value-a.value).slice(0,6); },[bookings]);
  const rows = data?.[tab] ?? [];
  async function remove(row:any) { if (!window.confirm("Delete this record?")) return; const { error } = await supabase.from(TABLES[tab] as any).delete().eq("id",row.id); if(error)return toast.error(error.message); toast.success("Deleted"); qc.invalidateQueries({queryKey:["admin-snapshot"]}); }
  async function save(row:any) { const payload=Object.fromEntries(FIELDS[tab].filter((f)=>f!=="created_at"&&row[f]!==undefined).map((f)=>[f,coerce(f,row[f])])); const request=row.id?supabase.from(TABLES[tab] as any).update(payload as never).eq("id",row.id):supabase.from(TABLES[tab] as any).insert(payload as never); const {error}=await request; if(error)return toast.error(error.message); toast.success(row.id?"Updated":"Created"); setEditing(null); setCreating(false); qc.invalidateQueries({queryKey:["admin-snapshot"]}); }

  return <SiteShell><main className="mx-auto max-w-7xl px-6 py-10">
    <div className="flex items-center gap-3"><BarChart3 className="h-6 w-6 text-primary" /><div><div className="text-xs uppercase tracking-[0.2em] text-primary">Operations</div><h1 className="font-display text-4xl">Admin dashboard</h1></div></div>
    {error && <div className="mt-6 rounded-2xl border border-destructive/50 p-4 text-sm text-destructive">{error.message}</div>}
    <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4"><Stat icon={BookOpen} label="Total bookings" value={String(bookings.length)} /><Stat icon={CircleDollarSign} label="Revenue" value={inr(revenue)} /><Stat icon={Users} label="Active users" value={String(users.length)} /><Stat icon={Star} label="Average rating" value={avgRating.toFixed(1)} /></div>
    <div className="mt-8 rounded-3xl glass p-6"><h2 className="font-display text-xl">Most booked packages</h2><div className="mt-5 h-64"><ResponsiveContainer width="100%" height="100%"><BarChart data={chart}><XAxis dataKey="name" stroke="currentColor" fontSize={10}/><YAxis stroke="currentColor" fontSize={10} allowDecimals={false}/><Tooltip contentStyle={{background:"var(--card)",border:"1px solid var(--border)",borderRadius:8}}/><Bar dataKey="value" fill="var(--primary)" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div></div>
    <div className="mt-10 flex gap-2 overflow-x-auto pb-2">{TABS.map((t)=><button key={t.id} onClick={()=>{setTab(t.id);setEditing(null);setCreating(false);}} className={`inline-flex shrink-0 items-center gap-2 rounded-full border px-4 py-2 text-sm ${tab===t.id?"border-primary bg-primary/10 text-primary":"border-border text-muted-foreground"}`}><t.icon className="h-4 w-4"/>{t.label}</button>)}</div>
    <section className="mt-4 overflow-hidden rounded-3xl glass"><div className="flex items-center justify-between border-b border-border/40 p-5"><div><h2 className="font-display text-2xl capitalize">{tab}</h2><p className="text-xs text-muted-foreground">{rows.length} records</p></div>{!(["bookings","users","payments","reviews"] as Tab[]).includes(tab)&&<button onClick={()=>{setCreating(true);setEditing(Object.fromEntries(FIELDS[tab].map((f)=>[f,""])));}} className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm text-primary-foreground"><Plus className="h-4 w-4"/>Add</button>}</div>
      {isLoading?<div className="p-10 text-center text-muted-foreground">Loading operations data…</div>:<div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left text-sm"><thead className="border-b border-border/40 text-[11px] uppercase tracking-wider text-muted-foreground"><tr>{FIELDS[tab].map((f)=><th key={f} className="p-4">{f.replace(/_/g," ")}</th>)}<th className="p-4 text-right">Actions</th></tr></thead><tbody>{creating&&editing&&<EditRow fields={FIELDS[tab]} row={editing} setRow={setEditing} onSave={()=>save(editing)} onCancel={()=>{setCreating(false);setEditing(null);}}/>}{rows.map((r:any)=>editing?.id===r.id?<EditRow key={r.id} fields={FIELDS[tab]} row={editing} setRow={setEditing} onSave={()=>save(editing)} onCancel={()=>setEditing(null)}/>:<tr key={r.id} className="border-b border-border/30 last:border-0">{FIELDS[tab].map((f)=><td key={f} className="max-w-xs truncate p-4 text-muted-foreground">{render(f,r[f])}</td>)}<td className="p-4"><div className="flex justify-end gap-2">{tab!=="payments"&&<button aria-label="Edit" onClick={()=>setEditing({...r})} className="rounded-lg border border-border p-2 hover:text-primary"><Pencil className="h-3.5 w-3.5"/></button>}{!(["bookings","payments","users"] as Tab[]).includes(tab)&&<button aria-label="Delete" onClick={()=>remove(r)} className="rounded-lg border border-border p-2 hover:text-destructive"><Trash2 className="h-3.5 w-3.5"/></button>}</div></td></tr>)}</tbody></table></div>}
    </section>
  </main></SiteShell>;
}
function Stat({icon:Icon,label,value}:{icon:typeof BookOpen;label:string;value:string}){return <div className="rounded-3xl glass p-5"><Icon className="h-5 w-5 text-primary"/><div className="mt-4 font-display text-3xl text-gradient-gold">{value}</div><div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{label}</div></div>}
function EditRow({fields,row,setRow,onSave,onCancel}:{fields:string[];row:any;setRow:(r:any)=>void;onSave:()=>void;onCancel:()=>void}){return <tr className="border-b border-primary/30 bg-primary/5">{fields.map((f)=><td key={f} className="p-2"><input disabled={f==="created_at"} value={row[f]??""} onChange={(e)=>setRow({...row,[f]:e.target.value})} className="w-full min-w-28 rounded-lg border border-border bg-background px-2 py-2 text-xs disabled:opacity-50"/></td>)}<td className="p-2"><div className="flex justify-end gap-2"><button aria-label="Save" onClick={onSave} className="rounded-lg border border-primary p-2 text-primary"><Check className="h-3.5 w-3.5"/></button><button aria-label="Cancel" onClick={onCancel} className="rounded-lg border border-border p-2"><X className="h-3.5 w-3.5"/></button></div></td></tr>}
function coerce(f:string,v:any){return ["price","rating","duration_days","recommended_days","daily_budget","star_rating","entry_fee","amount","total_amount"].includes(f)?Number(v):v}
function render(f:string,v:any){if(f.includes("date")||f==="created_at")return shortDate(v);if(["price","daily_budget","entry_fee","amount","total_amount"].includes(f))return inr(v);return String(v??"—")}
