import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { SiteShell } from "@/components/site-header";
import { PageTransition, Reveal } from "@/components/motion";
import { HotelCard, CardSkeleton, EmptyState, SectionHeading } from "@/components/cards";
import { SearchFilters, emptyFilters, type Filters } from "@/components/search-filters";
import { listCities, listCountries, listHotels, listStates } from "@/lib/api/travel";

export const Route = createFileRoute("/hotels/")({
  head: () => ({
    meta: [
      { title: "Hotels & Resorts — Royal Voyage" },
      { name: "description", content: "Handpicked 3, 4 and 5 star hotels and luxury resorts across our destinations, with room types, amenities and nightly rates." },
      { property: "og:title", content: "Hotels & Resorts — Royal Voyage" },
      { property: "og:description", content: "Every stay we book, with rooms, amenities and rates." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HotelsPage,
});

function HotelsPage() {
  const [filters, setFilters] = useState<Filters>(emptyFilters);
  const [minStars, setMinStars] = useState(0);

  const { data: countries = [] } = useQuery({ queryKey: ["countries"], queryFn: listCountries });
  const { data: states = [] } = useQuery({
    queryKey: ["states", filters.countryId], queryFn: () => listStates(filters.countryId || undefined),
  });
  const { data: cities = [] } = useQuery({ queryKey: ["all-cities"], queryFn: () => listCities({}) });
  const { data: hotels, isLoading } = useQuery({ queryKey: ["all-hotels"], queryFn: () => listHotels({}) });

  const stateIds = useMemo(() => new Set(states.map((s) => s.id)), [states]);
  const cityById = useMemo(() => new Map(cities.map((c) => [c.id, c])), [cities]);

  const results = (hotels ?? []).filter((h) => {
    if (filters.search && !h.name.toLowerCase().includes(filters.search.toLowerCase())) return false;
    if (minStars && h.star_rating < minStars) return false;
    const city = cityById.get(h.city_id);
    if (filters.stateId) return city?.state_id === filters.stateId;
    if (filters.countryId) return city ? stateIds.has(city.state_id) : false;
    return true;
  });

  return (
    <SiteShell>
      <PageTransition>
        <div className="mx-auto max-w-7xl px-6 py-14">
          <Reveal>
            <SectionHeading
              eyebrow="Where you'll stay"
              title="Hotels & resorts"
              subtitle="Choose your category now, or upgrade later while customising a package — the trip price updates instantly."
            />
          </Reveal>

          <div className="grid gap-8 lg:grid-cols-[300px_1fr]">
            <div className="space-y-4 lg:sticky lg:top-24 lg:self-start">
              <SearchFilters
                filters={filters} onChange={setFilters} countries={countries} states={states} showPackageFilters={false}
              />
              <div className="rounded-3xl glass p-5">
                <div className="mb-3 text-xs uppercase tracking-[0.2em] text-primary">Star rating</div>
                <div className="flex flex-wrap gap-2">
                  {[0, 3, 4, 5].map((s) => (
                    <button
                      key={s}
                      onClick={() => setMinStars(s)}
                      className={`rounded-full border px-3 py-1.5 text-xs transition ${minStars === s ? "border-primary text-primary" : "border-border/60 text-muted-foreground hover:border-primary/50"}`}
                    >
                      {s === 0 ? "Any" : `${s}★ and up`}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <div className="mb-5 text-sm text-muted-foreground">{results.length} properties</div>
              <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                {isLoading ? <CardSkeleton count={6} /> : results.map((h) => <HotelCard key={h.id} hotel={h} />)}
              </div>
              {!isLoading && results.length === 0 && (
                <EmptyState title="No stays match" hint="Try a different region or lower the star rating." />
              )}
            </div>
          </div>
        </div>
      </PageTransition>
    </SiteShell>
  );
}
