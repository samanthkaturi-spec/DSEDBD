import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { SiteShell } from "@/components/site-header";
import { PageTransition, Reveal } from "@/components/motion";
import { AttractionCard, CardSkeleton, EmptyState, SectionHeading } from "@/components/cards";
import { SearchFilters, emptyFilters, type Filters } from "@/components/search-filters";
import { listAttractions, listCities, listCountries, listStates } from "@/lib/api/travel";

export const Route = createFileRoute("/attractions/")({
  head: () => ({
    meta: [
      { title: "Attractions & Things To Do — Royal Voyage" },
      { name: "description", content: "Forts, beaches, museums and national parks across our destinations — with opening hours, entry fees and how long to spend." },
      { property: "og:title", content: "Attractions — Royal Voyage" },
      { property: "og:description", content: "Explore the sights our itineraries are built around." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AttractionsPage,
});

function AttractionsPage() {
  const [filters, setFilters] = useState<Filters>(emptyFilters);
  const [category, setCategory] = useState("");

  const { data: countries = [] } = useQuery({ queryKey: ["countries"], queryFn: listCountries });
  const { data: states = [] } = useQuery({
    queryKey: ["states", filters.countryId], queryFn: () => listStates(filters.countryId || undefined),
  });
  const { data: cities = [] } = useQuery({ queryKey: ["all-cities"], queryFn: () => listCities({}) });
  const { data: places, isLoading } = useQuery({ queryKey: ["all-places"], queryFn: () => listAttractions({}) });

  const stateIds = useMemo(() => new Set(states.map((s) => s.id)), [states]);
  const cityById = useMemo(() => new Map(cities.map((c) => [c.id, c])), [cities]);
  const categories = useMemo(
    () => Array.from(new Set((places ?? []).map((p) => p.category))).sort(),
    [places],
  );

  const results = (places ?? []).filter((p) => {
    if (filters.search && !p.name.toLowerCase().includes(filters.search.toLowerCase())) return false;
    if (category && p.category !== category) return false;
    const city = cityById.get(p.city_id);
    if (filters.stateId) return city?.state_id === filters.stateId;
    if (filters.countryId) return city ? stateIds.has(city.state_id) : false;
    return true;
  });

  return (
    <SiteShell>
      <PageTransition>
        <div className="mx-auto max-w-7xl px-6 py-14">
          <Reveal>
            <SectionHeading
              eyebrow="Things to do"
              title="Attractions worth planning around"
              subtitle="Every sight below feeds our itineraries — hours, ticket prices and visit lengths come straight from the catalogue."
            />
          </Reveal>

          <div className="grid gap-8 lg:grid-cols-[300px_1fr]">
            <div className="space-y-4 lg:sticky lg:top-24 lg:self-start">
              <SearchFilters
                filters={filters} onChange={setFilters} countries={countries} states={states} showPackageFilters={false}
              />
              <div className="rounded-3xl glass p-5">
                <div className="mb-3 text-xs uppercase tracking-[0.2em] text-primary">Category</div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setCategory("")}
                    className={`rounded-full border px-3 py-1.5 text-xs transition ${!category ? "border-primary text-primary" : "border-border/60 text-muted-foreground hover:border-primary/50"}`}
                  >
                    All
                  </button>
                  {categories.map((c) => (
                    <button
                      key={c}
                      onClick={() => setCategory(c)}
                      className={`rounded-full border px-3 py-1.5 text-xs capitalize transition ${category === c ? "border-primary text-primary" : "border-border/60 text-muted-foreground hover:border-primary/50"}`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <div className="mb-5 text-sm text-muted-foreground">{results.length} attractions</div>
              <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                {isLoading ? <CardSkeleton count={6} /> : results.map((p) => <AttractionCard key={p.id} place={p} />)}
              </div>
              {!isLoading && results.length === 0 && (
                <EmptyState title="Nothing matches those filters" hint="Try a broader region or clear the category." />
              )}
            </div>
          </div>
        </div>
      </PageTransition>
    </SiteShell>
  );
}
