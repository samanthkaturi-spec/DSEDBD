import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck, HeartHandshake, Globe2, Headset } from "lucide-react";
import { SiteShell } from "@/components/site-header";
import { Reveal, PageTransition } from "@/components/motion";
import { SectionHeading } from "@/components/cards";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Royal Voyage — Curated Travel Package Booking" },
      { name: "description", content: "Who we are, how we plan trips, our cancellation policy and answers to common questions about booking with Royal Voyage." },
      { property: "og:title", content: "About Royal Voyage" },
      { property: "og:description", content: "Curated travel experiences, handpicked stays and effortless booking." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AboutPage,
});

const VALUES = [
  { icon: Globe2, title: "Handpicked destinations", body: "Every city, stay and experience in our catalogue is researched and curated before it is published." },
  { icon: HeartHandshake, title: "Plans that bend to you", body: "Change hotels, travellers, dates or activities and watch the price update instantly — no hidden recalculation." },
  { icon: ShieldCheck, title: "Transparent pricing", body: "One clear breakdown: package, stay, extras and tax. No surprise line items at checkout." },
  { icon: Headset, title: "Human support", body: "Trip specialists on call before you leave, while you travel and after you return." },
];

const FAQS = [
  { q: "Are the prices shown live?", a: "Every displayed price is read from the current catalogue database. Airline and third-party hotel inventory feeds are not connected yet." },
  { q: "Is payment real?", a: "No. Checkout currently runs in demo mode — no gateway is connected, nothing is charged and card details are never stored or transmitted. Bookings are still recorded so you can see the full confirmation and trip-tracking flow." },
  { q: "Can I change my trip after booking?", a: "Yes. Open the trip from My Trips and use Modify booking to speak to a specialist, or cancel within the policy window." },
  { q: "How do I get my confirmation?", a: "Every confirmed booking has a printable confirmation you can download from the trip page." },
  { q: "Who can leave a review?", a: "Only signed-in travellers with a booking can publish a review, and reviews are shown against the package they booked." },
];

function AboutPage() {
  return (
    <SiteShell>
      <PageTransition>
        <div className="mx-auto max-w-6xl px-6 py-14">
          <Reveal>
            <div className="text-xs uppercase tracking-[0.2em] text-primary">About us</div>
            <h1 className="mt-3 max-w-3xl font-display text-4xl leading-tight sm:text-6xl">
              Travel planned with the <span className="text-gradient-gold">care of a private concierge</span>
            </h1>
            <p className="mt-5 max-w-2xl text-muted-foreground">
              Royal Voyage began as a hospitality service desk and grew into a full travel
              booking portal. The same obsession with detail now shapes entire journeys —
              country to region to city, attraction to itinerary to hotel.
            </p>
          </Reveal>

          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {VALUES.map((v, i) => (
              <Reveal key={v.title} delay={i * 0.06}>
                <div className="h-full rounded-3xl glass p-6 hover-lift">
                  <v.icon className="mb-4 h-6 w-6 text-primary" />
                  <div className="font-display text-lg">{v.title}</div>
                  <p className="mt-2 text-sm text-muted-foreground">{v.body}</p>
                </div>
              </Reveal>
            ))}
          </div>

          <section id="policies" className="mt-20 scroll-mt-24">
            <SectionHeading eyebrow="Good to know" title="Cancellation policy" />
            <div className="grid gap-4 sm:grid-cols-3">
              {[
                { when: "30+ days before departure", what: "Refund terms are confirmed with the booking and depend on the selected package and suppliers." },
                { when: "15–29 days before departure", what: "50% of the trip value is refunded." },
                { when: "Under 15 days", what: "Non-refundable, though dates may be shifted once, subject to availability." },
              ].map((p) => (
                <div key={p.when} className="rounded-3xl glass p-6">
                  <div className="text-sm text-primary">{p.when}</div>
                  <p className="mt-2 text-sm text-muted-foreground">{p.what}</p>
                </div>
              ))}
            </div>
          </section>

          <section id="faqs" className="mt-20 scroll-mt-24">
            <SectionHeading eyebrow="Questions" title="Frequently asked" />
            <div className="grid gap-3">
              {FAQS.map((f) => (
                <details key={f.q} className="group rounded-3xl glass p-6">
                  <summary className="cursor-pointer list-none font-display text-lg marker:hidden">
                    {f.q}
                  </summary>
                  <p className="mt-3 text-sm text-muted-foreground">{f.a}</p>
                </details>
              ))}
            </div>
          </section>

          <section id="contact" className="mt-20 scroll-mt-24">
            <SectionHeading eyebrow="Start planning" title="Explore current journeys" />
            <Link
              to="/packages"
              search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }}
              className="mt-8 inline-block rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition hover:opacity-90"
            >
              Browse travel packages
            </Link>
          </section>
        </div>
      </PageTransition>
    </SiteShell>
  );
}
