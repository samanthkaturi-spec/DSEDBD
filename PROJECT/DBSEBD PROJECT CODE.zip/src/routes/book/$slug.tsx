import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Check, ChevronLeft, ChevronRight, Minus, Plus } from "lucide-react";
import { toast } from "sonner";
import { AuthGate, SiteShell } from "@/components/site-header";
import { HotelCard, EmptyState } from "@/components/cards";
import { BookingSummary } from "@/components/booking-summary";
import { PaymentForm, type PaymentMethod } from "@/components/payment-form";
import { ItineraryTimeline, toCustomStops, type CustomStop } from "@/components/itinerary-timeline";
import { quote } from "@/lib/pricing";
import { useAuth } from "@/lib/auth";
import { createBooking, getPackageBySlug, listHotelsForPackage, listItinerary, notify, type Hotel } from "@/lib/api/travel";

export const Route = createFileRoute("/book/$slug")({
  validateSearch: (s: Record<string, unknown>) => ({ customize: s.customize === true || s.customize === "true" }),
  head: ({ params }) => ({ meta: [
    { title: `Customize ${params.slug.replace(/-/g, " ")} — Royal Voyage` },
    { name: "description", content: "Choose dates, travellers, hotel, activities and extras, then review the live trip estimate and confirm with demo payment." },
    { property: "og:title", content: "Customize Your Trip — Royal Voyage" },
    { property: "og:description", content: "Build your package, select a stay and review transparent pricing." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ]}),
  component: () => <AuthGate><BookPage /></AuthGate>,
});

const inputCls = "w-full rounded-xl border border-border/60 bg-background/60 px-4 py-3 text-sm outline-none focus:border-primary";

function BookPage() {
  const { slug } = Route.useParams();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [step, setStep] = useState(1);
  const today = new Date();
  today.setDate(today.getDate() + 14);
  const [startDate, setStartDate] = useState(today.toISOString().slice(0, 10));
  const [adults, setAdults] = useState(2);
  const [children, setChildren] = useState(0);
  const [roomsCount, setRoomsCount] = useState(1);
  const [mealPreference, setMealPreference] = useState("No preference");
  const [transport, setTransport] = useState("Package transport");
  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null);
  const [roomId, setRoomId] = useState("");
  const addons: string[] = [];
  const [customStops, setCustomStops] = useState<CustomStop[]>([]);
  const [traveller, setTraveller] = useState({ fullName: "", email: "", phone: "", dob: "", nationality: "" });
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: pkg, isLoading } = useQuery({ queryKey: ["package", slug], queryFn: () => getPackageBySlug(slug) });
  const pkgId = pkg?.id;
  const { data: itinerary = [] } = useQuery({ queryKey: ["itinerary", pkgId], enabled: !!pkgId, queryFn: () => pkgId ? listItinerary(pkgId) : Promise.resolve([]) });
  const { data: hotels = [] } = useQuery({ queryKey: ["package-hotels", pkgId], enabled: !!pkg, queryFn: () => pkg ? listHotelsForPackage(pkg) : Promise.resolve([]) });

  useEffect(() => { setCustomStops(toCustomStops(itinerary)); }, [itinerary]);
  useEffect(() => { if (profile) setTraveller((v) => ({ ...v, fullName: profile.full_name, email: profile.email, phone: profile.phone })); }, [profile]);
  useEffect(() => {
    if (!selectedHotel && hotels.length) {
      setSelectedHotel(hotels[0]);
      setRoomId(hotels[0].rooms?.[0]?.id ?? "");
    }
  }, [hotels, selectedHotel]);

  const room = selectedHotel?.rooms?.find((r) => r.id === roomId) ?? null;
  const baseRate = useMemo(() => {
    const rates = hotels.flatMap((h) => h.rooms ?? []).map((r) => Number(r.price_per_night));
    return rates.length ? Math.min(...rates) : 0;
  }, [hotels]);
  const activityCost = customStops.filter((s) => s.removable).reduce((sum, s) => sum + s.cost, 0) * (adults + children);
  const q = quote({ packagePrice: Number(pkg?.price ?? 0), adults, children, nights: pkg?.duration_nights ?? 1, roomsCount, roomPricePerNight: Number(room?.price_per_night ?? baseRate), baseRoomPricePerNight: baseRate, addonIds: addons, activityCost });
  const endDate = (() => { const d = new Date(startDate); d.setDate(d.getDate() + (pkg?.duration_days ?? 1) - 1); return d.toISOString().slice(0, 10); })();

  function chooseHotel(h: Hotel) { setSelectedHotel(h); setRoomId(h.rooms?.[0]?.id ?? ""); }
  function validateTraveller() {
    if (!traveller.fullName.trim() || !/^\S+@\S+\.\S+$/.test(traveller.email) || traveller.phone.trim().length < 7 || !traveller.dob || !traveller.nationality.trim()) {
      toast.error("Complete all traveller details before continuing."); return false;
    }
    return true;
  }
  async function pay(method: PaymentMethod) {
    if (!pkg || !user) return;
    setBusy(true);
    try {
      const booking = await createBooking({ packageId: pkg.id, hotelId: selectedHotel?.id ?? null, roomId: room?.id ?? null, startDate, endDate, adults, children, roomsCount, addons: [...addons, `meal:${mealPreference}`, `transport:${transport}`], packageAmount: q.packageAmount, hotelAmount: q.hotelAmount, addonAmount: q.addonAmount + q.activityAmount, taxes: q.taxes, total: q.total, method, notes: `${notes}\nLead traveller: ${traveller.fullName}; DOB: ${traveller.dob}; Nationality: ${traveller.nationality}`.trim() });
      await notify(user.id, "Booking confirmed", `${pkg.name} is confirmed for ${startDate}. Reference: ${booking.booking_ref}`);
      toast.success("Demo payment complete — booking confirmed");
      navigate({ to: "/trips/$id", params: { id: booking.id }, search: { confirmed: true }, replace: true });
    } catch (e) { toast.error(e instanceof Error ? e.message : "Could not confirm booking"); }
    finally { setBusy(false); }
  }

  if (isLoading) return <SiteShell><div className="grid min-h-[70vh] place-items-center text-muted-foreground">Preparing your trip…</div></SiteShell>;
  if (!pkg) return <SiteShell><div className="mx-auto max-w-3xl px-6 py-24"><EmptyState title="Package unavailable" action={<Link to="/packages" search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }} className="rounded-full bg-primary px-6 py-2.5 text-sm text-primary-foreground">Browse packages</Link>} /></div></SiteShell>;

  const steps = ["Trip", "Hotel", "Itinerary", "Traveller", "Review & pay"];
  return <SiteShell><div className="mx-auto max-w-7xl px-6 py-10">
    <div className="mb-8"><div className="text-xs uppercase tracking-[0.2em] text-primary">Build your journey</div><h1 className="mt-2 font-display text-3xl sm:text-4xl">{pkg.name}</h1></div>
    <div className="mb-10 flex items-center gap-2 overflow-x-auto pb-2">{steps.map((s, i) => <div key={s} className="flex shrink-0 items-center gap-2"><span className={`grid h-8 w-8 place-items-center rounded-full border text-xs ${step > i + 1 ? "border-primary bg-primary text-primary-foreground" : step === i + 1 ? "border-primary text-primary" : "border-border text-muted-foreground"}`}>{step > i + 1 ? <Check className="h-4 w-4" /> : i + 1}</span><span className={`text-xs ${step === i + 1 ? "text-foreground" : "text-muted-foreground"}`}>{s}</span>{i < steps.length - 1 && <span className="mx-2 h-px w-8 bg-border" />}</div>)}</div>

    <div className="grid gap-10 lg:grid-cols-[1fr_360px]">
      <div>
        {step === 1 && <div className="rounded-3xl glass p-6 sm:p-8"><h2 className="font-display text-2xl">Trip preferences</h2><div className="mt-6 grid gap-5 sm:grid-cols-2">
          <label className="text-xs text-muted-foreground">Departure date<input type="date" min={new Date().toISOString().slice(0,10)} className={`${inputCls} mt-1.5`} value={startDate} onChange={(e) => setStartDate(e.target.value)} /></label>
          <label className="text-xs text-muted-foreground">Rooms<input type="number" min={1} max={6} className={`${inputCls} mt-1.5`} value={roomsCount} onChange={(e) => setRoomsCount(Math.max(1, Number(e.target.value)))} /></label>
          <Counter label="Adults" value={adults} min={1} onChange={setAdults} /><Counter label="Children" value={children} min={0} onChange={setChildren} />
          <label className="text-xs text-muted-foreground">Meal preference<select className={`${inputCls} mt-1.5`} value={mealPreference} onChange={(e) => setMealPreference(e.target.value)}><option>No preference</option><option>Vegetarian</option><option>Vegan</option><option>Non-vegetarian</option><option>Jain meals</option></select></label>
          <label className="text-xs text-muted-foreground">Transportation<select className={`${inputCls} mt-1.5`} value={transport} onChange={(e) => setTransport(e.target.value)}><option>Package transport</option><option>Private vehicle upgrade</option><option>Self-arranged</option></select></label>
        </div></div>}

        {step === 2 && <div><h2 className="font-display text-2xl">Choose your stay</h2><p className="mt-2 text-sm text-muted-foreground">Your package includes the base room rate. Only the upgrade difference is added.</p><div className="mt-6 grid gap-6 md:grid-cols-2">{hotels.map((h) => <HotelCard key={h.id} hotel={h} selected={selectedHotel?.id === h.id} onSelect={() => chooseHotel(h)} roomId={selectedHotel?.id === h.id ? roomId : undefined} onRoomChange={(id) => { chooseHotel(h); setRoomId(id); }} />)}</div>{hotels.length === 0 && <EmptyState title="Hotel selection is being arranged" hint="You can continue; our specialist will confirm a stay in your package category." />}</div>}

        {step === 3 && <div><h2 className="font-display text-2xl">Your current itinerary</h2><p className="mt-2 mb-6 text-sm text-muted-foreground">These stops are loaded from the package's current itinerary.</p><ItineraryTimeline stops={customStops} /></div>}

        {step === 4 && <div className="rounded-3xl glass p-6 sm:p-8"><h2 className="font-display text-2xl">Lead traveller</h2><div className="mt-6 grid gap-5 sm:grid-cols-2">{([ ["fullName","Full name","text"], ["email","Email","email"], ["phone","Phone","tel"], ["dob","Date of birth","date"], ["nationality","Nationality","text"] ] as const).map(([k,l,t]) => <label key={k} className="text-xs text-muted-foreground">{l}<input type={t} className={`${inputCls} mt-1.5`} value={traveller[k]} onChange={(e) => setTraveller({ ...traveller, [k]: e.target.value })} /></label>)}<label className="text-xs text-muted-foreground sm:col-span-2">Special requests<textarea rows={4} className={`${inputCls} mt-1.5 resize-none`} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Accessibility, dietary or celebration notes" /></label></div></div>}

        {step === 5 && <div className="space-y-6"><div className="rounded-3xl glass p-6"><h2 className="font-display text-2xl">Review your booking</h2><div className="mt-5 grid gap-4 text-sm sm:grid-cols-2"><Info label="Lead traveller" value={traveller.fullName} /><Info label="Contact" value={`${traveller.email} · ${traveller.phone}`} /><Info label="Meals" value={mealPreference} /><Info label="Transport" value={transport} /></div></div><PaymentForm amount={q.total} busy={busy} onPay={pay} /></div>}

        <div className="mt-8 flex justify-between"><button disabled={step === 1} onClick={() => setStep((s) => Math.max(1, s - 1))} className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-2.5 text-sm disabled:opacity-30"><ChevronLeft className="h-4 w-4" />Back</button>{step < 5 && <button onClick={() => { if (step === 4 && !validateTraveller()) return; setStep((s) => Math.min(5, s + 1)); window.scrollTo({ top: 0, behavior: "smooth" }); }} className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-2.5 text-sm font-medium text-primary-foreground">Continue<ChevronRight className="h-4 w-4" /></button>}</div>
      </div>
      <BookingSummary pkg={pkg} hotel={selectedHotel} room={room} quote={q} startDate={startDate} endDate={endDate} adults={adults} children={children} roomsCount={roomsCount} addonIds={addons} />
    </div>
  </div></SiteShell>;
}

function Counter({ label, value, min, onChange }: { label: string; value: number; min: number; onChange: (n: number) => void }) { return <div><div className="text-xs text-muted-foreground">{label}</div><div className="mt-1.5 flex items-center justify-between rounded-xl border border-border/60 bg-background/60 p-2"><button type="button" aria-label={`Decrease ${label}`} onClick={() => onChange(Math.max(min, value - 1))} className="grid h-8 w-8 place-items-center rounded-lg border border-border"><Minus className="h-3.5 w-3.5" /></button><span className="text-sm">{value}</span><button type="button" aria-label={`Increase ${label}`} onClick={() => onChange(value + 1)} className="grid h-8 w-8 place-items-center rounded-lg border border-border"><Plus className="h-3.5 w-3.5" /></button></div></div>; }
function Info({ label, value }: { label: string; value: string }) { return <div><div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div><div className="mt-1">{value || "—"}</div></div>; }
