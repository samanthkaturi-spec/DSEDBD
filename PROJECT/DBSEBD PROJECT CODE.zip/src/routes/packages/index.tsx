import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { SiteShell } from "@/components/site-header";
import { PageTransition, Reveal } from "@/components/motion";
import { PackageCard, CardSkeleton, EmptyState, SectionHeading } from "@/components/cards";
import { SearchFilters, emptyFilters, type Filters } from "@/components/search-filters";
import { listCountries, listPackages, listStates } from "@/lib/api/travel";

export const Route = createFileRoute("/packages/")({
  validateSearch: (s: Record<string, unknown>) => ({
    country: typeof s.country === "string" ? s.country : undefined,
    state: typeof s.state === "string" ? s.state : undefined,
    start: typeof s.start === "string" ? s.start : undefined,
    travellers: Number(s.travellers) || undefined,
  }),
  head: () => ({ meta: [
    { title: "Travel Packages — Royal Voyage" },
    { name: "description", content: "Compare curated India and UAE travel packages by destination, budget, duration, rating, hotel category and travel style." },
    { property: "og:title", content: "Travel Packages — Royal Voyage" },
    { property: "og:description", content: "Handpicked stays, transfers, sightseeing and day-by-day itineraries." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ]}),
  component: PackagesPage,
});

function PackagesPage() {
  const search = Route.useSearch();
  const [filters, setFilters] = useState<Filters>({ ...emptyFilters, countryId: search.country ?? "", stateId: search.state ?? "" });
  const { data: countries = [] } = useQuery({ queryKey: ["countries"], queryFn: listCountries });
  const { data: states = [] } = useQuery({ queryKey: ["states", filters.countryId], queryFn: () => listStates(filters.countryId || undefined) });
  const { data: packages, isLoading } = useQuery({
    queryKey: ["packages", filters],
    queryFn: () => listPackages({
      countryId: filters.countryId || undefined,
      stateId: filters.stateId || undefined,
      search: filters.search || undefined,
      maxPrice: filters.maxPrice || undefined,
      maxDays: filters.maxDays || undefined,
      minRating: filters.minRating || undefined,
      hotelCategory: filters.hotelCategory || undefined,
      travelStyle: filters.travelStyle || undefined,
    }),
  });

  return <SiteShell><PageTransition>
    <div className="mx-auto max-w-7xl px-6 py-14">
      <Reveal><SectionHeading eyebrow="Current journeys" title="Travel packages" subtitle="Prices and availability below are loaded from the current catalogue." /></Reveal>
      {(search.start || search.travellers) && <div className="mb-6 rounded-2xl border border-primary/30 bg-primary/5 px-5 py-3 text-sm text-muted-foreground">Showing current plans{search.travellers ? ` for ${search.travellers} travellers` : ""}{search.start ? ` from ${search.start}` : ""}. You can change these details before checkout.</div>}
      <div className="grid gap-8 lg:grid-cols-[300px_1fr]">
        <div className="lg:sticky lg:top-24 lg:self-start"><SearchFilters filters={filters} onChange={setFilters} countries={countries} states={states} /></div>
        <div>
          <div className="mb-5 text-sm text-muted-foreground">{packages?.length ?? 0} packages</div>
          <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">{isLoading ? <CardSkeleton count={6} /> : packages?.map((p) => <PackageCard key={p.id} pkg={p} />)}</div>
          {!isLoading && packages?.length === 0 && <EmptyState title="No packages match" hint="Try a higher budget, longer duration or another destination." />}
        </div>
      </div>
    </div>
  </PageTransition></SiteShell>;
}
