import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Check, X, CalendarDays, Bus, Utensils, BedDouble, MapPin, ShieldCheck, ShoppingBag } from "lucide-react";
import { toast } from "sonner";
import { SiteShell } from "@/components/site-header";
import { PageTransition, Reveal } from "@/components/motion";
import { SectionHeading, AttractionCard, ReviewCard, Stars, EmptyState } from "@/components/cards";
import { ItineraryTimeline, toCustomStops } from "@/components/itinerary-timeline";
import { inr } from "@/lib/format";
import { getPackageBySlug, listItinerary, listPackageAttractions, listReviews } from "@/lib/api/travel";
import { useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/packages/$slug")({
  head: ({ params }) => {
    const name = params.slug.replace(/-/g, " ").replace(/\b\w/g, (m) => m.toUpperCase());
    return { meta: [
      { title: `${name} Travel Package — Royal Voyage` },
      { name: "description", content: `View the ${name} itinerary, accommodation, transport, inclusions, cancellation policy and traveller reviews.` },
      { property: "og:title", content: `${name} — Royal Voyage` },
      { property: "og:description", content: "Full itinerary, stays, inclusions and transparent pricing." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ]};
  },
  component: PackagePage,
});

function PackagePage() {
  const { slug } = Route.useParams();
  const { items, addItem } = useCart();
  const { data: pkg, isLoading } = useQuery({ queryKey: ["package", slug], queryFn: () => getPackageBySlug(slug) });
  const pkgId = pkg?.id;
  const { data: itinerary = [] } = useQuery({ queryKey: ["itinerary", pkgId], enabled: !!pkgId, queryFn: () => pkgId ? listItinerary(pkgId) : Promise.resolve([]) });
  const { data: places = [] } = useQuery({ queryKey: ["package-places", pkgId], enabled: !!pkgId, queryFn: () => pkgId ? listPackageAttractions(pkgId) : Promise.resolve([]) });
  const { data: reviews = [] } = useQuery({ queryKey: ["package-reviews", pkgId], enabled: !!pkgId, queryFn: () => pkgId ? listReviews({ packageId: pkgId }) : Promise.resolve([]) });

  if (isLoading) return <SiteShell><div className="mx-auto max-w-7xl animate-pulse px-6 py-12"><div className="h-[55vh] rounded-3xl bg-muted/40" /></div></SiteShell>;
  if (!pkg) return <SiteShell><div className="mx-auto max-w-3xl px-6 py-24"><EmptyState title="Package not found" hint="It may have been retired from our current catalogue." action={<Link to="/packages" search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }} className="rounded-full bg-primary px-6 py-2.5 text-sm text-primary-foreground">Browse packages</Link>} /></div></SiteShell>;

  return <SiteShell><PageTransition>
    <section className="relative">
      <img src={pkg.image_url} alt={pkg.name} className="h-[55vh] min-h-[400px] w-full object-cover opacity-60" />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
      <div className="absolute inset-x-0 bottom-0"><div className="mx-auto max-w-7xl px-6 pb-10">
        <div className="text-xs uppercase tracking-[0.2em] text-primary">{pkg.package_code} · {pkg.travel_style}</div>
        <h1 className="mt-2 max-w-4xl font-display text-4xl sm:text-6xl">{pkg.name}</h1>
        <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
          <Stars value={pkg.rating} /><span className="inline-flex items-center gap-1"><MapPin className="h-4 w-4" />{pkg.state?.name ? `${pkg.state.name}, ` : ""}{pkg.country?.name}</span><span>{pkg.duration_nights} nights / {pkg.duration_days} days</span>
        </div>
      </div></div>
    </section>

    <div className="mx-auto max-w-7xl px-6 py-12">
      <div className="grid gap-10 lg:grid-cols-[1fr_340px]">
        <div>
          <p className="text-lg leading-relaxed text-muted-foreground">{pkg.description}</p>
          <div className="mt-8 grid gap-3 sm:grid-cols-4">
            {[{ i: CalendarDays, l: "Duration", v: `${pkg.duration_days} days` }, { i: BedDouble, l: "Stay", v: pkg.hotel_category }, { i: Utensils, l: "Meals", v: pkg.meals }, { i: Bus, l: "Transport", v: pkg.transportation }].map((a) => <div key={a.l} className="rounded-2xl glass p-4"><a.i className="h-4 w-4 text-primary" /><div className="mt-3 text-[11px] uppercase text-muted-foreground">{a.l}</div><div className="mt-1 text-sm">{a.v}</div></div>)}
          </div>
        </div>
        <aside className="lg:sticky lg:top-24 lg:self-start"><div className="rounded-3xl glass-strong p-6"><div className="text-xs uppercase tracking-wider text-muted-foreground">Current price</div><div className="mt-1 font-display text-4xl text-gradient-gold">{inr(pkg.price)}</div><div className="text-xs text-muted-foreground">per person · current catalogue rate</div><div className="mt-5 text-xs text-muted-foreground">{Math.max(0, pkg.capacity - pkg.booked_count)} places currently available</div><Link to="/book/$slug" params={{ slug }} search={{ customize: false }} className="mt-6 block rounded-full bg-primary px-6 py-3 text-center text-sm font-medium text-primary-foreground hover:opacity-90">Book this package</Link><Button variant="outline" className="mt-3 w-full rounded-full border-primary/50 text-primary" disabled={items.some((item) => item.slug === slug)} onClick={() => { addItem(slug); toast.success(`${pkg.name} added to your cart`); }}><ShoppingBag />{items.some((item) => item.slug === slug) ? "In your cart" : "Add to cart"}</Button><Link to="/book/$slug" params={{ slug }} search={{ customize: true }} className="mt-3 block rounded-full border border-primary/50 px-6 py-3 text-center text-sm text-primary hover:bg-primary/10">Customize trip</Link></div></aside>
      </div>

      <section className="pt-20"><Reveal><SectionHeading eyebrow="What's included" title="Everything arranged" /></Reveal><div className="grid gap-6 md:grid-cols-2"><div className="rounded-3xl glass p-6"><h3 className="font-display text-xl">Inclusions</h3><ul className="mt-5 space-y-3">{pkg.inclusions.map((x) => <li key={x} className="flex gap-3 text-sm text-muted-foreground"><Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />{x}</li>)}</ul></div><div className="rounded-3xl glass p-6"><h3 className="font-display text-xl">Not included</h3><ul className="mt-5 space-y-3">{["Flights or train tickets unless explicitly stated", "Personal expenses and optional tips", "Activities not listed in the confirmed itinerary", "Visa fees and international travel documents"].map((x) => <li key={x} className="flex gap-3 text-sm text-muted-foreground"><X className="mt-0.5 h-4 w-4 shrink-0" />{x}</li>)}</ul></div></div></section>

      <section className="pt-20"><Reveal><SectionHeading eyebrow="Day by day" title="Your itinerary" subtitle="Times may shift slightly with weather and local conditions." /></Reveal><ItineraryTimeline stops={toCustomStops(itinerary)} /></section>

      {!!places.length && <section className="pt-20"><Reveal><SectionHeading eyebrow="Highlights" title="Places along the way" /></Reveal><div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">{places.map((p) => <AttractionCard key={p.id} place={p} />)}</div></section>}

      <section className="pt-20"><Reveal><SectionHeading eyebrow="Peace of mind" title="Booking policy" /></Reveal><div className="rounded-3xl glass p-7"><ShieldCheck className="h-6 w-6 text-primary" /><p className="mt-4 max-w-3xl text-sm leading-relaxed text-muted-foreground">Cancellation and refund terms are confirmed for your selected package before payment and may vary by hotel, transport provider and travel date.</p><Link to="/about" hash="policies" className="mt-4 inline-block text-sm text-primary hover:underline">Policy information →</Link></div></section>

      {!!reviews.length && <section className="pt-20"><Reveal><SectionHeading eyebrow="Verified travellers" title="Recent reviews" /></Reveal><div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{reviews.map((r) => <ReviewCard key={r.id} review={r} />)}</div></section>}
    </div>
  </PageTransition></SiteShell>;
}
