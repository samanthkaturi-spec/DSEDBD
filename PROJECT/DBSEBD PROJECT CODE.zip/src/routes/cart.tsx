import { createFileRoute, Link } from "@tanstack/react-router";
import { useQueries } from "@tanstack/react-query";
import { Minus, Plus, ShoppingBag, Trash2 } from "lucide-react";
import { SiteShell } from "@/components/site-header";
import { Button } from "@/components/ui/button";
import { getPackageBySlug, type TravelPackage } from "@/lib/api/travel";
import { useCart, type CartItem } from "@/lib/cart";
import { inr } from "@/lib/format";
import { quote } from "@/lib/pricing";

export const Route = createFileRoute("/cart")({
  head: () => ({ meta: [
    { title: "Trip Cart — Royal Voyage" },
    { name: "description", content: "Review selected Royal Voyage travel packages and traveller counts before checkout." },
    { property: "og:title", content: "Trip Cart — Royal Voyage" },
    { property: "og:description", content: "Review your selected journeys before checkout." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: CartPage,
});

function priceFor(pkg: TravelPackage, item: CartItem) {
  return quote({ packagePrice: Number(pkg.price), adults: item.adults, children: item.children, nights: pkg.duration_nights, roomsCount: 1, roomPricePerNight: 0, baseRoomPricePerNight: 0, addonIds: [] });
}

function CartPage() {
  const { items, hydrated, updateItem, removeItem, clearCart } = useCart();
  const results = useQueries({ queries: items.map((item) => ({
    queryKey: ["package", item.slug],
    queryFn: () => getPackageBySlug(item.slug),
  })) });
  const rows = items.map((item, index) => ({ item, pkg: results[index]?.data ?? null }));
  const loading = !hydrated || results.some((result) => result.isLoading);
  const subtotal = rows.reduce((sum, row) => sum + (row.pkg ? priceFor(row.pkg, row.item).packageAmount : 0), 0);
  const taxes = Math.round(subtotal * 0.05);

  return <SiteShell><main className="mx-auto w-full max-w-7xl px-6 py-12">
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div><div className="text-xs uppercase tracking-[0.2em] text-primary">Selected journeys</div><h1 className="mt-2 font-display text-4xl sm:text-5xl">Your trip cart</h1><p className="mt-2 text-sm text-muted-foreground">Current catalogue prices are refreshed before checkout.</p></div>
      {!!items.length && <Button variant="ghost" onClick={clearCart}><Trash2 />Clear cart</Button>}
    </div>

    {loading ? <div className="mt-12 grid min-h-48 place-items-center text-muted-foreground">Refreshing your selections…</div> : !items.length ? (
      <div className="mt-12 rounded-2xl glass p-10 text-center"><ShoppingBag className="mx-auto h-8 w-8 text-primary" /><h2 className="mt-4 font-display text-2xl">Your cart is empty</h2><p className="mt-2 text-sm text-muted-foreground">Choose a current package to start planning.</p><Button asChild className="mt-6 rounded-full"><Link to="/packages" search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }}>Explore packages</Link></Button></div>
    ) : (
      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_340px]">
        <div className="space-y-4">{rows.map(({ item, pkg }) => pkg ? <article key={item.slug} className="grid overflow-hidden rounded-2xl glass sm:grid-cols-[190px_1fr]">
          <img src={pkg.image_url} alt={pkg.name} className="h-48 w-full object-cover sm:h-full" />
          <div className="p-5"><div className="flex items-start justify-between gap-4"><div><h2 className="font-display text-2xl">{pkg.name}</h2><p className="mt-1 text-xs text-muted-foreground">{pkg.state?.name ? `${pkg.state.name}, ` : ""}{pkg.country?.name} · {pkg.duration_nights}N / {pkg.duration_days}D</p></div><Button size="icon" variant="ghost" aria-label={`Remove ${pkg.name}`} onClick={() => removeItem(item.slug)}><Trash2 /></Button></div>
          <div className="mt-5 flex flex-wrap items-end justify-between gap-5"><div className="flex gap-5"><Quantity label="Adults" value={item.adults} min={1} onChange={(adults) => updateItem(item.slug, { adults, children: item.children })} /><Quantity label="Children" value={item.children} min={0} onChange={(children) => updateItem(item.slug, { adults: item.adults, children })} /></div><div className="text-right"><div className="text-xs text-muted-foreground">Package subtotal</div><div className="font-display text-2xl text-primary">{inr(priceFor(pkg, item).packageAmount)}</div></div></div></div>
        </article> : <div key={item.slug} className="rounded-2xl border border-destructive/40 p-5"><p className="text-sm">This package is no longer available.</p><Button variant="ghost" className="mt-2" onClick={() => removeItem(item.slug)}>Remove</Button></div>)}</div>
        <aside className="lg:sticky lg:top-24 lg:self-start"><div className="rounded-2xl glass-strong p-6"><h2 className="font-display text-2xl">Order summary</h2><div className="mt-5 space-y-3 text-sm"><SummaryRow label="Packages" value={inr(subtotal)} /><SummaryRow label="GST (5%)" value={inr(taxes)} /></div><div className="mt-5 flex items-end justify-between border-t border-border/50 pt-5"><span className="text-sm">Estimated total</span><strong className="font-display text-3xl text-primary">{inr(subtotal + taxes)}</strong></div><Button asChild className="mt-6 w-full rounded-full" disabled={rows.some((row) => !row.pkg)}><Link to="/checkout">Continue to checkout</Link></Button><Button asChild variant="outline" className="mt-3 w-full rounded-full"><Link to="/packages" search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }}>Add another journey</Link></Button></div></aside>
      </div>
    )}
  </main></SiteShell>;
}

function Quantity({ label, value, min, onChange }: { label: string; value: number; min: number; onChange: (value: number) => void }) {
  return <div><div className="mb-1.5 text-xs text-muted-foreground">{label}</div><div className="flex items-center gap-2"><Button size="icon" variant="outline" aria-label={`Decrease ${label}`} onClick={() => onChange(Math.max(min, value - 1))}><Minus /></Button><span className="w-6 text-center text-sm tabular-nums">{value}</span><Button size="icon" variant="outline" aria-label={`Increase ${label}`} onClick={() => onChange(value + 1)}><Plus /></Button></div></div>;
}

function SummaryRow({ label, value }: { label: string; value: string }) { return <div className="flex justify-between gap-4"><span className="text-muted-foreground">{label}</span><span className="tabular-nums">{value}</span></div>; }