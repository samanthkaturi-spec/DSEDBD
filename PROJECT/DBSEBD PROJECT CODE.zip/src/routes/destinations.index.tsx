import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { SiteShell } from "@/components/site-header";
import { PageTransition, Reveal } from "@/components/motion";
import { DestinationCard, CardSkeleton, EmptyState, SectionHeading } from "@/components/cards";
import { SearchFilters, emptyFilters, type Filters } from "@/components/search-filters";
import { listCities, listCountries, listStates } from "@/lib/api/travel";

export const Route = createFileRoute("/destinations/")({
  head: () => ({
    meta: [
      { title: "Destinations — Royal Voyage Travel Portal" },
      { name: "description", content: "Browse every destination we plan trips to, from Kerala's hill stations to Rajasthan's forts, Goa's beaches and the UAE." },
      { property: "og:title", content: "Destinations — Royal Voyage" },
      { property: "og:description", content: "Explore cities by country and region, with best season and daily budget." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DestinationsPage,
});

function DestinationsPage() {
  const [filters, setFilters] = useState<Filters>(emptyFilters);
  const { data: countries = [] } = useQuery({ queryKey: ["countries"], queryFn: listCountries });
  const { data: states = [] } = useQuery({
    queryKey: ["states", filters.countryId],
    queryFn: () => listStates(filters.countryId || undefined),
  });
  const { data: cities, isLoading } = useQuery({ queryKey: ["all-cities"], queryFn: () => listCities({}) });

  const stateIds = useMemo(() => new Set(states.map((s) => s.id)), [states]);
  const results = (cities ?? []).filter((c) => {
    if (filters.search && !c.name.toLowerCase().includes(filters.search.toLowerCase())) return false;
    if (filters.stateId) return c.state_id === filters.stateId;
    if (filters.countryId) return stateIds.has(c.state_id);
    return true;
  });

  return (
    <SiteShell>
      <PageTransition>
        <div className="mx-auto max-w-7xl px-6 py-14">
          <Reveal>
            <SectionHeading
              eyebrow="Destination explorer"
              title="Where would you like to go?"
              subtitle="Choose a country, then a region, then a city — each destination opens into attractions, packages and stays."
            />
          </Reveal>
          <div className="grid gap-8 lg:grid-cols-[300px_1fr]">
            <div className="lg:sticky lg:top-24 lg:self-start">
              <SearchFilters
                filters={filters}
                onChange={setFilters}
                countries={countries}
                states={states}
                showPackageFilters={false}
              />
            </div>
            <div>
              <div className="mb-5 text-sm text-muted-foreground">{results.length} destinations</div>
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {isLoading ? <CardSkeleton count={6} /> : results.map((c) => <DestinationCard key={c.id} city={c} />)}
              </div>
              {!isLoading && results.length === 0 && (
                <EmptyState title="No destinations match" hint="Try clearing a filter or searching a different city." />
              )}
            </div>
          </div>
        </div>
      </PageTransition>
    </SiteShell>
  );
}
