/**
 * Travel catalogue data access layer.
 *
 * Every value shown in the UI comes from the Lovable Cloud (Postgres) database
 * through these functions — components never hardcode catalogue content.
 * Read endpoints map 1:1 to REST-style resources:
 *
 *   listCountries()      -> GET /countries
 *   listStates()         -> GET /regions
 *   listCities()         -> GET /cities
 *   listAttractions()    -> GET /attractions
 *   listPackages()       -> GET /packages
 *   listHotels()         -> GET /hotels
 *   createBooking()      -> POST /bookings
 *   getBooking(id)       -> GET /bookings/:id
 *   listMyBookings()     -> GET /users/:id/trips
 *   submitReview()       -> POST /reviews
 *
 * If a live inventory/pricing API is connected later, swap the body of these
 * functions — no UI component needs to change.
 */
import { supabase } from "@/integrations/supabase/client";

/* ------------------------------- types ---------------------------------- */

export type Country = {
  id: string; code: string; name: string; slug: string; image_url: string;
  description: string; best_season: string; currency: string; starting_price: number;
};

export type State = {
  id: string; country_id: string; name: string; slug: string; image_url: string;
  description: string; best_season: string; starting_price: number;
  country?: Pick<Country, "name" | "slug" | "code"> | null;
};

export type City = {
  id: string; state_id: string; name: string; slug: string; image_url: string;
  description: string; best_season: string; recommended_days: number; daily_budget: number;
  state?: (Pick<State, "name" | "slug"> & { country?: Pick<Country, "name" | "slug"> | null }) | null;
};

export type Attraction = {
  id: string; city_id: string; name: string; slug: string; category: string;
  description: string; image_url: string; opening_time: string; closing_time: string;
  entry_fee: number; visit_duration_min: number; best_season: string;
  weather_sensitive: boolean; is_indoor: boolean; status: string;
  city?: (Pick<City, "name" | "slug"> & { state?: { name: string; country?: { name: string } | null } | null }) | null;
};

export type Room = {
  id: string; hotel_id: string; room_type: string; description: string; image_url: string;
  price_per_night: number; max_guests: number; total_units: number; available_units: number;
};

export type Hotel = {
  id: string; city_id: string; registration_no: string; name: string; slug: string;
  description: string; image_url: string; star_rating: number; rating: number;
  address: string; amenities: string[];
  city?: (Pick<City, "name" | "slug"> & { state?: { name: string; country?: { name: string } | null } | null }) | null;
  rooms?: Room[];
};

export type TravelPackage = {
  id: string; package_code: string; country_id: string; state_id: string | null;
  name: string; slug: string; description: string; image_url: string;
  duration_days: number; duration_nights: number; price: number; hotel_category: string;
  transportation: string; meals: string; travel_style: string; rating: number;
  capacity: number; booked_count: number; best_season: string; inclusions: string[];
  country?: Pick<Country, "name" | "slug"> | null;
  state?: Pick<State, "name" | "slug"> | null;
};

export type ItineraryStop = {
  id: string; package_id: string; day_number: number; day_title: string;
  city_id: string | null; start_time: string; activity: string; place_id: string | null;
  duration_min: number; travel_min: number; weather_sensitive: boolean; sort_order: number;
  city?: Pick<City, "name" | "slug"> | null;
  place?: Pick<Attraction, "name" | "slug" | "entry_fee" | "image_url"> | null;
};

export type Review = {
  id: string; user_id: string | null; package_id: string | null; hotel_id: string | null;
  rating: number; comment: string; reviewer_name: string; created_at: string;
  package?: Pick<TravelPackage, "name" | "slug"> | null;
};

export type Booking = {
  id: string; booking_ref: string; user_id: string; package_id: string;
  hotel_id: string | null; room_id: string | null; start_date: string; end_date: string;
  adults: number; children: number; travellers: number; rooms_count: number; addons: string[];
  package_amount: number; hotel_amount: number; addon_amount: number; taxes: number;
  total_amount: number; status: string; notes: string; created_at: string;
  package?: TravelPackage | null;
  hotel?: (Pick<Hotel, "name" | "image_url" | "address" | "star_rating"> & { city?: { name: string } | null }) | null;
  room?: Pick<Room, "room_type" | "price_per_night"> | null;
};

const unwrap = <T,>(res: { data: T | null; error: { message: string } | null }): T => {
  if (res.error) throw new Error(res.error.message);
  return (res.data ?? []) as T;
};

const CITY_JOIN = "*, state:states(name, slug, country:countries(name, slug))";

/* ----------------------------- geography -------------------------------- */

export async function listCountries(): Promise<Country[]> {
  return unwrap(await supabase.from("countries").select("*").order("name") as never);
}

export type PublicStats = {
  destinations: number;
  packages: number;
  hotels: number;
};

/** Current catalogue totals, counted directly from the database. */
export async function getPublicStats(): Promise<PublicStats> {
  const [destinations, packages, hotels] = await Promise.all([
    supabase.from("cities").select("id", { count: "exact", head: true }),
    supabase.from("travel_packages").select("id", { count: "exact", head: true }),
    supabase.from("hotels").select("id", { count: "exact", head: true }),
  ]);
  const failure = [destinations, packages, hotels].find((result) => result.error)?.error;
  if (failure) throw new Error(failure.message);
  return {
    destinations: destinations.count ?? 0,
    packages: packages.count ?? 0,
    hotels: hotels.count ?? 0,
  };
}

export async function listStates(countryId?: string): Promise<State[]> {
  let q = supabase.from("states").select("*, country:countries(name, slug, code)").order("name");
  if (countryId) q = q.eq("country_id", countryId);
  return unwrap(await q as never);
}

export async function listCities(filters: { stateId?: string; search?: string; limit?: number } = {}): Promise<City[]> {
  let q = supabase.from("cities").select(CITY_JOIN).order("name");
  if (filters.stateId) q = q.eq("state_id", filters.stateId);
  if (filters.search) q = q.ilike("name", `%${filters.search}%`);
  if (filters.limit) q = q.limit(filters.limit);
  return unwrap(await q as never);
}

/** Cities of one country, resolved via the state relation. */
export async function listCitiesByCountry(countryId: string): Promise<City[]> {
  const states = await listStates(countryId);
  if (!states.length) return [];
  const q = supabase.from("cities").select(CITY_JOIN).in("state_id", states.map((s) => s.id)).order("name");
  return unwrap(await q as never);
}

export async function getCityBySlug(slug: string): Promise<City | null> {
  const { data, error } = await supabase.from("cities").select(CITY_JOIN).eq("slug", slug).maybeSingle();
  if (error) throw new Error(error.message);
  return data as City | null;
}

/* ----------------------------- attractions ------------------------------ */

export async function listAttractions(filters: { cityId?: string; category?: string; search?: string; limit?: number } = {}): Promise<Attraction[]> {
  let q = supabase
    .from("tourist_places")
    .select("*, city:cities(name, slug, state:states(name, country:countries(name)))")
    .order("name");
  if (filters.cityId) q = q.eq("city_id", filters.cityId);
  if (filters.category) q = q.eq("category", filters.category);
  if (filters.search) q = q.ilike("name", `%${filters.search}%`);
  if (filters.limit) q = q.limit(filters.limit);
  return unwrap(await q as never);
}

/* ------------------------------- hotels --------------------------------- */

export async function listHotels(filters: { cityId?: string; minStars?: number; limit?: number } = {}): Promise<Hotel[]> {
  let q = supabase
    .from("hotels")
    .select("*, city:cities(name, slug, state:states(name, country:countries(name))), rooms(*)")
    .order("rating", { ascending: false });
  if (filters.cityId) q = q.eq("city_id", filters.cityId);
  if (filters.minStars) q = q.gte("star_rating", filters.minStars);
  if (filters.limit) q = q.limit(filters.limit);
  return unwrap(await q as never);
}

/** Hotels available for a package — everything in the package's region. */
export async function listHotelsForPackage(pkg: TravelPackage): Promise<Hotel[]> {
  let cityIds: string[] = [];
  if (pkg.state_id) {
    const cities = unwrap<{ id: string }[]>(
      await supabase.from("cities").select("id").eq("state_id", pkg.state_id) as never,
    );
    cityIds = cities.map((c) => c.id);
  }
  if (!cityIds.length) {
    const cities = await listCitiesByCountry(pkg.country_id);
    cityIds = cities.map((c) => c.id);
  }
  if (!cityIds.length) return [];
  return unwrap(
    await supabase
      .from("hotels")
      .select("*, city:cities(name, slug, state:states(name, country:countries(name))), rooms(*)")
      .in("city_id", cityIds)
      .order("star_rating", { ascending: true }) as never,
  );
}

/* ------------------------------ packages -------------------------------- */

const PKG_JOIN = "*, country:countries(name, slug), state:states(name, slug)";

export type PackageFilters = {
  countryId?: string;
  stateId?: string;
  search?: string;
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  maxDays?: number;
  hotelCategory?: string;
  travelStyle?: string;
  limit?: number;
};

export async function listPackages(f: PackageFilters = {}): Promise<TravelPackage[]> {
  let q = supabase.from("travel_packages").select(PKG_JOIN).order("rating", { ascending: false });
  if (f.countryId) q = q.eq("country_id", f.countryId);
  if (f.stateId) q = q.eq("state_id", f.stateId);
  if (f.search) q = q.ilike("name", `%${f.search}%`);
  if (f.minPrice != null) q = q.gte("price", f.minPrice);
  if (f.maxPrice != null) q = q.lte("price", f.maxPrice);
  if (f.minRating != null) q = q.gte("rating", f.minRating);
  if (f.maxDays != null) q = q.lte("duration_days", f.maxDays);
  if (f.hotelCategory) q = q.eq("hotel_category", f.hotelCategory);
  if (f.travelStyle) q = q.eq("travel_style", f.travelStyle);
  if (f.limit) q = q.limit(f.limit);
  return unwrap(await q as never);
}

export async function getPackageBySlug(slug: string): Promise<TravelPackage | null> {
  const { data, error } = await supabase.from("travel_packages").select(PKG_JOIN).eq("slug", slug).maybeSingle();
  if (error) throw new Error(error.message);
  return data as TravelPackage | null;
}

export async function listItinerary(packageId: string): Promise<ItineraryStop[]> {
  return unwrap(
    await supabase
      .from("package_itinerary")
      .select("*, city:cities(name, slug), place:tourist_places(name, slug, entry_fee, image_url)")
      .eq("package_id", packageId)
      .order("day_number")
      .order("sort_order") as never,
  );
}

export async function listPackageAttractions(packageId: string): Promise<Attraction[]> {
  const rows = unwrap<{ place: Attraction }[]>(
    await supabase
      .from("package_places")
      .select("sort_order, place:tourist_places(*, city:cities(name, slug, state:states(name, country:countries(name))))")
      .eq("package_id", packageId)
      .order("sort_order") as never,
  );
  return rows.map((r) => r.place).filter(Boolean);
}

/** Packages whose region contains this city. */
export async function listPackagesForCity(city: City): Promise<TravelPackage[]> {
  return listPackages({ stateId: city.state_id });
}

/* ------------------------------- reviews -------------------------------- */

export async function listReviews(filters: { packageId?: string; hotelId?: string; limit?: number } = {}): Promise<Review[]> {
  let q = supabase
    .from("reviews")
    .select("*, package:travel_packages(name, slug)")
    .not("user_id", "is", null)
    .order("created_at", { ascending: false });
  if (filters.packageId) q = q.eq("package_id", filters.packageId);
  if (filters.hotelId) q = q.eq("hotel_id", filters.hotelId);
  if (filters.limit) q = q.limit(filters.limit);
  return unwrap(await q as never);
}

export async function submitReview(input: {
  userId: string; packageId?: string | null; hotelId?: string | null;
  rating: number; comment: string; reviewerName: string;
}) {
  const { error } = await supabase.from("reviews").insert({
    user_id: input.userId,
    package_id: input.packageId ?? null,
    hotel_id: input.hotelId ?? null,
    rating: input.rating,
    comment: input.comment,
    reviewer_name: input.reviewerName,
  } as never);
  if (error) throw new Error(error.message);
}

/* ------------------------------ bookings -------------------------------- */

export type CreateBookingInput = {
  packageId: string; hotelId: string | null; roomId: string | null;
  startDate: string; endDate: string; adults: number; children: number;
  roomsCount: number; addons: string[]; packageAmount: number; hotelAmount: number;
  addonAmount: number; taxes: number; total: number;
  method: "upi" | "credit_card" | "debit_card" | "net_banking" | "cod";
  notes: string;
};

/** POST /bookings — atomic: checks capacity, holds the room, records payment. */
export async function createBooking(i: CreateBookingInput): Promise<Booking> {
  const { data, error } = await supabase.rpc("create_travel_booking", {
    _package_id: i.packageId,
    _hotel_id: i.hotelId,
    _room_id: i.roomId,
    _start_date: i.startDate,
    _end_date: i.endDate,
    _adults: i.adults,
    _children: i.children,
    _rooms_count: i.roomsCount,
    _addons: i.addons,
    _package_amount: i.packageAmount,
    _hotel_amount: i.hotelAmount,
    _addon_amount: i.addonAmount,
    _taxes: i.taxes,
    _total: i.total,
    _method: i.method,
    _notes: i.notes,
  } as never);
  if (error) throw new Error(error.message);
  return data as unknown as Booking;
}

const BOOKING_JOIN =
  "*, package:travel_packages(*, country:countries(name, slug), state:states(name, slug)), hotel:hotels(name, image_url, address, star_rating, city:cities(name)), room:rooms(room_type, price_per_night)";

export async function listMyBookings(userId: string): Promise<Booking[]> {
  return unwrap(
    await supabase.from("bookings").select(BOOKING_JOIN).eq("user_id", userId).order("start_date", { ascending: false }) as never,
  );
}

export async function getBooking(id: string): Promise<Booking | null> {
  const { data, error } = await supabase.from("bookings").select(BOOKING_JOIN).eq("id", id).maybeSingle();
  if (error) throw new Error(error.message);
  return data as Booking | null;
}

export async function cancelBooking(id: string) {
  const { error } = await supabase.from("bookings").update({ status: "cancelled" } as never).eq("id", id);
  if (error) throw new Error(error.message);
  await supabase.from("booking_history").insert({ booking_id: id, status: "cancelled", note: "Cancelled by traveller" } as never);
}

export async function listPayments(userId: string) {
  const { data, error } = await supabase
    .from("payments")
    .select("*, booking:bookings(booking_ref, package:travel_packages(name))")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as never[];
}

/* ----------------------------- saved trips ------------------------------ */

export async function listSavedTrips(userId: string) {
  const { data, error } = await supabase
    .from("saved_trips")
    .select("id, created_at, package:travel_packages(*, country:countries(name, slug), state:states(name, slug))")
    .eq("user_id", userId)
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as unknown as { id: string; created_at: string; package: TravelPackage }[];
}

export async function toggleSavedTrip(userId: string, packageId: string) {
  const { data } = await supabase
    .from("saved_trips").select("id").eq("user_id", userId).eq("package_id", packageId).maybeSingle();
  if (data?.id) {
    await supabase.from("saved_trips").delete().eq("id", data.id);
    return false;
  }
  const { error } = await supabase.from("saved_trips").insert({ user_id: userId, package_id: packageId } as never);
  if (error) throw new Error(error.message);
  return true;
}

/* ---------------------------- notifications ----------------------------- */

export async function listNotifications(userId: string) {
  const { data, error } = await supabase
    .from("notifications").select("*").eq("user_id", userId).order("created_at", { ascending: false }).limit(30);
  if (error) throw new Error(error.message);
  return (data ?? []) as { id: string; title: string; body: string; read: boolean; created_at: string }[];
}

export async function notify(userId: string, title: string, body: string) {
  await supabase.from("notifications").insert({ user_id: userId, title, body } as never);
}

export async function markNotificationRead(id: string) {
  await supabase.from("notifications").update({ read: true } as never).eq("id", id);
}
