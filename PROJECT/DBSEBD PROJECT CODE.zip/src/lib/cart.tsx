import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type CartItem = {
  slug: string;
  adults: number;
  children: number;
};

type CartContextValue = {
  items: CartItem[];
  count: number;
  hydrated: boolean;
  addItem: (slug: string) => void;
  updateItem: (slug: string, update: Pick<CartItem, "adults" | "children">) => void;
  removeItem: (slug: string) => void;
  clearCart: () => void;
};

const STORAGE_KEY = "royal-voyage-cart-v1";
const CartContext = createContext<CartContextValue | null>(null);

function validItem(value: unknown): value is CartItem {
  if (!value || typeof value !== "object") return false;
  const item = value as Partial<CartItem>;
  return typeof item.slug === "string" && item.slug.length > 0
    && Number.isInteger(item.adults) && Number(item.adults) >= 1
    && Number.isInteger(item.children) && Number(item.children) >= 0;
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const saved: unknown = JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? "[]");
      if (Array.isArray(saved)) setItems(saved.filter(validItem));
    } catch {
      window.localStorage.removeItem(STORAGE_KEY);
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }, [hydrated, items]);

  const value = useMemo<CartContextValue>(() => ({
    items,
    count: items.length,
    hydrated,
    addItem(slug) {
      setItems((current) => current.some((item) => item.slug === slug)
        ? current
        : [...current, { slug, adults: 2, children: 0 }]);
    },
    updateItem(slug, update) {
      setItems((current) => current.map((item) => item.slug === slug
        ? { ...item, adults: Math.max(1, update.adults), children: Math.max(0, update.children) }
        : item));
    },
    removeItem(slug) {
      setItems((current) => current.filter((item) => item.slug !== slug));
    },
    clearCart() {
      setItems([]);
    },
  }), [hydrated, items]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used within CartProvider");
  return context;
}