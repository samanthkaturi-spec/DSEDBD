/**
 * Trip pricing engine.
 *
 * All catalogue values (package price, room rates, entry fees) come from the
 * database. This module is the single place where a quote is assembled so the
 * same numbers appear in the customiser, the review step, the payment screen
 * and the stored booking record.
 */

export const TAX_RATE = 0.05; // 5% GST on travel packages

export type AddonOption = {
  id: string;
  label: string;
  description: string;
  /** price per traveller */
  pricePerPerson: number;
};

export const ADDONS: AddonOption[] = [
  { id: "airport-transfer", label: "Private airport transfer", description: "Chauffeured pickup & drop", pricePerPerson: 1500 },
  { id: "all-meals", label: "All meals included", description: "Breakfast, lunch & dinner", pricePerPerson: 2200 },
  { id: "guided-tours", label: "Private local guide", description: "Certified guide for every sightseeing day", pricePerPerson: 1800 },
  { id: "travel-insurance", label: "Travel insurance", description: "Medical & cancellation cover", pricePerPerson: 900 },
  { id: "photoshoot", label: "Destination photoshoot", description: "90-minute shoot with a local photographer", pricePerPerson: 3500 },
];

export type QuoteInput = {
  packagePrice: number;
  adults: number;
  children: number;
  nights: number;
  roomsCount: number;
  roomPricePerNight: number;
  /** base room rate for the package's included hotel category */
  baseRoomPricePerNight: number;
  addonIds: string[];
  activityCost?: number;
};

export type Quote = {
  travellers: number;
  packageAmount: number;
  hotelAmount: number;
  addonAmount: number;
  activityAmount: number;
  taxes: number;
  total: number;
  perPerson: number;
};

const CHILD_FACTOR = 0.6;

export function quote(input: QuoteInput): Quote {
  const travellers = input.adults + input.children;
  const packageAmount = Math.round(
    input.packagePrice * (input.adults + input.children * CHILD_FACTOR),
  );
  const upgrade = Math.max(0, input.roomPricePerNight - input.baseRoomPricePerNight);
  const hotelAmount = Math.round(upgrade * input.nights * Math.max(1, input.roomsCount));
  const addonAmount = Math.round(
    input.addonIds.reduce((sum, id) => {
      const a = ADDONS.find((x) => x.id === id);
      return sum + (a ? a.pricePerPerson * travellers : 0);
    }, 0),
  );
  const activityAmount = Math.round(input.activityCost ?? 0);
  const subtotal = packageAmount + hotelAmount + addonAmount + activityAmount;
  const taxes = Math.round(subtotal * TAX_RATE);
  const total = subtotal + taxes;
  return {
    travellers,
    packageAmount,
    hotelAmount,
    addonAmount,
    activityAmount,
    taxes,
    total,
    perPerson: travellers ? Math.round(total / travellers) : total,
  };
}
