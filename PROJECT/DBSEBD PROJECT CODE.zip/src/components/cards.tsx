import { Link } from "@tanstack/react-router";
import {
  Star, MapPin, CalendarDays, Clock, Ticket, Users, BedDouble, Utensils, Bus, Heart,
} from "lucide-react";
import { inr, shortDate, timeLabel, durationLabel } from "@/lib/format";
import type { Attraction, City, Hotel, Review, TravelPackage, Booking } from "@/lib/api/travel";

/* --------------------------------- atoms -------------------------------- */

export function Stars({ value, className = "" }: { value: number; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-1 text-primary ${className}`}>
      <Star className="h-3.5 w-3.5 fill-current" />
      <span className="text-xs font-medium text-foreground">{Number(value).toFixed(1)}</span>
    </span>
  );
}

export function Chip({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-border/60 bg-muted/30 px-2.5 py-1 text-[11px] text-muted-foreground">
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow, title, subtitle, action,
}: { eyebrow?: string; title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div>
        {eyebrow && <div className="text-xs uppercase tracking-[0.2em] text-primary">{eyebrow}</div>}
        <h2 className="mt-2 font-display text-3xl sm:text-4xl">{title}</h2>
        {subtitle && <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

const imgWrap =
  "relative aspect-[4/3] overflow-hidden rounded-2xl bg-muted";
const imgCls =
  "h-full w-full object-cover transition-transform duration-700 group-hover:scale-110";

/* ------------------------------ destination ------------------------------ */

export function DestinationCard({ city }: { city: City }) {
  return (
    <Link
      to="/destinations/$city"
      params={{ city: city.slug }}
      className="group block overflow-hidden rounded-3xl glass p-2.5 transition-all duration-300 hover-lift hover:border-primary"
    >
      <div className={imgWrap}>
        <img src={city.image_url} alt={`${city.name} destination`} loading="lazy" className={imgCls} />
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-background/90 to-transparent p-4">
          <div className="font-display text-xl">{city.name}</div>
          <div className="text-xs text-muted-foreground">
            {city.state?.name}, {city.state?.country?.name}
          </div>
        </div>
      </div>
      <div className="flex items-center justify-between px-3 py-3 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5"><CalendarDays className="h-3.5 w-3.5" />{city.best_season}</span>
        <span>{city.recommended_days} days · {inr(city.daily_budget)}/day</span>
      </div>
    </Link>
  );
}

/* -------------------------------- package -------------------------------- */

export function PackageCard({
  pkg, saved, onToggleSave,
}: { pkg: TravelPackage; saved?: boolean; onToggleSave?: () => void }) {
  const seatsLeft = Math.max(0, pkg.capacity - pkg.booked_count);
  return (
    <div className="group relative flex flex-col overflow-hidden rounded-3xl glass transition-all duration-300 hover-lift hover:border-primary">
      <Link to="/packages/$slug" params={{ slug: pkg.slug }} className="block">
        <div className="relative aspect-[16/10] overflow-hidden bg-muted">
          <img src={pkg.image_url} alt={pkg.name} loading="lazy" className={imgCls} />
          <div className="absolute left-4 top-4 rounded-full bg-background/80 px-3 py-1 text-[11px] uppercase tracking-wider text-primary backdrop-blur">
            {pkg.travel_style}
          </div>
        </div>
      </Link>
      {onToggleSave && (
        <button
          onClick={onToggleSave}
          aria-label={saved ? "Remove from wishlist" : "Save to wishlist"}
          className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full bg-background/80 backdrop-blur transition hover:text-primary"
        >
          <Heart className={`h-4 w-4 ${saved ? "fill-primary text-primary" : ""}`} />
        </button>
      )}
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <Link to="/packages/$slug" params={{ slug: pkg.slug }} className="font-display text-xl hover:text-primary">
              {pkg.name}
            </Link>
            <div className="mt-1 inline-flex items-center gap-1.5 text-xs text-muted-foreground">
              <MapPin className="h-3.5 w-3.5" />
              {pkg.state?.name ? `${pkg.state.name}, ` : ""}{pkg.country?.name}
            </div>
          </div>
          <Stars value={pkg.rating} />
        </div>

        <div className="mt-4 flex flex-wrap gap-1.5">
          <Chip><CalendarDays className="h-3 w-3" />{pkg.duration_nights}N / {pkg.duration_days}D</Chip>
          <Chip><BedDouble className="h-3 w-3" />{pkg.hotel_category}</Chip>
          <Chip><Utensils className="h-3 w-3" />{pkg.meals}</Chip>
          <Chip><Bus className="h-3 w-3" />{pkg.transportation}</Chip>
        </div>

        <p className="mt-3 line-clamp-2 text-sm text-muted-foreground">{pkg.description}</p>

        <div className="mt-auto flex items-end justify-between pt-5">
          <div>
            <div className="text-[11px] uppercase tracking-wider text-muted-foreground">From</div>
            <div className="font-display text-2xl text-gradient-gold">{inr(pkg.price)}</div>
            <div className="text-[11px] text-muted-foreground">
              per person · <Users className="inline h-3 w-3" /> {seatsLeft} seats left
            </div>
          </div>
          <Link
            to="/packages/$slug"
            params={{ slug: pkg.slug }}
            className="rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition hover:opacity-90"
          >
            View package
          </Link>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------- attraction ------------------------------ */

export function AttractionCard({
  place, onAdd, added,
}: { place: Attraction; onAdd?: () => void; added?: boolean }) {
  return (
    <div className="group flex flex-col overflow-hidden rounded-3xl glass transition-all duration-300 hover-lift hover:border-primary">
      <div className="relative aspect-[16/10] overflow-hidden bg-muted">
        <img src={place.image_url} alt={place.name} loading="lazy" className={imgCls} />
        <div className="absolute left-3 top-3 rounded-full bg-background/80 px-2.5 py-1 text-[10px] uppercase tracking-wider text-primary backdrop-blur">
          {place.category}
        </div>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <div className="font-display text-lg">{place.name}</div>
        <div className="mt-1 inline-flex items-center gap-1.5 text-xs text-muted-foreground">
          <MapPin className="h-3.5 w-3.5" />
          {place.city?.name}{place.city?.state?.name ? `, ${place.city.state.name}` : ""}
        </div>
        <p className="mt-3 line-clamp-3 text-sm text-muted-foreground">{place.description}</p>
        <div className="mt-4 grid grid-cols-2 gap-2 text-[11px] text-muted-foreground">
          <span className="inline-flex items-center gap-1.5"><Clock className="h-3 w-3" />{timeLabel(place.opening_time)}–{timeLabel(place.closing_time)}</span>
          <span className="inline-flex items-center gap-1.5"><CalendarDays className="h-3 w-3" />{durationLabel(place.visit_duration_min)} visit</span>
          <span className="inline-flex items-center gap-1.5"><Ticket className="h-3 w-3" />{Number(place.entry_fee) > 0 ? inr(place.entry_fee) : "Free entry"}</span>
          <span className="inline-flex items-center gap-1.5">{place.is_indoor ? "Indoor" : "Outdoor"}</span>
        </div>
        {onAdd && (
          <button
            onClick={onAdd}
            className={`mt-5 rounded-full px-4 py-2.5 text-sm font-medium transition ${
              added
                ? "border border-primary text-primary"
                : "bg-primary text-primary-foreground hover:opacity-90"
            }`}
          >
            {added ? "Added to trip" : "Add to trip"}
          </button>
        )}
      </div>
    </div>
  );
}

/* --------------------------------- hotel --------------------------------- */

export function HotelCard({
  hotel, selected, onSelect, roomId, onRoomChange,
}: {
  hotel: Hotel;
  selected?: boolean;
  onSelect?: () => void;
  roomId?: string;
  onRoomChange?: (id: string) => void;
}) {
  const rooms = hotel.rooms ?? [];
  const cheapest = rooms.length ? Math.min(...rooms.map((r) => Number(r.price_per_night))) : 0;
  return (
    <div
      className={`group flex flex-col overflow-hidden rounded-3xl glass transition-all duration-300 hover-lift ${
        selected ? "border-primary ring-1 ring-primary/40" : "hover:border-primary"
      }`}
    >
      <div className="relative aspect-[16/10] overflow-hidden bg-muted">
        <img src={hotel.image_url} alt={hotel.name} loading="lazy" className={imgCls} />
        <div className="absolute right-3 top-3 rounded-full bg-background/80 px-2.5 py-1 text-[11px] text-primary backdrop-blur">
          {hotel.star_rating}★ {hotel.star_rating === 5 ? "Luxury" : "Hotel"}
        </div>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-start justify-between gap-2">
          <div className="font-display text-lg">{hotel.name}</div>
          <Stars value={hotel.rating} />
        </div>
        <div className="mt-1 inline-flex items-center gap-1.5 text-xs text-muted-foreground">
          <MapPin className="h-3.5 w-3.5" />{hotel.address}
        </div>
        <p className="mt-3 line-clamp-2 text-sm text-muted-foreground">{hotel.description}</p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {hotel.amenities?.slice(0, 4).map((a) => <Chip key={a}>{a}</Chip>)}
        </div>

        {onRoomChange && rooms.length > 0 && (
          <div className="mt-4 grid gap-2">
            {rooms.map((r) => (
              <label
                key={r.id}
                className={`flex cursor-pointer items-center justify-between gap-3 rounded-2xl border p-3 text-sm transition ${
                  roomId === r.id ? "border-primary bg-primary/5" : "border-border/60 hover:border-primary/50"
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <input
                    type="radio"
                    className="accent-primary"
                    checked={roomId === r.id}
                    onChange={() => onRoomChange(r.id)}
                  />
                  <span>
                    <span className="block">{r.room_type}</span>
                    <span className="block text-[11px] text-muted-foreground">
                      Sleeps {r.max_guests} · {r.available_units} left
                    </span>
                  </span>
                </span>
                <span className="text-right">
                  <span className="block font-display text-base">{inr(r.price_per_night)}</span>
                  <span className="text-[11px] text-muted-foreground">per night</span>
                </span>
              </label>
            ))}
          </div>
        )}

        <div className="mt-auto flex items-end justify-between pt-5">
          <div>
            <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Rooms from</div>
            <div className="font-display text-xl text-gradient-gold">{inr(cheapest)}</div>
            <div className="text-[11px] text-muted-foreground">per night · breakfast included</div>
          </div>
          {onSelect && (
            <button
              onClick={onSelect}
              className={`rounded-full px-5 py-2.5 text-sm font-medium transition ${
                selected ? "border border-primary text-primary" : "bg-primary text-primary-foreground hover:opacity-90"
              }`}
            >
              {selected ? "Selected" : "Select hotel"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* -------------------------------- review --------------------------------- */

export function ReviewCard({ review }: { review: Review }) {
  return (
    <div className="flex h-full flex-col rounded-3xl glass p-6">
      <div className="flex items-center gap-1 text-primary">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star key={i} className={`h-3.5 w-3.5 ${i < review.rating ? "fill-current" : "opacity-25"}`} />
        ))}
      </div>
      <p className="mt-4 flex-1 text-sm leading-relaxed text-muted-foreground">“{review.comment}”</p>
      <div className="mt-5 border-t border-border/40 pt-4">
        {review.reviewer_name && <div className="text-sm">{review.reviewer_name}</div>}
        <div className="text-[11px] text-muted-foreground">
          {review.package?.name && <>{review.package.name} · </>}{shortDate(review.created_at)}
        </div>
      </div>
    </div>
  );
}

/* --------------------------------- trip ---------------------------------- */

export function TripCard({ booking, countdown }: { booking: Booking; countdown?: number }) {
  const pkg = booking.package;
  return (
    <Link
      to="/trips/$id"
      params={{ id: booking.id }}
      search={{ confirmed: false }}
      className="group flex gap-4 overflow-hidden rounded-3xl glass p-3 transition hover-lift hover:border-primary sm:p-4"
    >
      <div className="h-28 w-28 shrink-0 overflow-hidden rounded-2xl bg-muted sm:h-32 sm:w-40">
        <img src={pkg?.image_url} alt={pkg?.name ?? "Trip"} loading="lazy" className={imgCls} />
      </div>
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="truncate font-display text-lg">{pkg?.name}</div>
            <div className="text-xs text-muted-foreground">
              {booking.booking_ref} · {shortDate(booking.start_date)} → {shortDate(booking.end_date)}
            </div>
          </div>
          <span className="rounded-full border border-primary/40 px-2.5 py-1 text-[10px] uppercase tracking-wider text-primary">
            {booking.status.replace(/_/g, " ")}
          </span>
        </div>
        <div className="mt-2 flex flex-wrap gap-1.5">
          <Chip><Users className="h-3 w-3" />{booking.travellers} travellers</Chip>
          {booking.hotel?.name && <Chip><BedDouble className="h-3 w-3" />{booking.hotel.name}</Chip>}
          {countdown != null && countdown >= 0 && (
            <Chip><Clock className="h-3 w-3" />{countdown === 0 ? "Departs today" : `${countdown} days to go`}</Chip>
          )}
        </div>
        <div className="mt-auto pt-3 font-display text-xl text-gradient-gold">{inr(booking.total_amount)}</div>
      </div>
    </Link>
  );
}

/* ------------------------------- skeletons ------------------------------- */

export function CardSkeleton({ count = 3 }: { count?: number }) {
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="animate-pulse overflow-hidden rounded-3xl glass">
          <div className="aspect-[16/10] bg-muted/50" />
          <div className="space-y-3 p-5">
            <div className="h-4 w-2/3 rounded bg-muted/50" />
            <div className="h-3 w-1/3 rounded bg-muted/40" />
            <div className="h-3 w-full rounded bg-muted/30" />
            <div className="h-3 w-4/5 rounded bg-muted/30" />
          </div>
        </div>
      ))}
    </>
  );
}

export function EmptyState({ title, hint, action }: { title: string; hint?: string; action?: React.ReactNode }) {
  return (
    <div className="glass grid place-items-center rounded-3xl px-6 py-16 text-center">
      <div className="font-display text-xl">{title}</div>
      {hint && <p className="mt-2 max-w-sm text-sm text-muted-foreground">{hint}</p>}
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}
