import { Search, SlidersHorizontal, X } from "lucide-react";
import { inr } from "@/lib/format";

export type Filters = {
  search: string;
  countryId: string;
  stateId: string;
  maxPrice: number;
  maxDays: number;
  minRating: number;
  hotelCategory: string;
  travelStyle: string;
};

export const emptyFilters: Filters = {
  search: "", countryId: "", stateId: "", maxPrice: 0, maxDays: 0, minRating: 0,
  hotelCategory: "", travelStyle: "",
};

const field =
  "w-full rounded-xl border border-border/60 bg-background/60 px-3.5 py-2.5 text-sm outline-none transition focus:border-primary";

export function SearchFilters({
  filters, onChange, countries, states, priceCeiling = 200000, showPackageFilters = true,
}: {
  filters: Filters;
  onChange: (f: Filters) => void;
  countries: { id: string; name: string }[];
  states: { id: string; name: string }[];
  priceCeiling?: number;
  showPackageFilters?: boolean;
}) {
  const set = (patch: Partial<Filters>) => onChange({ ...filters, ...patch });
  const dirty = JSON.stringify(filters) !== JSON.stringify(emptyFilters);

  return (
    <div className="rounded-3xl glass p-5 sm:p-6">
      <div className="mb-4 flex items-center justify-between">
        <div className="inline-flex items-center gap-2 text-sm">
          <SlidersHorizontal className="h-4 w-4 text-primary" /> Refine
        </div>
        {dirty && (
          <button
            onClick={() => onChange(emptyFilters)}
            className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-primary"
          >
            <X className="h-3 w-3" /> Clear all
          </button>
        )}
      </div>

      <div className="relative mb-4">
        <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          className={`${field} pl-10`}
          placeholder="Search by name…"
          value={filters.search}
          onChange={(e) => set({ search: e.target.value })}
        />
      </div>

      <div className="grid gap-4">
        <div>
          <label className="mb-1.5 block text-xs text-muted-foreground">Country</label>
          <select className={field} value={filters.countryId} onChange={(e) => set({ countryId: e.target.value, stateId: "" })}>
            <option value="">All countries</option>
            {countries.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="mb-1.5 block text-xs text-muted-foreground">Region / state</label>
          <select className={field} value={filters.stateId} onChange={(e) => set({ stateId: e.target.value })}>
            <option value="">All regions</option>
            {states.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>

        {showPackageFilters && (
          <>
            <div>
              <label className="mb-1.5 flex justify-between text-xs text-muted-foreground">
                <span>Max budget</span>
                <span>{filters.maxPrice ? inr(filters.maxPrice) : "Any"}</span>
              </label>
              <input
                type="range"
                min={0}
                max={priceCeiling}
                step={5000}
                value={filters.maxPrice}
                onChange={(e) => set({ maxPrice: Number(e.target.value) })}
                className="w-full accent-[var(--primary)]"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs text-muted-foreground">Duration</label>
              <select className={field} value={filters.maxDays} onChange={(e) => set({ maxDays: Number(e.target.value) })}>
                <option value={0}>Any length</option>
                <option value={3}>Up to 3 days</option>
                <option value={5}>Up to 5 days</option>
                <option value={7}>Up to 7 days</option>
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-xs text-muted-foreground">Minimum rating</label>
              <select className={field} value={filters.minRating} onChange={(e) => set({ minRating: Number(e.target.value) })}>
                <option value={0}>Any rating</option>
                <option value={4}>4.0+</option>
                <option value={4.5}>4.5+</option>
                <option value={4.8}>4.8+</option>
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-xs text-muted-foreground">Hotel category</label>
              <select className={field} value={filters.hotelCategory} onChange={(e) => set({ hotelCategory: e.target.value })}>
                <option value="">Any category</option>
                <option value="3-Star">3 Star</option>
                <option value="4-Star">4 Star</option>
                <option value="5-Star">5 Star</option>
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-xs text-muted-foreground">Travel type</label>
              <select className={field} value={filters.travelStyle} onChange={(e) => set({ travelStyle: e.target.value })}>
                <option value="">Any style</option>
                <option value="family">Family</option>
                <option value="couple">Couple / honeymoon</option>
                <option value="adventure">Adventure</option>
                <option value="historical">Heritage & culture</option>
                <option value="luxury">Luxury</option>
              </select>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
