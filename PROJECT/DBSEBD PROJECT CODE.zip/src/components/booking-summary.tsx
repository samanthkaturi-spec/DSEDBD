import { inr, shortDate } from "@/lib/format";
import { ADDONS, type Quote } from "@/lib/pricing";
import type { Hotel, Room, TravelPackage } from "@/lib/api/travel";

export function BookingSummary({
  pkg, hotel, room, quote, startDate, endDate, adults, children, roomsCount, addonIds, sticky = true,
}: {
  pkg: TravelPackage;
  hotel?: Hotel | null;
  room?: Room | null;
  quote: Quote;
  startDate: string;
  endDate: string;
  adults: number;
  children: number;
  roomsCount: number;
  addonIds: string[];
  sticky?: boolean;
}) {
  const Row = ({ label, value, muted }: { label: string; value: string; muted?: boolean }) => (
    <div className={`flex items-baseline justify-between gap-4 text-sm ${muted ? "text-muted-foreground" : ""}`}>
      <span>{label}</span>
      <span className="tabular-nums">{value}</span>
    </div>
  );

  return (
    <aside className={sticky ? "lg:sticky lg:top-24" : ""}>
      <div className="rounded-3xl glass p-6">
        <div className="text-xs uppercase tracking-[0.2em] text-primary">Trip summary</div>
        <div className="mt-2 font-display text-2xl">{pkg.name}</div>
        <div className="mt-1 text-xs text-muted-foreground">
          {pkg.state?.name ? `${pkg.state.name}, ` : ""}{pkg.country?.name} · {pkg.duration_nights}N / {pkg.duration_days}D
        </div>

        <div className="mt-5 space-y-2 border-t border-border/40 pt-5">
          <Row muted label="Travel dates" value={`${shortDate(startDate)} → ${shortDate(endDate)}`} />
          <Row muted label="Travellers" value={`${adults} adult${adults > 1 ? "s" : ""}${children ? `, ${children} child` : ""}`} />
          <Row muted label="Rooms" value={String(roomsCount)} />
          {hotel && <Row muted label="Hotel" value={`${hotel.name} (${hotel.star_rating}★)`} />}
          {room && <Row muted label="Room" value={room.room_type} />}
          {addonIds.length > 0 && (
            <div className="pt-1 text-xs text-muted-foreground">
              Extras: {addonIds.map((id) => ADDONS.find((a) => a.id === id)?.label ?? id).join(", ")}
            </div>
          )}
        </div>

        <div className="mt-5 space-y-2 border-t border-border/40 pt-5">
          <Row label="Package price" value={inr(quote.packageAmount)} />
          <Row label="Hotel upgrade" value={quote.hotelAmount ? inr(quote.hotelAmount) : "Included"} />
          <Row label="Optional extras" value={quote.addonAmount ? inr(quote.addonAmount) : "—"} />
          {quote.activityAmount > 0 && <Row label="Added activities" value={inr(quote.activityAmount)} />}
          <Row label="Taxes & fees (5% GST)" value={inr(quote.taxes)} />
        </div>

        <div className="mt-5 flex items-end justify-between border-t border-border/40 pt-5">
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Estimated trip cost</div>
            <div className="text-[11px] text-muted-foreground">{inr(quote.perPerson)} per traveller</div>
          </div>
          <div className="font-display text-3xl text-gradient-gold tabular-nums">{inr(quote.total)}</div>
        </div>
      </div>
    </aside>
  );
}
