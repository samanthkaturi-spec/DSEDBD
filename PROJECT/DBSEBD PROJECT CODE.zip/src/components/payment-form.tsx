import { useState } from "react";
import { CreditCard, Smartphone, Landmark, ShieldCheck, Info } from "lucide-react";
import { inr } from "@/lib/format";

export type PaymentMethod = "upi" | "credit_card" | "debit_card" | "net_banking";

const METHODS: { id: PaymentMethod; label: string; icon: typeof CreditCard }[] = [
  { id: "upi", label: "UPI", icon: Smartphone },
  { id: "credit_card", label: "Credit card", icon: CreditCard },
  { id: "debit_card", label: "Debit card", icon: CreditCard },
  { id: "net_banking", label: "Net banking", icon: Landmark },
];

const BANKS = ["HDFC Bank", "ICICI Bank", "State Bank of India", "Axis Bank", "Kotak Mahindra"];

const field =
  "w-full rounded-xl border border-border/60 bg-background/60 px-4 py-3 text-sm outline-none transition focus:border-primary";

/**
 * Demo payment interface.
 *
 * No card data leaves the browser and no money moves — the form validates the
 * shape of the input and returns the chosen method. Swap `onPay` for a
 * Razorpay/Stripe checkout session when a real gateway is connected.
 */
export function PaymentForm({
  amount, busy, onPay,
}: { amount: number; busy?: boolean; onPay: (method: PaymentMethod) => void }) {
  const [method, setMethod] = useState<PaymentMethod>("upi");
  const [upi, setUpi] = useState("");
  const [card, setCard] = useState({ number: "", name: "", expiry: "", cvv: "" });
  const [bank, setBank] = useState(BANKS[0]);
  const [error, setError] = useState("");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (method === "upi" && !/^[\w.-]{2,}@[a-zA-Z]{2,}$/.test(upi)) {
      return setError("Enter a valid UPI ID.");
    }
    if ((method === "credit_card" || method === "debit_card")) {
      const digits = card.number.replace(/\s/g, "");
      if (digits.length < 12 || !/^\d+$/.test(digits)) return setError("Enter a valid card number.");
      if (!card.name.trim()) return setError("Enter the name printed on the card.");
      if (!/^\d{2}\/\d{2}$/.test(card.expiry)) return setError("Expiry must be in MM/YY format.");
      if (!/^\d{3,4}$/.test(card.cvv)) return setError("Enter the 3-digit CVV.");
    }
    onPay(method);
  }

  return (
    <form onSubmit={submit} className="rounded-3xl glass p-6 sm:p-8">
      <div className="flex items-center justify-between gap-4">
        <h2 className="font-display text-2xl">Payment</h2>
        <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
          <ShieldCheck className="h-3.5 w-3.5 text-primary" /> Encrypted checkout
        </span>
      </div>

      <div className="mt-5 flex items-start gap-2.5 rounded-2xl border border-primary/30 bg-primary/5 p-4 text-xs text-muted-foreground">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
        <p>
          <strong className="text-foreground">Demo mode.</strong> No payment gateway is connected
          yet, so no money is charged and no card details are stored or transmitted. Your booking
          is recorded so you can see the full confirmation flow. A live Razorpay or Stripe
          integration can be plugged into this same step later.
        </p>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {METHODS.map((m) => (
          <button
            key={m.id}
            type="button"
            onClick={() => setMethod(m.id)}
            className={`flex flex-col items-center gap-2 rounded-2xl border p-4 text-xs transition ${
              method === m.id ? "border-primary bg-primary/10 text-primary" : "border-border/60 text-muted-foreground hover:border-primary/50"
            }`}
          >
            <m.icon className="h-4 w-4" />
            {m.label}
          </button>
        ))}
      </div>

      <div className="mt-6 space-y-4">
        {method === "upi" && (
          <div>
            <label className="mb-1.5 block text-xs text-muted-foreground">UPI ID</label>
            <input className={field} autoComplete="off" value={upi} onChange={(e) => setUpi(e.target.value)} />
          </div>
        )}

        {(method === "credit_card" || method === "debit_card") && (
          <>
            <div>
              <label className="mb-1.5 block text-xs text-muted-foreground">Card number</label>
              <input
                className={field}
                inputMode="numeric"
                placeholder="Card number"
                value={card.number}
                onChange={(e) => setCard({ ...card, number: e.target.value })}
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs text-muted-foreground">Name on card</label>
              <input className={field} placeholder="As printed on the card" value={card.name} onChange={(e) => setCard({ ...card, name: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1.5 block text-xs text-muted-foreground">Expiry</label>
                <input className={field} placeholder="MM/YY" value={card.expiry} onChange={(e) => setCard({ ...card, expiry: e.target.value })} />
              </div>
              <div>
                <label className="mb-1.5 block text-xs text-muted-foreground">CVV</label>
                <input className={field} type="password" placeholder="•••" value={card.cvv} onChange={(e) => setCard({ ...card, cvv: e.target.value })} />
              </div>
            </div>
          </>
        )}

        {method === "net_banking" && (
          <div>
            <label className="mb-1.5 block text-xs text-muted-foreground">Select your bank</label>
            <select className={field} value={bank} onChange={(e) => setBank(e.target.value)}>
              {BANKS.map((b) => <option key={b}>{b}</option>)}
            </select>
          </div>
        )}
      </div>

      {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

      <button
        type="submit"
        disabled={busy}
        className="mt-7 w-full rounded-full bg-primary px-6 py-3.5 text-sm font-medium text-primary-foreground transition hover:opacity-90 disabled:opacity-60"
      >
        {busy ? "Confirming your trip…" : `Pay ${inr(amount)} (demo)`}
      </button>
    </form>
  );
}
