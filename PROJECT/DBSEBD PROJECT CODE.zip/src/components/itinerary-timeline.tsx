import { Clock, MapPin, Bus, Ticket, Plus, Trash2 } from "lucide-react";
import { inr, timeLabel, durationLabel } from "@/lib/format";
import type { ItineraryStop } from "@/lib/api/travel";

export type CustomStop = {
  key: string;
  day: number;
  time: string;
  activity: string;
  location: string;
  durationMin: number;
  travelMin: number;
  cost: number;
  removable: boolean;
};

/** Normalises database itinerary rows into day-grouped, editable stops. */
export function toCustomStops(stops: ItineraryStop[]): CustomStop[] {
  return stops.map((s) => ({
    key: s.id,
    day: s.day_number,
    time: s.start_time,
    activity: s.activity,
    location: s.city?.name ?? "",
    durationMin: s.duration_min,
    travelMin: s.travel_min,
    cost: Number(s.place?.entry_fee ?? 0),
    removable: false,
  }));
}

export function ItineraryTimeline({
  stops,
  editable = false,
  onRemove,
  onAddDayActivity,
}: {
  stops: CustomStop[];
  editable?: boolean;
  onRemove?: (key: string) => void;
  onAddDayActivity?: (day: number) => void;
}) {
  const days = Array.from(new Set(stops.map((s) => s.day))).sort((a, b) => a - b);

  if (!stops.length) {
    return (
      <div className="rounded-3xl glass p-8 text-center text-sm text-muted-foreground">
        A detailed day-by-day plan will be shared with your booking confirmation.
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {days.map((day) => {
        const dayStops = stops.filter((s) => s.day === day).sort((a, b) => a.time.localeCompare(b.time));
        const dayCost = dayStops.reduce((sum, s) => sum + s.cost, 0);
        return (
          <div key={day} className="rounded-3xl glass p-5 sm:p-7">
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-xs uppercase tracking-[0.2em] text-primary">Day {day}</div>
                <div className="mt-1 font-display text-xl">
                  {dayStops[0]?.activity ? dayStops.length + " planned moments" : "Free day"}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground">
                  Est. extras {dayCost > 0 ? inr(dayCost) : "included"}
                </span>
                {editable && onAddDayActivity && (
                  <button
                    onClick={() => onAddDayActivity(day)}
                    className="inline-flex items-center gap-1.5 rounded-full border border-primary/50 px-3 py-1.5 text-xs text-primary transition hover:bg-primary/10"
                  >
                    <Plus className="h-3 w-3" /> Add activity
                  </button>
                )}
              </div>
            </div>

            <ol className="relative space-y-5 border-l border-border/50 pl-6">
              {dayStops.map((s) => (
                <li key={s.key} className="relative">
                  <span className="absolute -left-[31px] top-1.5 grid h-3 w-3 place-items-center rounded-full bg-primary ring-4 ring-background" />
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-xs text-primary">
                        <Clock className="h-3 w-3" />
                        {timeLabel(s.time)}
                      </div>
                      <div className="mt-1 text-sm">{s.activity}</div>
                      <div className="mt-1.5 flex flex-wrap gap-3 text-[11px] text-muted-foreground">
                        {s.location && <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{s.location}</span>}
                        {s.durationMin > 0 && <span>{durationLabel(s.durationMin)}</span>}
                        {s.travelMin > 0 && <span className="inline-flex items-center gap-1"><Bus className="h-3 w-3" />{durationLabel(s.travelMin)} travel</span>}
                        <span className="inline-flex items-center gap-1">
                          <Ticket className="h-3 w-3" />{s.cost > 0 ? inr(s.cost) : "Included"}
                        </span>
                      </div>
                    </div>
                    {editable && s.removable && onRemove && (
                      <button
                        onClick={() => onRemove(s.key)}
                        aria-label={`Remove ${s.activity}`}
                        className="rounded-full border border-border/60 p-2 text-muted-foreground transition hover:border-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ol>
          </div>
        );
      })}
    </div>
  );
}
