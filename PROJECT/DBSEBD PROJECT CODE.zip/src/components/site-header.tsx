import { Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Compass, Menu, X, LogOut, User as UserIcon, LayoutDashboard, ShieldCheck, ShoppingBag,
} from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useCart } from "@/lib/cart";

const NAV = [
  { to: "/destinations", label: "Destinations" },
  { to: "/packages", label: "Packages" },
  { to: "/attractions", label: "Attractions" },
  { to: "/hotels", label: "Hotels" },
  { to: "/about", label: "About" },
] as const;

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <span className="grid h-9 w-9 place-items-center rounded-full glass">
        <Compass className="h-4 w-4 text-primary" />
      </span>
      <span className="font-display text-lg tracking-wide">
        Royal <span className="text-gradient-gold">Voyage</span>
        {!compact && (
          <span className="ml-2 hidden text-[10px] uppercase tracking-[0.25em] text-muted-foreground lg:inline">
            Travel Portal
          </span>
        )}
      </span>
    </span>
  );
}

export function SiteHeader() {
  const { user, isAdmin, signOut } = useAuth();
  const { count, hydrated } = useCart();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await signOut();
    navigate({ to: "/login", replace: true });
  }

  return (
    <header className="sticky top-0 z-50 border-b border-border/40 glass-strong backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3.5 sm:px-6">
        <Link to="/" aria-label="Royal Voyage home">
          <Brand />
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeProps={{ className: "text-primary" }}
              className="rounded-full px-3.5 py-2 text-sm text-muted-foreground transition-colors hover:text-primary"
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <Link to="/cart" className="relative rounded-full glass p-2.5 hover:border-primary" aria-label={`Cart with ${hydrated ? count : 0} items`}>
            <ShoppingBag className="h-4 w-4" />
            {hydrated && count > 0 && <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-primary px-1 text-[10px] font-semibold text-primary-foreground">{count}</span>}
          </Link>
          {user ? (
            <>
              {isAdmin && (
                <Link to="/admin" className="rounded-full glass p-2.5 hover:border-primary" aria-label="Admin">
                  <ShieldCheck className="h-4 w-4" />
                </Link>
              )}
              <Link
                to="/trips"
                className="rounded-full glass px-4 py-2 text-sm transition hover:border-primary"
              >
                <LayoutDashboard className="mr-1.5 inline h-3.5 w-3.5" />
                My Trips
              </Link>
              <Link to="/profile" className="rounded-full glass p-2.5 hover:border-primary" aria-label="Profile">
                <UserIcon className="h-4 w-4" />
              </Link>
              <button onClick={handleSignOut} className="rounded-full glass p-2.5 hover:border-primary" aria-label="Sign out">
                <LogOut className="h-4 w-4" />
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="rounded-full px-4 py-2 text-sm text-muted-foreground hover:text-primary">
                Sign in
              </Link>
              <Link
                to="/register"
                className="rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground transition hover:opacity-90"
              >
                Join
              </Link>
            </>
          )}
        </div>

        <button
          className="rounded-full glass p-2.5 md:hidden"
          onClick={() => setOpen((o) => !o)}
          aria-label="Menu"
        >
          {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-border/40 px-5 py-4 md:hidden">
          <div className="grid gap-1">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setOpen(false)}
                className="rounded-xl px-3 py-2.5 text-sm text-muted-foreground hover:bg-muted/40 hover:text-primary"
              >
                {n.label}
              </Link>
            ))}
            <div className="mt-2 grid gap-2 border-t border-border/40 pt-3">
              <Link to="/cart" onClick={() => setOpen(false)} className="flex items-center justify-between rounded-xl px-3 py-2.5 text-sm"><span className="inline-flex items-center gap-2"><ShoppingBag className="h-4 w-4" />Cart</span>{hydrated && count > 0 && <span className="rounded-full bg-primary px-2 py-0.5 text-xs text-primary-foreground">{count}</span>}</Link>
              {user ? (
                <>
                  <Link to="/trips" onClick={() => setOpen(false)} className="rounded-xl px-3 py-2.5 text-sm">My Trips</Link>
                  <Link to="/profile" onClick={() => setOpen(false)} className="rounded-xl px-3 py-2.5 text-sm">Profile</Link>
                  {isAdmin && <Link to="/admin" onClick={() => setOpen(false)} className="rounded-xl px-3 py-2.5 text-sm">Admin</Link>}
                  <button onClick={handleSignOut} className="rounded-xl px-3 py-2.5 text-left text-sm text-muted-foreground">
                    Sign out
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" onClick={() => setOpen(false)} className="rounded-xl px-3 py-2.5 text-sm">Sign in</Link>
                  <Link
                    to="/register"
                    onClick={() => setOpen(false)}
                    className="rounded-xl bg-primary px-3 py-2.5 text-center text-sm text-primary-foreground"
                  >
                    Join Royal Voyage
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border/40 bg-card/30">
      <div className="mx-auto grid max-w-7xl gap-10 px-6 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Brand compact />
          <p className="mt-4 max-w-xs text-sm text-muted-foreground">
            Discover. Plan. Experience. Your journey, thoughtfully planned — curated
            itineraries, handpicked stays and effortless booking.
          </p>
        </div>
        <div>
          <div className="mb-4 text-xs uppercase tracking-[0.2em] text-primary">Explore</div>
          <ul className="space-y-2.5 text-sm text-muted-foreground">
            <li><Link to="/destinations" className="hover:text-primary">Destinations</Link></li>
            <li><Link to="/packages" search={{ country: undefined, state: undefined, start: undefined, travellers: undefined }} className="hover:text-primary">Travel packages</Link></li>
            <li><Link to="/attractions" className="hover:text-primary">Attractions</Link></li>
            <li><Link to="/hotels" className="hover:text-primary">Hotels & resorts</Link></li>
          </ul>
        </div>
        <div>
          <div className="mb-4 text-xs uppercase tracking-[0.2em] text-primary">Account</div>
          <ul className="space-y-2.5 text-sm text-muted-foreground">
            <li><Link to="/trips" className="hover:text-primary">My trips</Link></li>
            <li><Link to="/cart" className="hover:text-primary">Trip cart</Link></li>
            <li><Link to="/profile" className="hover:text-primary">Profile</Link></li>
            <li><Link to="/login" className="hover:text-primary">Sign in</Link></li>
            <li><Link to="/register" className="hover:text-primary">Create account</Link></li>
          </ul>
        </div>
        <div>
          <div className="mb-4 text-xs uppercase tracking-[0.2em] text-primary">Company</div>
          <ul className="space-y-2.5 text-sm text-muted-foreground">
            <li><Link to="/about" className="hover:text-primary">About us</Link></li>
            <li><Link to="/about" hash="contact" className="hover:text-primary">Contact</Link></li>
            <li><Link to="/about" hash="policies" className="hover:text-primary">Cancellation policy</Link></li>
            <li><Link to="/about" hash="faqs" className="hover:text-primary">FAQs</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/40 px-6 py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Royal Voyage — Travel Package Booking Portal. Catalogue
        availability and prices are loaded from the current database; payments run in demo mode.
      </div>
    </footer>
  );
}

/** Standard page frame: sticky nav + content + footer. */
export function SiteShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <div className="flex-1">{children}</div>
      <SiteFooter />
    </div>
  );
}

export function AuthGate({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center text-muted-foreground">
        Preparing your journey…
      </div>
    );
  }
  if (!user) {
    if (typeof window !== "undefined") navigate({ to: "/login", replace: true });
    return null;
  }
  return <>{children}</>;
}

export function AdminGate({ children }: { children: React.ReactNode }) {
  const { user, isAdmin, loading, profile } = useAuth();
  const navigate = useNavigate();
  if (loading || (user && !profile)) {
    return <div className="grid min-h-screen place-items-center text-muted-foreground">Checking access…</div>;
  }
  if (!user) {
    if (typeof window !== "undefined") navigate({ to: "/login", replace: true });
    return null;
  }
  if (!isAdmin) {
    return (
      <div className="grid min-h-screen place-items-center px-6 text-center">
        <div>
          <h1 className="font-display text-3xl">Admin access required</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            This area is restricted to Royal Voyage operations staff.
          </p>
          <Link to="/trips" className="mt-6 inline-block rounded-full bg-primary px-6 py-2.5 text-sm text-primary-foreground">
            Back to my trips
          </Link>
        </div>
      </div>
    );
  }
  return <>{children}</>;
}

