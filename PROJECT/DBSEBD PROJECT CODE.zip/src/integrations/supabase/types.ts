export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      booking_history: {
        Row: {
          booking_id: string
          created_at: string
          id: string
          note: string
          status: Database["public"]["Enums"]["booking_status"]
        }
        Insert: {
          booking_id: string
          created_at?: string
          id?: string
          note?: string
          status: Database["public"]["Enums"]["booking_status"]
        }
        Update: {
          booking_id?: string
          created_at?: string
          id?: string
          note?: string
          status?: Database["public"]["Enums"]["booking_status"]
        }
        Relationships: [
          {
            foreignKeyName: "booking_history_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      bookings: {
        Row: {
          addon_amount: number
          addons: string[]
          adults: number
          booking_ref: string
          children: number
          created_at: string
          end_date: string
          hotel_amount: number
          hotel_id: string | null
          id: string
          notes: string
          package_amount: number
          package_id: string
          room_id: string | null
          rooms_count: number
          start_date: string
          status: Database["public"]["Enums"]["booking_status"]
          taxes: number
          total_amount: number
          travellers: number
          updated_at: string
          user_id: string
        }
        Insert: {
          addon_amount?: number
          addons?: string[]
          adults?: number
          booking_ref: string
          children?: number
          created_at?: string
          end_date: string
          hotel_amount?: number
          hotel_id?: string | null
          id?: string
          notes?: string
          package_amount?: number
          package_id: string
          room_id?: string | null
          rooms_count?: number
          start_date: string
          status?: Database["public"]["Enums"]["booking_status"]
          taxes?: number
          total_amount?: number
          travellers?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          addon_amount?: number
          addons?: string[]
          adults?: number
          booking_ref?: string
          children?: number
          created_at?: string
          end_date?: string
          hotel_amount?: number
          hotel_id?: string | null
          id?: string
          notes?: string
          package_amount?: number
          package_id?: string
          room_id?: string | null
          rooms_count?: number
          start_date?: string
          status?: Database["public"]["Enums"]["booking_status"]
          taxes?: number
          total_amount?: number
          travellers?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookings_hotel_id_fkey"
            columns: ["hotel_id"]
            isOneToOne: false
            referencedRelation: "hotels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "travel_packages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "rooms"
            referencedColumns: ["id"]
          },
        ]
      }
      cities: {
        Row: {
          best_season: string
          created_at: string
          daily_budget: number
          description: string
          id: string
          image_url: string
          name: string
          recommended_days: number
          slug: string
          state_id: string
          updated_at: string
        }
        Insert: {
          best_season?: string
          created_at?: string
          daily_budget?: number
          description?: string
          id?: string
          image_url?: string
          name: string
          recommended_days?: number
          slug: string
          state_id: string
          updated_at?: string
        }
        Update: {
          best_season?: string
          created_at?: string
          daily_budget?: number
          description?: string
          id?: string
          image_url?: string
          name?: string
          recommended_days?: number
          slug?: string
          state_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "cities_state_id_fkey"
            columns: ["state_id"]
            isOneToOne: false
            referencedRelation: "states"
            referencedColumns: ["id"]
          },
        ]
      }
      countries: {
        Row: {
          best_season: string
          code: string
          created_at: string
          currency: string
          description: string
          id: string
          image_url: string
          name: string
          slug: string
          starting_price: number
          updated_at: string
        }
        Insert: {
          best_season?: string
          code: string
          created_at?: string
          currency?: string
          description?: string
          id?: string
          image_url?: string
          name: string
          slug: string
          starting_price?: number
          updated_at?: string
        }
        Update: {
          best_season?: string
          code?: string
          created_at?: string
          currency?: string
          description?: string
          id?: string
          image_url?: string
          name?: string
          slug?: string
          starting_price?: number
          updated_at?: string
        }
        Relationships: []
      }
      feedback: {
        Row: {
          comment: string
          created_at: string
          food_rating: number
          id: string
          order_id: string | null
          service_rating: number
          user_id: string
        }
        Insert: {
          comment?: string
          created_at?: string
          food_rating?: number
          id?: string
          order_id?: string | null
          service_rating?: number
          user_id: string
        }
        Update: {
          comment?: string
          created_at?: string
          food_rating?: number
          id?: string
          order_id?: string | null
          service_rating?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "feedback_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      hotels: {
        Row: {
          address: string
          amenities: string[]
          city_id: string
          created_at: string
          description: string
          id: string
          image_url: string
          name: string
          rating: number
          registration_no: string
          slug: string
          star_rating: number
          updated_at: string
        }
        Insert: {
          address?: string
          amenities?: string[]
          city_id: string
          created_at?: string
          description?: string
          id?: string
          image_url?: string
          name: string
          rating?: number
          registration_no: string
          slug: string
          star_rating?: number
          updated_at?: string
        }
        Update: {
          address?: string
          amenities?: string[]
          city_id?: string
          created_at?: string
          description?: string
          id?: string
          image_url?: string
          name?: string
          rating?: number
          registration_no?: string
          slug?: string
          star_rating?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "hotels_city_id_fkey"
            columns: ["city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
        ]
      }
      menu_categories: {
        Row: {
          id: string
          name: string
          slug: string
          sort_order: number
        }
        Insert: {
          id?: string
          name: string
          slug: string
          sort_order?: number
        }
        Update: {
          id?: string
          name?: string
          slug?: string
          sort_order?: number
        }
        Relationships: []
      }
      menu_items: {
        Row: {
          category_id: string
          created_at: string
          description: string
          diet_type: Database["public"]["Enums"]["diet_type"]
          id: string
          image_url: string
          is_available: boolean
          name: string
          prep_time_min: number
          price: number
          rating: number
        }
        Insert: {
          category_id: string
          created_at?: string
          description?: string
          diet_type?: Database["public"]["Enums"]["diet_type"]
          id?: string
          image_url?: string
          is_available?: boolean
          name: string
          prep_time_min?: number
          price: number
          rating?: number
        }
        Update: {
          category_id?: string
          created_at?: string
          description?: string
          diet_type?: Database["public"]["Enums"]["diet_type"]
          id?: string
          image_url?: string
          is_available?: boolean
          name?: string
          prep_time_min?: number
          price?: number
          rating?: number
        }
        Relationships: [
          {
            foreignKeyName: "menu_items_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "menu_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          body: string
          created_at: string
          id: string
          read: boolean
          title: string
          user_id: string
        }
        Insert: {
          body?: string
          created_at?: string
          id?: string
          read?: boolean
          title: string
          user_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          read?: boolean
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      order_items: {
        Row: {
          id: string
          menu_item_id: string | null
          name_snapshot: string
          order_id: string
          price_snapshot: number
          quantity: number
        }
        Insert: {
          id?: string
          menu_item_id?: string | null
          name_snapshot: string
          order_id: string
          price_snapshot: number
          quantity?: number
        }
        Update: {
          id?: string
          menu_item_id?: string | null
          name_snapshot?: string
          order_id?: string
          price_snapshot?: number
          quantity?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_items_menu_item_id_fkey"
            columns: ["menu_item_id"]
            isOneToOne: false
            referencedRelation: "menu_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          created_at: string
          gst: number
          id: string
          notes: string
          payment_method: Database["public"]["Enums"]["payment_method"]
          payment_status: Database["public"]["Enums"]["payment_status"]
          room_number: string
          service_charge: number
          status: Database["public"]["Enums"]["order_status"]
          subtotal: number
          total: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          gst?: number
          id?: string
          notes?: string
          payment_method?: Database["public"]["Enums"]["payment_method"]
          payment_status?: Database["public"]["Enums"]["payment_status"]
          room_number?: string
          service_charge?: number
          status?: Database["public"]["Enums"]["order_status"]
          subtotal?: number
          total?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          gst?: number
          id?: string
          notes?: string
          payment_method?: Database["public"]["Enums"]["payment_method"]
          payment_status?: Database["public"]["Enums"]["payment_status"]
          room_number?: string
          service_charge?: number
          status?: Database["public"]["Enums"]["order_status"]
          subtotal?: number
          total?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      package_itinerary: {
        Row: {
          activity: string
          city_id: string | null
          day_number: number
          day_title: string
          duration_min: number
          id: string
          package_id: string
          place_id: string | null
          sort_order: number
          start_time: string
          travel_min: number
          weather_sensitive: boolean
        }
        Insert: {
          activity: string
          city_id?: string | null
          day_number: number
          day_title?: string
          duration_min?: number
          id?: string
          package_id: string
          place_id?: string | null
          sort_order?: number
          start_time?: string
          travel_min?: number
          weather_sensitive?: boolean
        }
        Update: {
          activity?: string
          city_id?: string | null
          day_number?: number
          day_title?: string
          duration_min?: number
          id?: string
          package_id?: string
          place_id?: string | null
          sort_order?: number
          start_time?: string
          travel_min?: number
          weather_sensitive?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "package_itinerary_city_id_fkey"
            columns: ["city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "package_itinerary_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "travel_packages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "package_itinerary_place_id_fkey"
            columns: ["place_id"]
            isOneToOne: false
            referencedRelation: "tourist_places"
            referencedColumns: ["id"]
          },
        ]
      }
      package_places: {
        Row: {
          id: string
          package_id: string
          place_id: string
          sort_order: number
        }
        Insert: {
          id?: string
          package_id: string
          place_id: string
          sort_order?: number
        }
        Update: {
          id?: string
          package_id?: string
          place_id?: string
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "package_places_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "travel_packages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "package_places_place_id_fkey"
            columns: ["place_id"]
            isOneToOne: false
            referencedRelation: "tourist_places"
            referencedColumns: ["id"]
          },
        ]
      }
      payments: {
        Row: {
          amount: number
          booking_id: string
          created_at: string
          id: string
          method: Database["public"]["Enums"]["payment_method"]
          reference: string
          status: Database["public"]["Enums"]["payment_status"]
          user_id: string
        }
        Insert: {
          amount: number
          booking_id: string
          created_at?: string
          id?: string
          method?: Database["public"]["Enums"]["payment_method"]
          reference?: string
          status?: Database["public"]["Enums"]["payment_status"]
          user_id: string
        }
        Update: {
          amount?: number
          booking_id?: string
          created_at?: string
          id?: string
          method?: Database["public"]["Enums"]["payment_method"]
          reference?: string
          status?: Database["public"]["Enums"]["payment_status"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          email: string
          full_name: string
          id: string
          loyalty_points: number
          phone: string
          room_number: string
        }
        Insert: {
          created_at?: string
          email?: string
          full_name?: string
          id: string
          loyalty_points?: number
          phone?: string
          room_number?: string
        }
        Update: {
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          loyalty_points?: number
          phone?: string
          room_number?: string
        }
        Relationships: []
      }
      reviews: {
        Row: {
          comment: string
          created_at: string
          hotel_id: string | null
          id: string
          package_id: string | null
          rating: number
          reviewer_name: string
          user_id: string | null
        }
        Insert: {
          comment?: string
          created_at?: string
          hotel_id?: string | null
          id?: string
          package_id?: string | null
          rating: number
          reviewer_name?: string
          user_id?: string | null
        }
        Update: {
          comment?: string
          created_at?: string
          hotel_id?: string | null
          id?: string
          package_id?: string | null
          rating?: number
          reviewer_name?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "reviews_hotel_id_fkey"
            columns: ["hotel_id"]
            isOneToOne: false
            referencedRelation: "hotels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "travel_packages"
            referencedColumns: ["id"]
          },
        ]
      }
      rooms: {
        Row: {
          available_units: number
          created_at: string
          description: string
          hotel_id: string
          id: string
          image_url: string
          max_guests: number
          price_per_night: number
          room_type: string
          total_units: number
          updated_at: string
        }
        Insert: {
          available_units?: number
          created_at?: string
          description?: string
          hotel_id: string
          id?: string
          image_url?: string
          max_guests?: number
          price_per_night: number
          room_type: string
          total_units?: number
          updated_at?: string
        }
        Update: {
          available_units?: number
          created_at?: string
          description?: string
          hotel_id?: string
          id?: string
          image_url?: string
          max_guests?: number
          price_per_night?: number
          room_type?: string
          total_units?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "rooms_hotel_id_fkey"
            columns: ["hotel_id"]
            isOneToOne: false
            referencedRelation: "hotels"
            referencedColumns: ["id"]
          },
        ]
      }
      routes: {
        Row: {
          distance_km: number
          from_city_id: string
          id: string
          notes: string
          road_condition: string
          road_status: string
          to_city_id: string
          traffic_level: string
          travel_min: number
          updated_at: string
        }
        Insert: {
          distance_km: number
          from_city_id: string
          id?: string
          notes?: string
          road_condition?: string
          road_status?: string
          to_city_id: string
          traffic_level?: string
          travel_min: number
          updated_at?: string
        }
        Update: {
          distance_km?: number
          from_city_id?: string
          id?: string
          notes?: string
          road_condition?: string
          road_status?: string
          to_city_id?: string
          traffic_level?: string
          travel_min?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "routes_from_city_id_fkey"
            columns: ["from_city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "routes_to_city_id_fkey"
            columns: ["to_city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
        ]
      }
      saved_trips: {
        Row: {
          created_at: string
          id: string
          package_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          package_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          package_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "saved_trips_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "travel_packages"
            referencedColumns: ["id"]
          },
        ]
      }
      service_items: {
        Row: {
          description: string
          duration_min: number
          id: string
          image_url: string
          is_active: boolean
          name: string
          price: number
          type: Database["public"]["Enums"]["service_type"]
        }
        Insert: {
          description?: string
          duration_min?: number
          id?: string
          image_url?: string
          is_active?: boolean
          name: string
          price?: number
          type: Database["public"]["Enums"]["service_type"]
        }
        Update: {
          description?: string
          duration_min?: number
          id?: string
          image_url?: string
          is_active?: boolean
          name?: string
          price?: number
          type?: Database["public"]["Enums"]["service_type"]
        }
        Relationships: []
      }
      service_requests: {
        Row: {
          created_at: string
          id: string
          item_name: string
          notes: string
          room_number: string
          scheduled_at: string | null
          service_item_id: string | null
          status: Database["public"]["Enums"]["service_request_status"]
          type: Database["public"]["Enums"]["service_type"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          item_name: string
          notes?: string
          room_number?: string
          scheduled_at?: string | null
          service_item_id?: string | null
          status?: Database["public"]["Enums"]["service_request_status"]
          type: Database["public"]["Enums"]["service_type"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          item_name?: string
          notes?: string
          room_number?: string
          scheduled_at?: string | null
          service_item_id?: string | null
          status?: Database["public"]["Enums"]["service_request_status"]
          type?: Database["public"]["Enums"]["service_type"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_requests_service_item_id_fkey"
            columns: ["service_item_id"]
            isOneToOne: false
            referencedRelation: "service_items"
            referencedColumns: ["id"]
          },
        ]
      }
      states: {
        Row: {
          best_season: string
          country_id: string
          created_at: string
          description: string
          id: string
          image_url: string
          name: string
          slug: string
          starting_price: number
          updated_at: string
        }
        Insert: {
          best_season?: string
          country_id: string
          created_at?: string
          description?: string
          id?: string
          image_url?: string
          name: string
          slug: string
          starting_price?: number
          updated_at?: string
        }
        Update: {
          best_season?: string
          country_id?: string
          created_at?: string
          description?: string
          id?: string
          image_url?: string
          name?: string
          slug?: string
          starting_price?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "states_country_id_fkey"
            columns: ["country_id"]
            isOneToOne: false
            referencedRelation: "countries"
            referencedColumns: ["id"]
          },
        ]
      }
      tourist_places: {
        Row: {
          best_season: string
          category: string
          city_id: string
          closing_time: string
          created_at: string
          description: string
          entry_fee: number
          id: string
          image_url: string
          is_indoor: boolean
          name: string
          opening_time: string
          slug: string
          status: Database["public"]["Enums"]["place_status"]
          updated_at: string
          visit_duration_min: number
          weather_sensitive: boolean
        }
        Insert: {
          best_season?: string
          category?: string
          city_id: string
          closing_time?: string
          created_at?: string
          description?: string
          entry_fee?: number
          id?: string
          image_url?: string
          is_indoor?: boolean
          name: string
          opening_time?: string
          slug: string
          status?: Database["public"]["Enums"]["place_status"]
          updated_at?: string
          visit_duration_min?: number
          weather_sensitive?: boolean
        }
        Update: {
          best_season?: string
          category?: string
          city_id?: string
          closing_time?: string
          created_at?: string
          description?: string
          entry_fee?: number
          id?: string
          image_url?: string
          is_indoor?: boolean
          name?: string
          opening_time?: string
          slug?: string
          status?: Database["public"]["Enums"]["place_status"]
          updated_at?: string
          visit_duration_min?: number
          weather_sensitive?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "tourist_places_city_id_fkey"
            columns: ["city_id"]
            isOneToOne: false
            referencedRelation: "cities"
            referencedColumns: ["id"]
          },
        ]
      }
      travel_packages: {
        Row: {
          best_season: string
          booked_count: number
          capacity: number
          country_id: string
          created_at: string
          description: string
          duration_days: number
          duration_nights: number
          hotel_category: string
          id: string
          image_url: string
          inclusions: string[]
          meals: string
          name: string
          package_code: string
          price: number
          rating: number
          slug: string
          state_id: string | null
          transportation: string
          travel_style: string
          updated_at: string
        }
        Insert: {
          best_season?: string
          booked_count?: number
          capacity?: number
          country_id: string
          created_at?: string
          description?: string
          duration_days: number
          duration_nights: number
          hotel_category?: string
          id?: string
          image_url?: string
          inclusions?: string[]
          meals?: string
          name: string
          package_code: string
          price: number
          rating?: number
          slug: string
          state_id?: string | null
          transportation?: string
          travel_style?: string
          updated_at?: string
        }
        Update: {
          best_season?: string
          booked_count?: number
          capacity?: number
          country_id?: string
          created_at?: string
          description?: string
          duration_days?: number
          duration_nights?: number
          hotel_category?: string
          id?: string
          image_url?: string
          inclusions?: string[]
          meals?: string
          name?: string
          package_code?: string
          price?: number
          rating?: number
          slug?: string
          state_id?: string | null
          transportation?: string
          travel_style?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "travel_packages_country_id_fkey"
            columns: ["country_id"]
            isOneToOne: false
            referencedRelation: "countries"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "travel_packages_state_id_fkey"
            columns: ["state_id"]
            isOneToOne: false
            referencedRelation: "states"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      create_travel_booking: {
        Args: {
          _addon_amount: number
          _addons: string[]
          _adults: number
          _children: number
          _end_date: string
          _hotel_amount: number
          _hotel_id: string
          _method: Database["public"]["Enums"]["payment_method"]
          _notes: string
          _package_amount: number
          _package_id: string
          _room_id: string
          _rooms_count: number
          _start_date: string
          _taxes: number
          _total: number
        }
        Returns: {
          addon_amount: number
          addons: string[]
          adults: number
          booking_ref: string
          children: number
          created_at: string
          end_date: string
          hotel_amount: number
          hotel_id: string | null
          id: string
          notes: string
          package_amount: number
          package_id: string
          room_id: string | null
          rooms_count: number
          start_date: string
          status: Database["public"]["Enums"]["booking_status"]
          taxes: number
          total_amount: number
          travellers: number
          updated_at: string
          user_id: string
        }
        SetofOptions: {
          from: "*"
          to: "bookings"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "guest"
      booking_status:
        | "pending"
        | "confirmed"
        | "in_progress"
        | "completed"
        | "cancelled"
      diet_type: "veg" | "non_veg" | "vegan"
      order_status:
        | "confirmed"
        | "preparing"
        | "chef_assigned"
        | "out_for_delivery"
        | "delivered"
        | "cancelled"
      payment_method:
        | "upi"
        | "credit_card"
        | "debit_card"
        | "net_banking"
        | "cod"
      payment_status: "pending" | "paid" | "failed"
      place_status: "open" | "closed" | "seasonal" | "maintenance"
      service_request_status:
        | "pending"
        | "in_progress"
        | "completed"
        | "cancelled"
      service_type: "housekeeping" | "laundry" | "spa"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "guest"],
      booking_status: [
        "pending",
        "confirmed",
        "in_progress",
        "completed",
        "cancelled",
      ],
      diet_type: ["veg", "non_veg", "vegan"],
      order_status: [
        "confirmed",
        "preparing",
        "chef_assigned",
        "out_for_delivery",
        "delivered",
        "cancelled",
      ],
      payment_method: [
        "upi",
        "credit_card",
        "debit_card",
        "net_banking",
        "cod",
      ],
      payment_status: ["pending", "paid", "failed"],
      place_status: ["open", "closed", "seasonal", "maintenance"],
      service_request_status: [
        "pending",
        "in_progress",
        "completed",
        "cancelled",
      ],
      service_type: ["housekeeping", "laundry", "spa"],
    },
  },
} as const
