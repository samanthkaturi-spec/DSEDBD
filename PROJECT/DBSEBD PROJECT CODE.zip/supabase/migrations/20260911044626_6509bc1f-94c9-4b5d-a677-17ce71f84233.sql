
-- 1. Fix package country to match its state's country
UPDATE public.travel_packages tp
SET country_id = s.country_id
FROM public.states s
WHERE tp.state_id = s.id AND tp.country_id <> s.country_id;

-- 2. Reviews: allow curated sample testimonials
ALTER TABLE public.reviews ADD COLUMN IF NOT EXISTS reviewer_name text NOT NULL DEFAULT '';
ALTER TABLE public.reviews ALTER COLUMN user_id DROP NOT NULL;

-- 3. Lock booking RPC to authenticated users
REVOKE ALL ON FUNCTION public.create_travel_booking(uuid,uuid,uuid,date,date,integer,integer,integer,text[],numeric,numeric,numeric,numeric,numeric,payment_method,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.create_travel_booking(uuid,uuid,uuid,date,date,integer,integer,integer,text[],numeric,numeric,numeric,numeric,numeric,payment_method,text) TO authenticated;

-- 4. New cities
INSERT INTO public.cities (state_id, name, slug, image_url, description, best_season, recommended_days, daily_budget)
SELECT s.id, v.name, v.slug, v.image_url, v.description, v.best_season, v.recommended_days, v.daily_budget
FROM (VALUES
 ('rajasthan','Jodhpur','jodhpur','https://images.unsplash.com/photo-1477587458883-47145ed94245?w=1200','The Blue City, ringed by indigo houses beneath the colossal Mehrangarh Fort.','October to March',2,4200),
 ('goa','Panaji','panaji','https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=1200','Goa''s riverside capital, all Latin quarters, pastel facades and Mandovi cruises.','November to February',2,3800),
 ('telangana','Warangal','warangal','https://images.unsplash.com/photo-1600100397608-f010bb01a3a1?w=1200','Kakatiya capital famed for its thousand-pillar temple and ruined stone fort.','October to February',2,2800),
 ('abu-dhabi','Abu Dhabi','abu-dhabi-city','https://images.unsplash.com/photo-1512632578888-169bbbc64f33?w=1200','The UAE capital: grand mosques, island museums and Formula-1 speed.','November to March',3,12000)
) AS v(state_slug,name,slug,image_url,description,best_season,recommended_days,daily_budget)
JOIN public.states s ON s.slug = v.state_slug
WHERE NOT EXISTS (SELECT 1 FROM public.cities c WHERE c.slug = v.slug);

-- 5. New attractions
INSERT INTO public.tourist_places (city_id,name,slug,category,description,image_url,opening_time,closing_time,entry_fee,visit_duration_min,best_season,weather_sensitive,is_indoor,status)
SELECT c.id, v.name, v.slug, v.category, v.description, v.image_url, v.o::time, v.cl::time, v.fee, v.dur, v.season, v.wsens, v.indoor, 'open'::place_status
FROM (VALUES
 ('jaipur','Jantar Mantar','jantar-mantar','Heritage','UNESCO-listed 18th-century astronomical observatory with the world''s largest stone sundial.','https://images.unsplash.com/photo-1599661046289-e31897846e41?w=1200','09:00','16:30',200,60,'October to March',true,false),
 ('munnar','Top Station','top-station','Nature','Munnar''s highest viewpoint, looking out over the Theni valley through drifting cloud.','https://images.unsplash.com/photo-1580741569354-08feacf1b3a1?w=1200','07:00','18:00',30,90,'September to March',true,false),
 ('hyderabad','Hussain Sagar','hussain-sagar','Nature','Heart-shaped lake with the monolithic Buddha statue and sunset boat rides.','https://images.unsplash.com/photo-1572445271230-a78b5944a659?w=1200','08:00','22:00',60,90,'October to February',true,false),
 ('hyderabad','Ramoji Film City','ramoji-film-city','Entertainment','The world''s largest film studio complex — sets, shows and themed gardens.','https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=1200','09:00','17:30',1350,480,'October to February',false,false),
 ('north-goa','Calangute Beach','calangute-beach','Beach','The Queen of Beaches — a broad golden sweep lined with shacks and water sports.','https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=1200','06:00','21:00',0,180,'November to February',true,false),
 ('north-goa','Basilica of Bom Jesus','basilica-of-bom-jesus','Heritage','UNESCO baroque basilica in Old Goa holding the relics of St Francis Xavier.','https://images.unsplash.com/photo-1590766940554-153a4d9f2a3a?w=1200','09:00','18:30',0,60,'November to February',false,true),
 ('jodhpur','Mehrangarh Fort','mehrangarh-fort','Heritage','One of India''s largest forts, rising 120m above the blue city on a sandstone bluff.','https://images.unsplash.com/photo-1477587458883-47145ed94245?w=1200','09:00','17:00',600,150,'October to March',false,false),
 ('jodhpur','Umaid Bhawan Palace','umaid-bhawan-palace','Heritage','Art-deco royal residence and museum, part still home to the Jodhpur royal family.','https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=1200','09:00','17:00',100,90,'October to March',false,true),
 ('jodhpur','Toorji Ka Jhalra','toorji-ka-jhalra','Heritage','An 18th-century stepwell restored into the city''s most photogenic gathering spot.','https://images.unsplash.com/photo-1609920658906-8223bd289001?w=1200','06:00','20:00',0,45,'October to March',true,false),
 ('warangal','Warangal Fort','warangal-fort','Heritage','Kakatiya-era ruins with four ornate stone gateways standing in open fields.','https://images.unsplash.com/photo-1600100397608-f010bb01a3a1?w=1200','09:00','17:30',25,90,'October to February',true,false),
 ('warangal','Thousand Pillar Temple','thousand-pillar-temple','Heritage','A 12th-century star-shaped Chalukyan temple carved from black basalt.','https://images.unsplash.com/photo-1621496654598-0d0d6a3a6b1a?w=1200','06:00','20:00',0,60,'October to February',false,true),
 ('panaji','Fontainhas Latin Quarter','fontainhas','Heritage','Portuguese-era lanes of ochre, indigo and lime-green heritage homes.','https://images.unsplash.com/photo-1590766940554-153a4d9f2a3a?w=1200','07:00','19:00',0,90,'November to February',true,false),
 ('panaji','Mandovi River Cruise','mandovi-river-cruise','Experience','Sunset cruise with live Goan folk music along the Mandovi.','https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=1200','17:00','21:00',400,60,'November to February',true,false),
 ('abu-dhabi-city','Sheikh Zayed Grand Mosque','sheikh-zayed-grand-mosque','Heritage','Marble-and-mother-of-pearl masterpiece holding 40,000 worshippers.','https://images.unsplash.com/photo-1512632578888-169bbbc64f33?w=1200','09:00','22:00',0,120,'November to March',false,true),
 ('abu-dhabi-city','Louvre Abu Dhabi','louvre-abu-dhabi','Museum','Jean Nouvel''s domed museum on Saadiyat Island, raining light over the galleries.','https://images.unsplash.com/photo-1583037189850-1921ae7c6c22?w=1200','10:00','18:30',1500,150,'November to March',false,true),
 ('abu-dhabi-city','Ferrari World','ferrari-world','Entertainment','Yas Island theme park home to the world''s fastest roller coaster.','https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=1200','11:00','20:00',6500,300,'November to March',false,true)
) AS v(city_slug,name,slug,category,description,image_url,o,cl,fee,dur,season,wsens,indoor)
JOIN public.cities c ON c.slug = v.city_slug
WHERE NOT EXISTS (SELECT 1 FROM public.tourist_places t WHERE t.slug = v.slug);

-- 6. Hotels for cities lacking them
INSERT INTO public.hotels (city_id,registration_no,name,slug,description,image_url,star_rating,rating,address,amenities)
SELECT c.id, v.reg, v.name, v.slug, v.description, v.image_url, v.stars, v.rating, v.address, v.amenities::text[]
FROM (VALUES
 ('coorg','REG-CRG-1101','Tamara Coorg Retreat','tamara-coorg-retreat','Plantation villas tucked into a working coffee estate.','https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200',5,4.7,'Kabbinakad Estate, Coorg','{"Infinity pool","Spa","Plantation walks","Fine dining","Free Wi-Fi"}'),
 ('jaisalmer','REG-JSM-1102','Suryagarh Desert Palace','suryagarh-desert-palace','Sandstone fortress hotel on the edge of the Thar.','https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=1200',5,4.8,'Kahala Phata, Jaisalmer','{"Pool","Spa","Desert safari","Heritage dining","Free Wi-Fi"}'),
 ('udaipur','REG-UDR-1103','Lake Pichola Haveli','lake-pichola-haveli','Lakefront haveli with rooftop views of the City Palace.','https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=1200',4,4.6,'Outside Chandpole, Udaipur','{"Lake view","Rooftop restaurant","Airport transfer","Free Wi-Fi"}'),
 ('ooty','REG-OTY-1104','Nilgiri Colonial Lodge','nilgiri-colonial-lodge','Restored British-era lodge amid eucalyptus gardens.','https://images.unsplash.com/photo-1445019980597-93fa8acb246c?w=1200',4,4.4,'Havelock Road, Ooty','{"Garden","Fireplace lounge","Breakfast","Free Wi-Fi"}'),
 ('thekkady','REG-TKD-1105','Periyar Spice Resort','periyar-spice-resort','Spice-garden cottages minutes from the tiger reserve gate.','https://images.unsplash.com/photo-1540541338287-41700207dee6?w=1200',4,4.5,'Thekkady Junction, Idukki','{"Ayurvedic spa","Pool","Nature walks","Free Wi-Fi"}'),
 ('jodhpur','REG-JDH-1106','Raas Blue City Palace','raas-blue-city-palace','Contemporary heritage hotel facing Mehrangarh Fort.','https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=1200',5,4.8,'Tunwarji Ka Jhalra, Jodhpur','{"Fort view","Pool","Spa","Fine dining","Free Wi-Fi"}'),
 ('panaji','REG-PNJ-1107','Mandovi Riverside Hotel','mandovi-riverside-hotel','Riverfront rooms in the heart of Panaji''s Latin quarter.','https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200',4,4.3,'D B Marg, Panaji','{"River view","Pool","Restaurant","Free Wi-Fi"}'),
 ('warangal','REG-WGL-1108','Kakatiya Grand Warangal','kakatiya-grand-warangal','Comfortable business-class base for the fort circuit.','https://images.unsplash.com/photo-1590490360182-c33d57733427?w=1200',3,4.1,'Hanamkonda, Warangal','{"Restaurant","Airport transfer","Breakfast","Free Wi-Fi"}'),
 ('abu-dhabi-city','REG-AUH-1109','Saadiyat Shores Resort','saadiyat-shores-resort','Beachfront resort steps from Louvre Abu Dhabi.','https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=1200',5,4.9,'Saadiyat Island, Abu Dhabi','{"Private beach","Spa","Pools","Fine dining","Free Wi-Fi"}'),
 ('kyoto','REG-KYT-1110','Gion Machiya Ryokan','gion-machiya-ryokan','Townhouse ryokan with tatami suites and kaiseki dining.','https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=1200',5,4.9,'Gion, Higashiyama, Kyoto','{"Onsen bath","Kaiseki dining","Garden","Free Wi-Fi"}'),
 ('florence','REG-FLR-1111','Palazzo Arno Firenze','palazzo-arno-firenze','Renaissance palazzo overlooking the Ponte Vecchio.','https://images.unsplash.com/photo-1543429776-2782fc8e1acd?w=1200',5,4.8,'Lungarno Acciaiuoli, Florence','{"River view","Rooftop bar","Concierge","Free Wi-Fi"}'),
 ('kuala-lumpur-city','REG-KUL-1112','Bukit Bintang Sky Hotel','bukit-bintang-sky-hotel','Skyline rooms with Petronas Towers views.','https://images.unsplash.com/photo-1590490360182-c33d57733427?w=1200',4,4.5,'Bukit Bintang, Kuala Lumpur','{"Infinity pool","Gym","Restaurant","Free Wi-Fi"}'),
 ('singapore-city','REG-SIN-1113','Marina Bay Horizon','marina-bay-horizon','Design hotel a short walk from Gardens by the Bay.','https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=1200',5,4.8,'Marina Boulevard, Singapore','{"Rooftop pool","Spa","Fine dining","Free Wi-Fi"}'),
 ('phuket','REG-HKT-1114','Kata Bay Beach Resort','kata-bay-beach-resort','Low-rise resort on a quiet stretch of Kata beach.','https://images.unsplash.com/photo-1540541338287-41700207dee6?w=1200',4,4.6,'Kata Noi, Phuket','{"Private beach","Pool","Spa","Free Wi-Fi"}')
) AS v(city_slug,reg,name,slug,description,image_url,stars,rating,address,amenities)
JOIN public.cities c ON c.slug = v.city_slug
WHERE NOT EXISTS (SELECT 1 FROM public.hotels h WHERE h.slug = v.slug);

-- 7. Rooms for every hotel that has none
INSERT INTO public.rooms (hotel_id, room_type, description, image_url, price_per_night, max_guests, total_units, available_units)
SELECT h.id, r.room_type, r.description, r.image_url,
       round((r.base * CASE h.star_rating WHEN 5 THEN 2.2 WHEN 4 THEN 1.4 ELSE 1.0 END)::numeric, 0),
       r.guests, r.units, r.units
FROM public.hotels h
CROSS JOIN (VALUES
 ('Deluxe Room','Warm, generously sized room with garden or city outlook.','https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=1200',4500,2,12),
 ('Premium Suite','Separate living area, plush bedding and a private balcony.','https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=1200',8500,3,6)
) AS r(room_type,description,image_url,base,guests,units)
WHERE NOT EXISTS (SELECT 1 FROM public.rooms rm WHERE rm.hotel_id = h.id);

-- 8. Sample traveller stories (clearly-seeded catalogue content, no user account attached)
INSERT INTO public.reviews (user_id, package_id, hotel_id, rating, comment, reviewer_name)
SELECT NULL, p.id, NULL, v.rating, v.comment, v.reviewer
FROM (VALUES
 ('munnar-tea-country-escape',5,'The tea estate sunrise alone was worth the trip. Transfers were punctual and the guide was superb.','Ananya Menon'),
 ('royal-rajasthan-heritage',5,'Three cities, zero stress. The Amber Fort early-entry slot made all the difference.','Rohit Kapoor'),
 ('goa-beach-indulgence',4,'Great beachfront hotel and a lovely sunset cruise. Would have liked one more free evening.','Priya Nair'),
 ('kerala-grand-explorer',5,'The houseboat night in Alleppey is something our family still talks about.','Sandeep Iyer'),
 ('dubai-luxury-discovery',5,'Desert safari and the Burj observation deck were flawlessly organised.','Meera Shah'),
 ('hyderabad-nizami-trail',4,'Charminar, Golconda and unforgettable biryani in two days. Excellent value.','Vikram Reddy')
) AS v(pkg_slug,rating,comment,reviewer)
JOIN public.travel_packages p ON p.slug = v.pkg_slug
WHERE NOT EXISTS (SELECT 1 FROM public.reviews r WHERE r.reviewer_name = v.reviewer);
