-- ============ GEOGRAPHY ============
CREATE TABLE public.countries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL UNIQUE,
  slug text NOT NULL UNIQUE,
  image_url text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  best_season text NOT NULL DEFAULT '',
  currency text NOT NULL DEFAULT 'INR',
  starting_price numeric NOT NULL DEFAULT 0 CHECK (starting_price >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.countries TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.countries TO authenticated;
GRANT ALL ON public.countries TO service_role;
ALTER TABLE public.countries ENABLE ROW LEVEL SECURITY;
CREATE POLICY countries_read ON public.countries FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY countries_admin ON public.countries FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TABLE public.states (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country_id uuid NOT NULL REFERENCES public.countries(id) ON DELETE CASCADE,
  name text NOT NULL,
  slug text NOT NULL,
  image_url text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  best_season text NOT NULL DEFAULT '',
  starting_price numeric NOT NULL DEFAULT 0 CHECK (starting_price >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (country_id, slug)
);
GRANT SELECT ON public.states TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.states TO authenticated;
GRANT ALL ON public.states TO service_role;
ALTER TABLE public.states ENABLE ROW LEVEL SECURITY;
CREATE POLICY states_read ON public.states FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY states_admin ON public.states FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TABLE public.cities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  state_id uuid NOT NULL REFERENCES public.states(id) ON DELETE CASCADE,
  name text NOT NULL,
  slug text NOT NULL,
  image_url text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  best_season text NOT NULL DEFAULT '',
  recommended_days integer NOT NULL DEFAULT 2 CHECK (recommended_days > 0),
  daily_budget numeric NOT NULL DEFAULT 0 CHECK (daily_budget >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (state_id, slug)
);
CREATE INDEX idx_cities_state ON public.cities(state_id);
GRANT SELECT ON public.cities TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cities TO authenticated;
GRANT ALL ON public.cities TO service_role;
ALTER TABLE public.cities ENABLE ROW LEVEL SECURITY;
CREATE POLICY cities_read ON public.cities FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY cities_admin ON public.cities FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TYPE public.place_status AS ENUM ('open','closed','seasonal','maintenance');

CREATE TABLE public.tourist_places (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  city_id uuid NOT NULL REFERENCES public.cities(id) ON DELETE CASCADE,
  name text NOT NULL,
  slug text NOT NULL,
  category text NOT NULL DEFAULT 'sightseeing',
  description text NOT NULL DEFAULT '',
  image_url text NOT NULL DEFAULT '',
  opening_time time NOT NULL DEFAULT '09:00',
  closing_time time NOT NULL DEFAULT '18:00',
  entry_fee numeric NOT NULL DEFAULT 0 CHECK (entry_fee >= 0),
  visit_duration_min integer NOT NULL DEFAULT 60 CHECK (visit_duration_min > 0),
  best_season text NOT NULL DEFAULT '',
  weather_sensitive boolean NOT NULL DEFAULT false,
  is_indoor boolean NOT NULL DEFAULT false,
  status public.place_status NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (city_id, slug)
);
CREATE INDEX idx_places_city ON public.tourist_places(city_id);
GRANT SELECT ON public.tourist_places TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tourist_places TO authenticated;
GRANT ALL ON public.tourist_places TO service_role;
ALTER TABLE public.tourist_places ENABLE ROW LEVEL SECURITY;
CREATE POLICY places_read ON public.tourist_places FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY places_admin ON public.tourist_places FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

-- ============ HOTELS ============
CREATE TABLE public.hotels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  city_id uuid NOT NULL REFERENCES public.cities(id) ON DELETE CASCADE,
  registration_no text NOT NULL UNIQUE,
  name text NOT NULL,
  slug text NOT NULL,
  description text NOT NULL DEFAULT '',
  image_url text NOT NULL DEFAULT '',
  star_rating integer NOT NULL DEFAULT 4 CHECK (star_rating BETWEEN 1 AND 7),
  rating numeric NOT NULL DEFAULT 4.5 CHECK (rating >= 0 AND rating <= 5),
  address text NOT NULL DEFAULT '',
  amenities text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (city_id, slug)
);
CREATE INDEX idx_hotels_city ON public.hotels(city_id);
GRANT SELECT ON public.hotels TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.hotels TO authenticated;
GRANT ALL ON public.hotels TO service_role;
ALTER TABLE public.hotels ENABLE ROW LEVEL SECURITY;
CREATE POLICY hotels_read ON public.hotels FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY hotels_admin ON public.hotels FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TABLE public.rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  hotel_id uuid NOT NULL REFERENCES public.hotels(id) ON DELETE CASCADE,
  room_type text NOT NULL,
  description text NOT NULL DEFAULT '',
  image_url text NOT NULL DEFAULT '',
  price_per_night numeric NOT NULL CHECK (price_per_night > 0),
  max_guests integer NOT NULL DEFAULT 2 CHECK (max_guests > 0),
  total_units integer NOT NULL DEFAULT 5 CHECK (total_units >= 0),
  available_units integer NOT NULL DEFAULT 5 CHECK (available_units >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (hotel_id, room_type)
);
CREATE INDEX idx_rooms_hotel ON public.rooms(hotel_id);
GRANT SELECT ON public.rooms TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.rooms TO authenticated;
GRANT ALL ON public.rooms TO service_role;
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
CREATE POLICY rooms_read ON public.rooms FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY rooms_admin ON public.rooms FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

-- ============ PACKAGES ============
CREATE TABLE public.travel_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  package_code text NOT NULL UNIQUE,
  country_id uuid NOT NULL REFERENCES public.countries(id) ON DELETE CASCADE,
  state_id uuid REFERENCES public.states(id) ON DELETE SET NULL,
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  description text NOT NULL DEFAULT '',
  image_url text NOT NULL DEFAULT '',
  duration_days integer NOT NULL CHECK (duration_days > 0),
  duration_nights integer NOT NULL CHECK (duration_nights >= 0),
  price numeric NOT NULL CHECK (price > 0),
  hotel_category text NOT NULL DEFAULT '4-Star',
  transportation text NOT NULL DEFAULT 'Private cab',
  meals text NOT NULL DEFAULT 'Breakfast',
  travel_style text NOT NULL DEFAULT 'family',
  rating numeric NOT NULL DEFAULT 4.6 CHECK (rating >= 0 AND rating <= 5),
  capacity integer NOT NULL DEFAULT 40 CHECK (capacity >= 0),
  booked_count integer NOT NULL DEFAULT 0 CHECK (booked_count >= 0),
  best_season text NOT NULL DEFAULT '',
  inclusions text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_packages_country ON public.travel_packages(country_id);
CREATE INDEX idx_packages_state ON public.travel_packages(state_id);
CREATE INDEX idx_packages_code ON public.travel_packages(package_code);
GRANT SELECT ON public.travel_packages TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.travel_packages TO authenticated;
GRANT ALL ON public.travel_packages TO service_role;
ALTER TABLE public.travel_packages ENABLE ROW LEVEL SECURITY;
CREATE POLICY packages_read ON public.travel_packages FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY packages_admin ON public.travel_packages FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TABLE public.package_places (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  package_id uuid NOT NULL REFERENCES public.travel_packages(id) ON DELETE CASCADE,
  place_id uuid NOT NULL REFERENCES public.tourist_places(id) ON DELETE CASCADE,
  sort_order integer NOT NULL DEFAULT 0,
  UNIQUE (package_id, place_id)
);
GRANT SELECT ON public.package_places TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.package_places TO authenticated;
GRANT ALL ON public.package_places TO service_role;
ALTER TABLE public.package_places ENABLE ROW LEVEL SECURITY;
CREATE POLICY pkg_places_read ON public.package_places FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY pkg_places_admin ON public.package_places FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

CREATE TABLE public.package_itinerary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  package_id uuid NOT NULL REFERENCES public.travel_packages(id) ON DELETE CASCADE,
  day_number integer NOT NULL CHECK (day_number > 0),
  day_title text NOT NULL DEFAULT '',
  city_id uuid REFERENCES public.cities(id) ON DELETE SET NULL,
  start_time time NOT NULL DEFAULT '09:00',
  activity text NOT NULL,
  place_id uuid REFERENCES public.tourist_places(id) ON DELETE SET NULL,
  duration_min integer NOT NULL DEFAULT 60 CHECK (duration_min > 0),
  travel_min integer NOT NULL DEFAULT 0 CHECK (travel_min >= 0),
  weather_sensitive boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0
);
CREATE INDEX idx_itinerary_package ON public.package_itinerary(package_id, day_number, sort_order);
GRANT SELECT ON public.package_itinerary TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.package_itinerary TO authenticated;
GRANT ALL ON public.package_itinerary TO service_role;
ALTER TABLE public.package_itinerary ENABLE ROW LEVEL SECURITY;
CREATE POLICY itin_read ON public.package_itinerary FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY itin_admin ON public.package_itinerary FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

-- ============ ROUTES ============
CREATE TABLE public.routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_city_id uuid NOT NULL REFERENCES public.cities(id) ON DELETE CASCADE,
  to_city_id uuid NOT NULL REFERENCES public.cities(id) ON DELETE CASCADE,
  distance_km numeric NOT NULL CHECK (distance_km > 0),
  travel_min integer NOT NULL CHECK (travel_min > 0),
  road_status text NOT NULL DEFAULT 'open',
  traffic_level text NOT NULL DEFAULT 'moderate',
  road_condition text NOT NULL DEFAULT 'good',
  notes text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (from_city_id, to_city_id)
);
GRANT SELECT ON public.routes TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.routes TO authenticated;
GRANT ALL ON public.routes TO service_role;
ALTER TABLE public.routes ENABLE ROW LEVEL SECURITY;
CREATE POLICY routes_read ON public.routes FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY routes_admin ON public.routes FOR ALL TO authenticated USING (has_role(auth.uid(),'admin')) WITH CHECK (has_role(auth.uid(),'admin'));

-- ============ BOOKINGS ============
CREATE TYPE public.booking_status AS ENUM ('pending','confirmed','in_progress','completed','cancelled');

CREATE TABLE public.bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_ref text NOT NULL UNIQUE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  package_id uuid NOT NULL REFERENCES public.travel_packages(id),
  hotel_id uuid REFERENCES public.hotels(id),
  room_id uuid REFERENCES public.rooms(id),
  start_date date NOT NULL,
  end_date date NOT NULL,
  adults integer NOT NULL DEFAULT 1 CHECK (adults > 0),
  children integer NOT NULL DEFAULT 0 CHECK (children >= 0),
  travellers integer NOT NULL DEFAULT 1 CHECK (travellers > 0),
  rooms_count integer NOT NULL DEFAULT 1 CHECK (rooms_count > 0),
  addons text[] NOT NULL DEFAULT '{}',
  package_amount numeric NOT NULL DEFAULT 0 CHECK (package_amount >= 0),
  hotel_amount numeric NOT NULL DEFAULT 0 CHECK (hotel_amount >= 0),
  addon_amount numeric NOT NULL DEFAULT 0 CHECK (addon_amount >= 0),
  taxes numeric NOT NULL DEFAULT 0 CHECK (taxes >= 0),
  total_amount numeric NOT NULL DEFAULT 0 CHECK (total_amount >= 0),
  status public.booking_status NOT NULL DEFAULT 'confirmed',
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_bookings_user ON public.bookings(user_id);
CREATE INDEX idx_bookings_date ON public.bookings(start_date);
CREATE INDEX idx_bookings_hotel ON public.bookings(hotel_id);
GRANT SELECT, INSERT, UPDATE ON public.bookings TO authenticated;
GRANT ALL ON public.bookings TO service_role;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY bookings_select ON public.bookings FOR SELECT TO authenticated USING (user_id = auth.uid() OR has_role(auth.uid(),'admin'));
CREATE POLICY bookings_insert ON public.bookings FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY bookings_update ON public.bookings FOR UPDATE TO authenticated USING (user_id = auth.uid() OR has_role(auth.uid(),'admin'));

CREATE TABLE public.booking_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
  status public.booking_status NOT NULL,
  note text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_bh_booking ON public.booking_history(booking_id);
GRANT SELECT, INSERT ON public.booking_history TO authenticated;
GRANT ALL ON public.booking_history TO service_role;
ALTER TABLE public.booking_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY bh_select ON public.booking_history FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.bookings b WHERE b.id = booking_history.booking_id AND (b.user_id = auth.uid() OR has_role(auth.uid(),'admin'))));
CREATE POLICY bh_insert ON public.booking_history FOR INSERT TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM public.bookings b WHERE b.id = booking_history.booking_id AND b.user_id = auth.uid()));

CREATE TABLE public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount numeric NOT NULL CHECK (amount >= 0),
  method public.payment_method NOT NULL DEFAULT 'upi',
  status public.payment_status NOT NULL DEFAULT 'paid',
  reference text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_payments_booking ON public.payments(booking_id);
GRANT SELECT, INSERT ON public.payments TO authenticated;
GRANT ALL ON public.payments TO service_role;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
CREATE POLICY payments_select ON public.payments FOR SELECT TO authenticated USING (user_id = auth.uid() OR has_role(auth.uid(),'admin'));
CREATE POLICY payments_insert ON public.payments FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());

CREATE TABLE public.saved_trips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  package_id uuid NOT NULL REFERENCES public.travel_packages(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, package_id)
);
GRANT SELECT, INSERT, DELETE ON public.saved_trips TO authenticated;
GRANT ALL ON public.saved_trips TO service_role;
ALTER TABLE public.saved_trips ENABLE ROW LEVEL SECURITY;
CREATE POLICY saved_all ON public.saved_trips FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE TABLE public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  package_id uuid REFERENCES public.travel_packages(id) ON DELETE CASCADE,
  hotel_id uuid REFERENCES public.hotels(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.reviews TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reviews TO authenticated;
GRANT ALL ON public.reviews TO service_role;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY reviews_read ON public.reviews FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY reviews_own ON public.reviews FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- ============ ATOMIC BOOKING TRANSACTION ============
CREATE OR REPLACE FUNCTION public.create_travel_booking(
  _package_id uuid,
  _hotel_id uuid,
  _room_id uuid,
  _start_date date,
  _end_date date,
  _adults integer,
  _children integer,
  _rooms_count integer,
  _addons text[],
  _package_amount numeric,
  _hotel_amount numeric,
  _addon_amount numeric,
  _taxes numeric,
  _total numeric,
  _method public.payment_method,
  _notes text
) RETURNS public.bookings
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _ref text;
  _b public.bookings;
  _avail integer;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;

  -- capacity constraint (package)
  PERFORM 1 FROM public.travel_packages
   WHERE id = _package_id AND booked_count + (_adults + _children) <= capacity FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Package capacity unavailable'; END IF;

  -- capacity constraint (room)
  IF _room_id IS NOT NULL THEN
    SELECT available_units INTO _avail FROM public.rooms WHERE id = _room_id FOR UPDATE;
    IF _avail IS NULL OR _avail < _rooms_count THEN RAISE EXCEPTION 'Selected room is unavailable'; END IF;
    UPDATE public.rooms SET available_units = available_units - _rooms_count, updated_at = now() WHERE id = _room_id;
  END IF;

  UPDATE public.travel_packages
     SET booked_count = booked_count + (_adults + _children), updated_at = now()
   WHERE id = _package_id;

  _ref := 'RSC-' || to_char(now(),'YYYY') || '-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,6));

  INSERT INTO public.bookings (
    booking_ref, user_id, package_id, hotel_id, room_id, start_date, end_date,
    adults, children, travellers, rooms_count, addons,
    package_amount, hotel_amount, addon_amount, taxes, total_amount, status, notes
  ) VALUES (
    _ref, _uid, _package_id, _hotel_id, _room_id, _start_date, _end_date,
    _adults, _children, _adults + _children, _rooms_count, coalesce(_addons,'{}'),
    _package_amount, _hotel_amount, _addon_amount, _taxes, _total, 'confirmed', coalesce(_notes,'')
  ) RETURNING * INTO _b;

  INSERT INTO public.booking_history (booking_id, status, note)
  VALUES (_b.id, 'confirmed', 'Booking created and confirmed');

  INSERT INTO public.payments (booking_id, user_id, amount, method, status, reference)
  VALUES (_b.id, _uid, _total, _method, 'paid', 'DEMO-' || _ref);

  RETURN _b;
END; $$;
GRANT EXECUTE ON FUNCTION public.create_travel_booking(uuid,uuid,uuid,date,date,integer,integer,integer,text[],numeric,numeric,numeric,numeric,numeric,public.payment_method,text) TO authenticated;

-- ============ SEED DATA ============
INSERT INTO public.countries (code,name,slug,image_url,description,best_season,currency,starting_price) VALUES
('IN','India','india','https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=1200','Timeless palaces, backwaters, beaches and Himalayan peaks.','Oct – Mar','INR',18999),
('AE','United Arab Emirates','uae','https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=1200','Desert luxury, skyline marvels and golden souks.','Nov – Mar','INR',44999),
('TH','Thailand','thailand','https://images.unsplash.com/photo-1528181304800-259b08848526?w=1200','Island paradises, temples and legendary street food.','Nov – Feb','INR',38999),
('SG','Singapore','singapore','https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=1200','A garden city of futuristic design and flavour.','Feb – Apr','INR',42999),
('MY','Malaysia','malaysia','https://images.unsplash.com/photo-1596422846543-75c6fc197f07?w=1200','Rainforests, islands and twin-tower skylines.','Mar – Sep','INR',36999),
('FR','France','france','https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1200','Art, couture, châteaux and Riviera sunsets.','Apr – Jun','INR',119999),
('IT','Italy','italy','https://images.unsplash.com/photo-1515542622106-78bda8ba0e5b?w=1200','Renaissance cities, coastlines and cuisine.','Apr – Jun','INR',109999),
('CH','Switzerland','switzerland','https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?w=1200','Alpine railways, glaciers and lakeside towns.','Jun – Sep','INR',134999),
('JP','Japan','japan','https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=1200','Cherry blossoms, shrines and bullet trains.','Mar – May','INR',124999),
('KR','South Korea','south-korea','https://images.unsplash.com/photo-1538485399081-7191377e8241?w=1200','Palaces, K-culture and mountain temples.','Apr – Jun','INR',99999),
('AU','Australia','australia','https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=1200','Reefs, opera houses and outback horizons.','Sep – Nov','INR',149999),
('GB','United Kingdom','united-kingdom','https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=1200','Royal heritage, highlands and countryside charm.','May – Sep','INR',114999),
('US','United States','united-states','https://images.unsplash.com/photo-1485871981521-5b1fd3805eee?w=1200','Canyons, coastlines and iconic cities.','May – Sep','INR',159999);

INSERT INTO public.states (country_id,name,slug,image_url,description,best_season,starting_price)
SELECT c.id, v.name, v.slug, v.img, v.descr, v.season, v.price FROM public.countries c JOIN (VALUES
('india','Kerala','kerala','https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=1200','Backwaters, tea hills and Ayurvedic calm.','Sep – Mar',24999),
('india','Rajasthan','rajasthan','https://images.unsplash.com/photo-1477587458883-47145ed94245?w=1200','Forts, palaces and desert dunes.','Oct – Mar',22999),
('india','Goa','goa','https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=1200','Beaches, Portuguese heritage and nightlife.','Nov – Feb',18999),
('india','Telangana','telangana','https://images.unsplash.com/photo-1600100397608-f010cb1de3d5?w=1200','Nizami heritage, pearls and biryani.','Oct – Feb',15999),
('india','Tamil Nadu','tamil-nadu','https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=1200','Temple towns and colonial hill stations.','Nov – Feb',19999),
('india','Karnataka','karnataka','https://images.unsplash.com/photo-1600100397608-f010cb1de3d5?w=1200','Ruins of Hampi, coffee estates and palaces.','Oct – Feb',19999),
('india','Maharashtra','maharashtra','https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=1200','Caves, coastline and the city that never sleeps.','Nov – Feb',17999),
('india','Himachal Pradesh','himachal-pradesh','https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=1200','Snow peaks, pine valleys and hill towns.','Mar – Jun',21999),
('india','Uttarakhand','uttarakhand','https://images.unsplash.com/photo-1591018533221-6a1a1a1a1a1a?w=1200','Himalayan pilgrimage and river adventure.','Mar – Jun',20999),
('india','Jammu & Kashmir','jammu-kashmir','https://images.unsplash.com/photo-1566837945700-30057527ade0?w=1200','Shikaras, meadows and alpine snow.','Apr – Oct',27999),
('uae','Dubai','dubai','https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=1200','Skyline spectacle and desert luxury.','Nov – Mar',44999),
('uae','Abu Dhabi','abu-dhabi','https://images.unsplash.com/photo-1551041777-575d3855ca71?w=1200','Grand mosques and island resorts.','Nov – Mar',46999),
('thailand','Bangkok & Central','bangkok-central','https://images.unsplash.com/photo-1508009603885-50cf7c579365?w=1200','Temples, markets and river life.','Nov – Feb',38999),
('thailand','Phuket & Krabi','phuket-krabi','https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=1200','Limestone islands and turquoise bays.','Nov – Apr',41999),
('singapore','Central Singapore','central-singapore','https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=1200','Marina Bay, gardens and island fun.','Feb – Apr',42999),
('malaysia','Kuala Lumpur','kuala-lumpur','https://images.unsplash.com/photo-1596422846543-75c6fc197f07?w=1200','Twin towers, caves and food streets.','Mar – Sep',36999),
('italy','Tuscany','tuscany','https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?w=1200','Vineyards, Renaissance art and hill towns.','Apr – Jun',109999),
('france','Île-de-France','ile-de-france','https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1200','Paris and its royal surroundings.','Apr – Jun',119999),
('switzerland','Bernese Oberland','bernese-oberland','https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?w=1200','Jungfrau peaks and alpine villages.','Jun – Sep',134999),
('japan','Kansai','kansai','https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=1200','Kyoto shrines and Osaka energy.','Mar – May',124999)
) AS v(cslug,name,slug,img,descr,season,price) ON c.slug = v.cslug;

INSERT INTO public.cities (state_id,name,slug,image_url,description,best_season,recommended_days,daily_budget)
SELECT s.id, v.name, v.slug, v.img, v.descr, v.season, v.days, v.budget
FROM public.states s JOIN (VALUES
('kerala','Kochi','kochi','https://images.unsplash.com/photo-1590766940554-153a4d9f6cb5?w=1200','A spice-trade port where colonial lanes meet the Arabian Sea.','Oct – Mar',2,3500),
('kerala','Munnar','munnar','https://images.unsplash.com/photo-1580889240912-c39ae1a8b0d3?w=1200','Rolling tea gardens wrapped in Western Ghats mist.','Sep – Mar',2,3200),
('kerala','Thekkady','thekkady','https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=1200','Spice plantations at the edge of Periyar reserve.','Oct – Mar',1,2800),
('kerala','Alleppey','alleppey','https://images.unsplash.com/photo-1593693411515-c20261bcad6e?w=1200','Houseboat country: palm-lined canals and paddy fields.','Nov – Feb',1,4200),
('rajasthan','Jaipur','jaipur','https://images.unsplash.com/photo-1477587458883-47145ed94245?w=1200','The Pink City of forts, bazaars and royal courtyards.','Oct – Mar',2,3000),
('rajasthan','Udaipur','udaipur','https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=1200','Lake palaces and marble ghats.','Oct – Mar',2,3800),
('rajasthan','Jaisalmer','jaisalmer','https://images.unsplash.com/photo-1524229664653-e2e1a9dc9d97?w=1200','A golden fortress rising from the Thar desert.','Nov – Feb',2,2900),
('goa','North Goa','north-goa','https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=1200','Beach shacks, forts and sunset markets.','Nov – Feb',3,3400),
('telangana','Hyderabad','hyderabad','https://images.unsplash.com/photo-1600100397608-f010cb1de3d5?w=1200','Charminar, Golconda and legendary biryani.','Oct – Feb',2,2600),
('tamil-nadu','Ooty','ooty','https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=1200','Colonial hill station of eucalyptus and toy trains.','Oct – Jun',2,2700),
('karnataka','Coorg','coorg','https://images.unsplash.com/photo-1580889240912-c39ae1a8b0d3?w=1200','Coffee estates and misty valleys.','Oct – Mar',2,3100),
('dubai','Dubai City','dubai-city','https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=1200','Burj Khalifa, desert safaris and gold souks.','Nov – Mar',4,9000),
('bangkok-central','Bangkok','bangkok','https://images.unsplash.com/photo-1508009603885-50cf7c579365?w=1200','Golden temples, river ferries and night markets.','Nov – Feb',3,5200),
('phuket-krabi','Phuket','phuket','https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=1200','Andaman beaches and island hopping.','Nov – Apr',3,6000),
('central-singapore','Singapore City','singapore-city','https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=1200','Marina Bay, Sentosa and hawker culture.','Feb – Apr',3,8000),
('kuala-lumpur','Kuala Lumpur','kuala-lumpur-city','https://images.unsplash.com/photo-1596422846543-75c6fc197f07?w=1200','Petronas Towers and Batu Caves.','Mar – Sep',3,5500),
('tuscany','Florence','florence','https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?w=1200','Cradle of the Renaissance.','Apr – Jun',3,12000),
('ile-de-france','Paris','paris','https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1200','The city of light, love and haute cuisine.','Apr – Jun',4,14000),
('bernese-oberland','Interlaken','interlaken','https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?w=1200','Between two lakes beneath the Jungfrau.','Jun – Sep',3,15000),
('kansai','Kyoto','kyoto','https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=1200','Thousand shrines and geisha districts.','Mar – May',3,13000)
) AS v(sslug,name,slug,img,descr,season,days,budget) ON s.slug = v.sslug;

INSERT INTO public.tourist_places (city_id,name,slug,category,description,image_url,opening_time,closing_time,entry_fee,visit_duration_min,best_season,weather_sensitive,is_indoor,status)
SELECT ci.id, v.name, v.slug, v.cat, v.descr, v.img, v.o::time, v.c::time, v.fee, v.dur, v.season, v.ws, v.indoor, v.st::public.place_status
FROM public.cities ci JOIN (VALUES
('kochi','Fort Kochi','fort-kochi','heritage','Colonial streets, Chinese fishing nets and cafés.','https://images.unsplash.com/photo-1590766940554-153a4d9f6cb5?w=1200','08:00','18:00',0,120,'Oct – Mar',true,false,'open'),
('kochi','Mattancherry Palace','mattancherry-palace','museum','Dutch palace with Kerala mural masterpieces.','https://images.unsplash.com/photo-1548013146-72479768bada?w=1200','09:00','17:00',50,60,'All year',false,true,'open'),
('kochi','Marine Drive','marine-drive','promenade','Sunset walkway along the backwater harbour.','https://images.unsplash.com/photo-1519046904884-53103b34b206?w=1200','06:00','22:00',0,60,'Oct – Mar',true,false,'open'),
('munnar','Munnar Tea Gardens','munnar-tea-gardens','nature','Emerald terraces stretching to the horizon.','https://images.unsplash.com/photo-1580889240912-c39ae1a8b0d3?w=1200','07:00','18:00',0,120,'Sep – Mar',true,false,'open'),
('munnar','Eravikulam National Park','eravikulam-national-park','wildlife','Home of the Nilgiri tahr and Neelakurinji blooms.','https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=1200','08:00','16:00',200,180,'Sep – Jan',true,false,'open'),
('munnar','Mattupetty Dam','mattupetty-dam','nature','Boating beneath shola forest slopes.','https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1200','09:00','17:00',100,90,'Sep – Mar',true,false,'open'),
('munnar','Echo Point','echo-point','viewpoint','Valley viewpoint famed for its echo.','https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=1200','08:00','17:00',20,45,'Sep – Mar',true,false,'open'),
('munnar','Tea Museum','tea-museum','museum','Indoor walkthrough of Kerala tea heritage.','https://images.unsplash.com/photo-1571934811356-5cc061b6821f?w=1200','10:00','16:00',150,60,'All year',false,true,'open'),
('thekkady','Periyar Wildlife Sanctuary','periyar-wildlife-sanctuary','wildlife','Lakeside jungle cruise among elephants.','https://images.unsplash.com/photo-1549366021-9f761d450615?w=1200','07:00','17:00',300,180,'Oct – Mar',true,false,'open'),
('thekkady','Spice Plantation Walk','spice-plantation-walk','experience','Guided walk through cardamom and pepper estates.','https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=1200','09:00','17:00',250,90,'All year',false,false,'open'),
('alleppey','Alleppey Backwaters','alleppey-backwaters','nature','Houseboat cruise through palm-lined canals.','https://images.unsplash.com/photo-1593693411515-c20261bcad6e?w=1200','09:00','18:00',0,300,'Nov – Feb',true,false,'open'),
('jaipur','Amber Fort','amber-fort','heritage','Hilltop fort of mirrored halls and ramparts.','https://images.unsplash.com/photo-1477587458883-47145ed94245?w=1200','08:00','17:30',500,150,'Oct – Mar',false,false,'open'),
('jaipur','Hawa Mahal','hawa-mahal','heritage','The palace of winds with 953 latticed windows.','https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=1200','09:00','16:30',200,60,'Oct – Mar',false,true,'open'),
('jaipur','City Palace','city-palace-jaipur','museum','Royal residence and museum courtyards.','https://images.unsplash.com/photo-1599661046289-e31897846e41?w=1200','09:30','17:00',700,120,'All year',false,true,'open'),
('udaipur','Lake Pichola','lake-pichola','nature','Sunset boat ride past island palaces.','https://images.unsplash.com/photo-1567157577867-05ccb1388e66?w=1200','08:00','19:00',400,90,'Oct – Mar',true,false,'open'),
('jaisalmer','Sam Sand Dunes','sam-sand-dunes','adventure','Camel safari and desert camp evenings.','https://images.unsplash.com/photo-1524229664653-e2e1a9dc9d97?w=1200','15:00','21:00',1500,180,'Nov – Feb',true,false,'open'),
('north-goa','Baga Beach','baga-beach','beach','Golden sands, shacks and water sports.','https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=1200','06:00','21:00',0,180,'Nov – Feb',true,false,'open'),
('north-goa','Fort Aguada','fort-aguada','heritage','Portuguese sea fort with lighthouse views.','https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=1200','09:30','18:00',50,90,'Nov – Feb',true,false,'open'),
('hyderabad','Charminar','charminar','heritage','The 16th-century icon at the heart of the old city.','https://images.unsplash.com/photo-1600100397608-f010cb1de3d5?w=1200','09:30','17:30',25,60,'Oct – Feb',false,false,'open'),
('hyderabad','Golconda Fort','golconda-fort','heritage','Acoustic marvels and hilltop ruins.','https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?w=1200','09:00','17:30',30,150,'Oct – Feb',true,false,'open'),
('hyderabad','Salar Jung Museum','salar-jung-museum','museum','One of the world''s largest one-man collections.','https://images.unsplash.com/photo-1566127992631-137a642a90f4?w=1200','10:00','17:00',50,120,'All year',false,true,'open'),
('ooty','Botanical Gardens','ooty-botanical-gardens','nature','Terraced Victorian gardens.','https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=1200','07:00','18:30',75,90,'Oct – Jun',true,false,'open'),
('coorg','Abbey Falls','abbey-falls','nature','Cascade framed by coffee plantations.','https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?w=1200','09:00','17:30',30,60,'Oct – Mar',true,false,'open'),
('dubai-city','Burj Khalifa','burj-khalifa','landmark','The world''s tallest tower observation decks.','https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=1200','09:00','23:00',4500,120,'Nov – Mar',false,true,'open'),
('dubai-city','Desert Safari','dubai-desert-safari','adventure','Dune bashing with a Bedouin-style dinner.','https://images.unsplash.com/photo-1451337516015-6b6e9a44a8a3?w=1200','15:00','21:30',3500,300,'Nov – Mar',true,false,'open'),
('dubai-city','Dubai Mall & Fountain','dubai-mall','shopping','Retail spectacle and the dancing fountain show.','https://images.unsplash.com/photo-1546412414-e1885259563a?w=1200','10:00','24:00',0,180,'All year',false,true,'open'),
('bangkok','Grand Palace','grand-palace','heritage','Gilded royal complex and the Emerald Buddha.','https://images.unsplash.com/photo-1508009603885-50cf7c579365?w=1200','08:30','15:30',1200,150,'Nov – Feb',false,false,'open'),
('bangkok','Chatuchak Market','chatuchak-market','shopping','Thousands of stalls across a weekend maze.','https://images.unsplash.com/photo-1519677100203-a0e668c92439?w=1200','09:00','18:00',0,180,'Nov – Feb',false,true,'open'),
('phuket','Phi Phi Islands','phi-phi-islands','beach','Speedboat day trip to limestone lagoons.','https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=1200','08:00','17:00',2800,480,'Nov – Apr',true,false,'open'),
('singapore-city','Gardens by the Bay','gardens-by-the-bay','nature','Supertrees and climate-controlled domes.','https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=1200','09:00','21:00',2200,180,'All year',false,true,'open'),
('singapore-city','Sentosa Island','sentosa-island','entertainment','Beaches, cable cars and theme parks.','https://images.unsplash.com/photo-1533628635777-112b2239b1c7?w=1200','10:00','22:00',3000,300,'Feb – Apr',true,false,'open'),
('kuala-lumpur-city','Petronas Twin Towers','petronas-twin-towers','landmark','Skybridge and observation deck.','https://images.unsplash.com/photo-1596422846543-75c6fc197f07?w=1200','09:00','21:00',2000,120,'All year',false,true,'open'),
('kuala-lumpur-city','Batu Caves','batu-caves','heritage','272 rainbow steps to limestone temple caves.','https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=1200','07:00','21:00',0,120,'Mar – Sep',true,false,'open'),
('florence','Uffizi Gallery','uffizi-gallery','museum','Botticelli, da Vinci and Renaissance masters.','https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?w=1200','08:15','18:30',2100,180,'All year',false,true,'open'),
('paris','Eiffel Tower','eiffel-tower','landmark','Iron lattice icon above the Champ de Mars.','https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1200','09:30','23:00',2600,150,'Apr – Jun',true,false,'open'),
('paris','Louvre Museum','louvre-museum','museum','The world''s most visited museum.','https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=1200','09:00','18:00',1800,240,'All year',false,true,'open'),
('interlaken','Jungfraujoch','jungfraujoch','nature','Top of Europe glacier railway.','https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?w=1200','08:00','17:00',18000,360,'Jun – Sep',true,false,'open'),
('kyoto','Fushimi Inari Shrine','fushimi-inari','heritage','Ten thousand vermilion torii gates.','https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=1200','00:00','23:59',0,150,'Mar – May',true,false,'open')
) AS v(cslug,name,slug,cat,descr,img,o,c,fee,dur,season,ws,indoor,st) ON ci.slug = v.cslug;

INSERT INTO public.hotels (city_id,registration_no,name,slug,description,image_url,star_rating,rating,address,amenities)
SELECT ci.id, v.reg, v.name, v.slug, v.descr, v.img, v.star, v.rat, v.addr, v.am
FROM public.cities ci JOIN (VALUES
('kochi','RSC-HTL-0001','Royal Stay Kochi Harbour','royal-stay-kochi','Heritage harbourfront suites with concierge service.','https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200',5,4.8,'Fort Kochi, Kerala',ARRAY['Pool','Spa','Room Service','Airport Transfer']),
('munnar','RSC-HTL-0002','Royal Stay Munnar Tea Retreat','royal-stay-munnar','Valley-view chalets set inside a working tea estate.','https://images.unsplash.com/photo-1445019980597-93fa8acb246c?w=1200',5,4.7,'Chithirapuram, Munnar',ARRAY['Spa','Bonfire','Room Service','Trekking']),
('alleppey','RSC-HTL-0003','Royal Stay Backwater Villas','royal-stay-alleppey','Private pool villas beside the Vembanad canals.','https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=1200',5,4.9,'Punnamada, Alleppey',ARRAY['Private Pool','Houseboat','Ayurveda','Room Service']),
('jaipur','RSC-HTL-0004','Royal Stay Jaipur Palace','royal-stay-jaipur','A restored haveli with courtyard dining.','https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?w=1200',5,4.8,'Civil Lines, Jaipur',ARRAY['Pool','Spa','Heritage Tour','Room Service']),
('hyderabad','RSC-HTL-0005','Royal Stay Hyderabad Nizam','royal-stay-hyderabad','Nizami elegance minutes from Charminar.','https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=1200',5,4.6,'Banjara Hills, Hyderabad',ARRAY['Pool','Gym','Room Service','Business Lounge']),
('north-goa','RSC-HTL-0006','Royal Stay Goa Beach Resort','royal-stay-goa','Beachfront resort with sunset decks.','https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=1200',5,4.7,'Baga, North Goa',ARRAY['Beach Access','Pool','Spa','Room Service']),
('dubai-city','RSC-HTL-0007','Royal Stay Dubai Marina','royal-stay-dubai','Marina skyline suites with infinity pool.','https://images.unsplash.com/photo-1582719508461-905c673771fd?w=1200',5,4.9,'Dubai Marina',ARRAY['Infinity Pool','Spa','Butler','Room Service']),
('bangkok','RSC-HTL-0008','Royal Stay Bangkok Riverside','royal-stay-bangkok','River-facing tower with rooftop dining.','https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=1200',5,4.7,'Chao Phraya, Bangkok',ARRAY['Rooftop Bar','Pool','Spa','Room Service']),
('paris','RSC-HTL-0009','Royal Stay Paris Rive Gauche','royal-stay-paris','Belle Époque rooms near the Seine.','https://images.unsplash.com/photo-1445019980597-93fa8acb246c?w=1200',5,4.8,'6th Arrondissement, Paris',ARRAY['Concierge','Spa','Room Service','Fine Dining']),
('interlaken','RSC-HTL-0010','Royal Stay Interlaken Alpine','royal-stay-interlaken','Alpine lodge between Thun and Brienz lakes.','https://images.unsplash.com/photo-1596436889106-be35e843f974?w=1200',5,4.9,'Interlaken, Switzerland',ARRAY['Mountain View','Spa','Ski Desk','Room Service'])
) AS v(cslug,reg,name,slug,descr,img,star,rat,addr,am) ON ci.slug = v.cslug;

INSERT INTO public.rooms (hotel_id,room_type,description,image_url,price_per_night,max_guests,total_units,available_units)
SELECT h.id, v.rt, v.descr, v.img, v.price, v.mg, v.tu, v.au
FROM public.hotels h JOIN (VALUES
('royal-stay-kochi','Deluxe Room','Harbour-view king room.','https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=1200',6500,2,12,12),
('royal-stay-kochi','Heritage Suite','Two-room suite with private balcony.','https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=1200',11500,4,6,6),
('royal-stay-munnar','Valley Chalet','Tea-valley chalet with fireplace.','https://images.unsplash.com/photo-1595576508898-0ad5c879a061?w=1200',7200,2,10,10),
('royal-stay-munnar','Estate Villa','Private villa for families.','https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=1200',13500,5,4,4),
('royal-stay-alleppey','Pool Villa','Villa with plunge pool on the backwaters.','https://images.unsplash.com/photo-1582719508461-905c673771fd?w=1200',14500,4,6,6),
('royal-stay-alleppey','Canal Room','Cosy room facing the canal.','https://images.unsplash.com/photo-1590490360182-c33d57733427?w=1200',6800,2,10,10),
('royal-stay-jaipur','Royal Room','Frescoed room around the courtyard.','https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=1200',6200,2,14,14),
('royal-stay-jaipur','Maharaja Suite','Grand suite with private terrace.','https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=1200',15500,4,4,4),
('royal-stay-hyderabad','Deluxe Room','City-view room with lounge access.','https://images.unsplash.com/photo-1590490360182-c33d57733427?w=1200',5500,2,16,16),
('royal-stay-hyderabad','Executive Suite','Suite with workspace and lounge.','https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=1200',9800,3,6,6),
('royal-stay-goa','Sea View Room','Balcony overlooking the Arabian Sea.','https://images.unsplash.com/photo-1602002418082-a4443e081dd1?w=1200',7400,2,14,14),
('royal-stay-goa','Beach Villa','Private villa steps from the sand.','https://images.unsplash.com/photo-1596436889106-be35e843f974?w=1200',16500,5,5,5),
('royal-stay-dubai','Marina Room','Floor-to-ceiling marina views.','https://images.unsplash.com/photo-1582719508461-905c673771fd?w=1200',18500,2,20,20),
('royal-stay-dubai','Sky Suite','Corner suite with butler service.','https://images.unsplash.com/photo-1590490360182-c33d57733427?w=1200',34000,4,8,8),
('royal-stay-bangkok','River Room','River-facing room with rain shower.','https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=1200',9200,2,18,18),
('royal-stay-bangkok','Riverside Suite','Suite with panoramic river terrace.','https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=1200',17500,4,6,6),
('royal-stay-paris','Classic Room','Parisian room with balcony.','https://images.unsplash.com/photo-1595576508898-0ad5c879a061?w=1200',24000,2,12,12),
('royal-stay-paris','Seine Suite','Suite with Seine and rooftop views.','https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=1200',42000,4,4,4),
('royal-stay-interlaken','Alpine Room','Mountain-view room with balcony.','https://images.unsplash.com/photo-1596436889106-be35e843f974?w=1200',26000,2,10,10),
('royal-stay-interlaken','Jungfrau Suite','Panoramic suite facing the glacier.','https://images.unsplash.com/photo-1590490360182-c33d57733427?w=1200',48000,4,4,4)
) AS v(hslug,rt,descr,img,price,mg,tu,au) ON h.slug = v.hslug;

INSERT INTO public.travel_packages (package_code,country_id,state_id,name,slug,description,image_url,duration_days,duration_nights,price,hotel_category,transportation,meals,travel_style,rating,capacity,best_season,inclusions)
SELECT v.code, c.id, s.id, v.name, v.slug, v.descr, v.img, v.days, v.nights, v.price, v.hcat, v.trans, v.meals, v.style, v.rating, v.cap, v.season, v.inc
FROM (VALUES
('PKG-KL-001','india','kerala','Kerala Grand Explorer','kerala-grand-explorer','Kochi, Munnar, Thekkady and Alleppey across five unhurried days.','https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=1200',5,4,32999,'5-Star','Private cab','Breakfast','family',4.8,40,'Sep – Mar',ARRAY['Hotel accommodation','Private transportation','Daily breakfast','Major sightseeing','Local transfers','Concierge assistance']),
('PKG-KL-002','india','kerala','Munnar Tea Country Escape','munnar-tea-country-escape','A three-day hill retreat among tea gardens and waterfalls.','https://images.unsplash.com/photo-1580889240912-c39ae1a8b0d3?w=1200',3,2,18999,'4-Star','Private cab','Breakfast','couple',4.6,30,'Sep – Mar',ARRAY['Hotel accommodation','Private cab','Daily breakfast','Tea estate tour']),
('PKG-RJ-001','india','rajasthan','Royal Rajasthan Heritage','royal-rajasthan-heritage','Jaipur, Udaipur and Jaisalmer forts, lakes and dunes.','https://images.unsplash.com/photo-1477587458883-47145ed94245?w=1200',6,5,42999,'5-Star','Private cab','Breakfast & Dinner','historical',4.7,35,'Oct – Mar',ARRAY['Palace hotels','Private transportation','Breakfast & dinner','Desert camp','Guided monument tours']),
('PKG-GA-001','india','goa','Goa Beach Indulgence','goa-beach-indulgence','Four days of beaches, forts and sunset cruises.','https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=1200',4,3,24999,'5-Star','Airport transfers','Breakfast','couple',4.5,50,'Nov – Feb',ARRAY['Beach resort stay','Airport transfers','Daily breakfast','Sunset cruise']),
('PKG-TS-001','india','telangana','Hyderabad Nizami Trail','hyderabad-nizami-trail','Charminar, Golconda and the Salar Jung treasures.','https://images.unsplash.com/photo-1600100397608-f010cb1de3d5?w=1200',3,2,15999,'4-Star','Private cab','Breakfast','historical',4.4,40,'Oct – Feb',ARRAY['Hotel accommodation','City transfers','Daily breakfast','Heritage guide']),
('PKG-AE-001','india','dubai','Dubai Luxury Discovery','dubai-luxury-discovery','Skyline, desert and island luxury across five days.','https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=1200',5,4,89999,'5-Star','Private transfers','Breakfast','luxury',4.9,30,'Nov – Mar',ARRAY['Marina hotel','Airport transfers','Daily breakfast','Burj Khalifa tickets','Desert safari']),
('PKG-TH-001','india','bangkok-central','Thailand Temples & Islands','thailand-temples-islands','Bangkok culture followed by Phuket''s Andaman blue.','https://images.unsplash.com/photo-1528181304800-259b08848526?w=1200',6,5,74999,'4-Star','Flights & transfers','Breakfast','adventure',4.6,36,'Nov – Feb',ARRAY['Hotels in Bangkok & Phuket','Internal flight','Daily breakfast','Island day trip']),
('PKG-EU-001','india','ile-de-france','Paris & Alpine Splendour','paris-alpine-splendour','Paris elegance paired with the Swiss Jungfrau region.','https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=1200',7,6,189999,'5-Star','Rail & private transfers','Breakfast','luxury',4.9,24,'Jun – Sep',ARRAY['Luxury hotels','First-class rail','Daily breakfast','Jungfraujoch excursion','Museum passes'])
) AS v(code,cslug,sslug,name,slug,descr,img,days,nights,price,hcat,trans,meals,style,rating,cap,season,inc)
JOIN public.countries c ON c.slug = v.cslug
LEFT JOIN public.states s ON s.slug = v.sslug;

-- Kerala Grand Explorer itinerary
INSERT INTO public.package_itinerary (package_id,day_number,day_title,city_id,start_time,activity,place_id,duration_min,travel_min,weather_sensitive,sort_order)
SELECT p.id, v.day, v.title, ci.id, v.t::time, v.act, pl.id, v.dur, v.travel, v.ws, v.ord
FROM public.travel_packages p
JOIN (VALUES
('kerala-grand-explorer',1,'Kochi','kochi','09:00','Arrival & welcome',NULL,60,0,false,1),
('kerala-grand-explorer',1,'Kochi','kochi','10:00','Explore Fort Kochi','fort-kochi',120,30,true,2),
('kerala-grand-explorer',1,'Kochi','kochi','12:00','Mattancherry Palace','mattancherry-palace',60,15,false,3),
('kerala-grand-explorer',1,'Kochi','kochi','14:00','Lunch at a harbour café',NULL,60,10,false,4),
('kerala-grand-explorer',1,'Kochi','kochi','16:00','Marine Drive sunset walk','marine-drive',60,20,true,5),
('kerala-grand-explorer',1,'Kochi','kochi','19:00','Hotel check-in & dinner',NULL,90,15,false,6),
('kerala-grand-explorer',2,'Kochi → Munnar','munnar','08:00','Departure to Munnar',NULL,30,255,false,1),
('kerala-grand-explorer',2,'Kochi → Munnar','munnar','12:30','Arrival & lunch',NULL,60,0,false,2),
('kerala-grand-explorer',2,'Kochi → Munnar','munnar','14:00','Munnar Tea Gardens','munnar-tea-gardens',120,20,true,3),
('kerala-grand-explorer',2,'Kochi → Munnar','munnar','16:00','Mattupetty Dam','mattupetty-dam',90,25,true,4),
('kerala-grand-explorer',3,'Munnar','munnar','09:00','Eravikulam National Park','eravikulam-national-park',180,40,true,1),
('kerala-grand-explorer',3,'Munnar','munnar','13:00','Lunch in town',NULL,60,20,false,2),
('kerala-grand-explorer',3,'Munnar','munnar','15:00','Echo Point','echo-point',45,30,true,3),
('kerala-grand-explorer',3,'Munnar','munnar','18:00','Return to hotel & spa',NULL,90,25,false,4),
('kerala-grand-explorer',4,'Munnar → Thekkady','thekkady','08:30','Drive to Thekkady',NULL,30,180,false,1),
('kerala-grand-explorer',4,'Munnar → Thekkady','thekkady','12:30','Spice plantation walk','spice-plantation-walk',90,15,false,2),
('kerala-grand-explorer',4,'Munnar → Thekkady','thekkady','15:00','Periyar lake cruise','periyar-wildlife-sanctuary',180,20,true,3),
('kerala-grand-explorer',5,'Thekkady → Alleppey','alleppey','08:00','Drive to Alleppey',NULL,30,210,false,1),
('kerala-grand-explorer',5,'Thekkady → Alleppey','alleppey','12:00','Houseboat backwater cruise','alleppey-backwaters',300,15,true,2),
('kerala-grand-explorer',5,'Thekkady → Alleppey','alleppey','18:00','Departure transfer',NULL,60,0,false,3),
('munnar-tea-country-escape',1,'Arrive Munnar','munnar','12:00','Check-in & tea estate stroll','munnar-tea-gardens',120,0,true,1),
('munnar-tea-country-escape',2,'Munnar','munnar','09:00','Eravikulam National Park','eravikulam-national-park',180,40,true,1),
('munnar-tea-country-escape',2,'Munnar','munnar','15:00','Tea Museum','tea-museum',60,20,false,2),
('munnar-tea-country-escape',3,'Munnar','munnar','09:00','Echo Point & departure','echo-point',45,30,true,1),
('royal-rajasthan-heritage',1,'Jaipur','jaipur','10:00','Amber Fort','amber-fort',150,40,false,1),
('royal-rajasthan-heritage',1,'Jaipur','jaipur','15:00','Hawa Mahal & bazaars','hawa-mahal',60,20,false,2),
('royal-rajasthan-heritage',2,'Jaipur','jaipur','09:30','City Palace & museums','city-palace-jaipur',120,15,false,1),
('royal-rajasthan-heritage',3,'Jaipur → Udaipur','udaipur','08:00','Scenic drive to Udaipur',NULL,30,390,false,1),
('royal-rajasthan-heritage',3,'Jaipur → Udaipur','udaipur','17:00','Lake Pichola sunset cruise','lake-pichola',90,15,true,2),
('royal-rajasthan-heritage',5,'Jaisalmer','jaisalmer','16:00','Sam Sand Dunes camel safari','sam-sand-dunes',180,45,true,1),
('goa-beach-indulgence',1,'North Goa','north-goa','15:00','Baga Beach & shacks','baga-beach',180,20,true,1),
('goa-beach-indulgence',2,'North Goa','north-goa','10:00','Fort Aguada','fort-aguada',90,30,true,1),
('hyderabad-nizami-trail',1,'Hyderabad','hyderabad','10:00','Charminar & Laad Bazaar','charminar',60,20,false,1),
('hyderabad-nizami-trail',1,'Hyderabad','hyderabad','15:00','Salar Jung Museum','salar-jung-museum',120,20,false,2),
('hyderabad-nizami-trail',2,'Hyderabad','hyderabad','09:30','Golconda Fort','golconda-fort',150,35,true,1),
('dubai-luxury-discovery',1,'Dubai','dubai-city','16:00','Dubai Mall & Fountain show','dubai-mall',180,30,false,1),
('dubai-luxury-discovery',2,'Dubai','dubai-city','10:00','Burj Khalifa observation deck','burj-khalifa',120,25,false,1),
('dubai-luxury-discovery',3,'Dubai','dubai-city','15:30','Desert safari & dinner','dubai-desert-safari',300,60,true,1),
('thailand-temples-islands',1,'Bangkok','bangkok','09:00','Grand Palace','grand-palace',150,30,false,1),
('thailand-temples-islands',2,'Bangkok','bangkok','09:00','Chatuchak Market','chatuchak-market',180,40,false,1),
('thailand-temples-islands',4,'Phuket','phuket','08:00','Phi Phi Islands speedboat','phi-phi-islands',480,60,true,1),
('paris-alpine-splendour',1,'Paris','paris','10:00','Eiffel Tower','eiffel-tower',150,30,true,1),
('paris-alpine-splendour',2,'Paris','paris','09:00','Louvre Museum','louvre-museum',240,25,false,1),
('paris-alpine-splendour',5,'Interlaken','interlaken','08:00','Jungfraujoch excursion','jungfraujoch',360,90,true,1)
) AS v(pslug,day,title,cslug,t,act,plslug,dur,travel,ws,ord) ON p.slug = v.pslug
LEFT JOIN public.cities ci ON ci.slug = v.cslug
LEFT JOIN public.tourist_places pl ON pl.slug = v.plslug;

INSERT INTO public.package_places (package_id, place_id, sort_order)
SELECT DISTINCT i.package_id, i.place_id, i.sort_order
FROM public.package_itinerary i WHERE i.place_id IS NOT NULL
ON CONFLICT DO NOTHING;

INSERT INTO public.routes (from_city_id,to_city_id,distance_km,travel_min,road_status,traffic_level,road_condition,notes)
SELECT f.id, t.id, v.km, v.min, v.status, v.traffic, v.cond, v.note
FROM (VALUES
('kochi','munnar',125,255,'open','moderate','good','Ghat section with hairpin bends after Neriamangalam.'),
('munnar','thekkady',90,180,'open','light','good','Scenic plantation road.'),
('thekkady','alleppey',140,210,'open','moderate','fair','Occasional monsoon waterlogging near Vaikom.'),
('kochi','alleppey',55,90,'open','moderate','good','NH-66 coastal highway.'),
('jaipur','udaipur',395,390,'open','light','good','Six-lane NH-48 for most of the drive.'),
('udaipur','jaisalmer',495,480,'open','light','fair','Long desert stretch, start early.'),
('bangkok','phuket',840,90,'open','light','good','Domestic flight recommended over road.'),
('paris','interlaken',680,330,'open','light','good','High-speed rail via Basel.')
) AS v(fs,ts,km,min,status,traffic,cond,note)
JOIN public.cities f ON f.slug = v.fs
JOIN public.cities t ON t.slug = v.ts;