DELETE FROM public.reviews
WHERE user_id IS NULL;