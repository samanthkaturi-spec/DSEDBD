# Cart and Checkout

## What will be built
- Add a persistent cart for travel packages, preserving live package names, images, rates, capacity, and duration from the catalogue.
- Add an **Add to cart** action on package details while keeping the existing direct booking/customization actions.
- Add a `/cart` page where travellers can review packages, change traveller counts, remove items, clear the cart, and see a calculated subtotal and GST estimate.
- Add a `/checkout` page that requires sign-in, collects trip dates and lead-traveller details per package, recalculates totals from current catalogue rates, accepts the existing demo payment methods, and creates real booking records in Lovable Cloud.
- Add a cart icon and live item count to desktop and mobile navigation.
- Clear successfully booked items and link each confirmation to **My Trips**.

## Data and pricing behavior
- Cart contents are stored in the browser so they survive navigation and refreshes; catalogue information is reloaded from Lovable Cloud before display and checkout.
- Package pricing uses the existing child-price factor and 5% GST logic; no example product or price data is introduced.
- Checkout remains clearly marked as demo payment because no live payment provider is connected.

## Verification
- Check empty and populated cart states, quantity controls, removal, sign-in protection, checkout validation, booking creation, cart clearing, and responsive navigation.
- Confirm the app builds cleanly and test the main flow in the preview.
